// LPRS eRIC I2C Routines (Updated)
// Based extensively on the eRIC/eROS code examples kindly provided by LPRS:
// http://www.lprs.co.uk/products/easyradio-ism-modules/eric-soc-rf-modules.html
// http://www.lprs.co.uk/assets/files/eRIC4_9_Datasheet_1.34.pdf
// http://www.lprs.co.uk/assets/files/Custom%20programming%20eRIC.zip
// http://www.lprs.co.uk/knowledge-centre/code-examples.html
// http://www.lprs.co.uk/assets/files/eRIC_I2C_V1.1.zip
// http://www.lprs.co.uk/assets/files/eRIC_I2C1.1.pdf

#include <cc430f5137.h>
#include "eRIC.h"
#include "LPRS_I2C.h"

unsigned char I2C_ReadAddress(char Address)
{
    eRIC_I2CB_AsTransmitter(); //I2C set as Master TX
    eRIC_I2CB_Start();//Start I2C. this will send address
    eRIC_I2CB_SendByte(Address); //Send address byte to read data
    while(eRIC_I2CB_TxBufferIsBusy());
    eRIC_I2CB_AsReceiver(); //I2C set as receiver
    eRIC_I2CB_Start();//Start I2C
    while(eRIC_I2CB_IsStartActive()); //wait while start is active, it needs to be cleared
    eRIC_I2CB_Stop(); //Stop I2C
    unsigned char result = eRIC_I2CB_ReceiveByte(); // Get received byte which is the data at the address
    while(eRIC_I2CB_IsBusBusy()); //wait while I2C is busy
    return result;// Return received byte
}

void I2C_WriteAddress(char Address, char Data)
{
    eRIC_I2CB_AsTransmitter(); //Set I2C as Master Tx
    eRIC_I2CB_Start();//Start I2C, this will send slave address
    eRIC_I2CB_SendByte(Address);//Send address byte
    eRIC_I2CB_SendByte(Data);//Send data to write at the address location
    while(eRIC_I2CB_TxBufferIsBusy());
    eRIC_I2CB_Stop();//Stop i2C
    while(eRIC_I2CB_IsBusBusy()); //wait while I2C is busy
}




