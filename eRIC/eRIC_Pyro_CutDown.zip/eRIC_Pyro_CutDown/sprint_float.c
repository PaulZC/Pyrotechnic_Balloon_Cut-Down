#include <cc430f5137.h>
#include "eRIC.h"
#include "sprint_float.h"

// This function is sprintf-like
// Based on LPRS' eRIC_Sprintf but adapted to handle floats
// Uses a sledgehammer-to-crack-a-wallnut approach...
// Could do with a little finessing!
// Returns the number of characters printed
// Will only handle floats less than 10,000,000
// and with up to three decimal places
unsigned char sprint_float(char *buffer, char *string, float value)
{
    unsigned char StringLength = eRIC_Stringlength(string);
    volatile unsigned char i = 0, j = 0;
    volatile float copy = value;
    if (copy > (float)9999999.999) // Ignore values >= 10,000,000
    {
        copy = (float)9999999.999;
    }
    for (i = 0; i < StringLength; i++)
    {
        if (string[i] == '%') //if special vals then parse here
        {
            i++;
            switch (string[i])
            {
                case 'f':
                {
                    volatile int digit = 0;
                    volatile char c;
                    volatile int fds = 0; // First digit seen
                    if (copy < 0) // Is value < zero?
                    {
                        buffer[j++] = '-'; // If it is, include a minus sign
                        copy = 0 - copy; // Make the copy positive
                    }
                    if (copy >= (float)1000000) // Is copy greater than this?
                    {
                        digit = (int)(copy / (float)1000000); // If it is, get the digit
                        c = (char)(digit + '0'); // Convert digit into a character
                        buffer[j++] = c; // Store it in the buffer
                        copy = copy - ((float)digit * (float)1000000); // Subtract
                        fds = 1; // Set fds to true
                    }
                    if (copy >= (float)100000) // Is copy greater than this?
                    {
                        digit = (int)(copy / (float)100000); // If it is, get the digit
                        c = (char)(digit + '0'); // Convert digit into a character
                        buffer[j++] = c; // Store it in the buffer
                        copy = copy - ((float)digit * (float)100000); // Subtract
                        fds = 1; // Set fds to true
                    }
                    else
                    {
                        if(fds)
                        {
                            buffer[j++] = '0'; // Add a zero to the buffer
                        }
                    }
                    if (copy >= (float)10000) // Is copy greater than this?
                    {
                        digit = (int)(copy / (float)10000); // If it is, get the digit
                        c = (char)(digit + '0'); // Convert digit into a character
                        buffer[j++] = c; // Store it in the buffer
                        copy = copy - ((float)digit * (float)10000); // Subtract
                        fds = 1; // Set fds to true
                    }
                    else
                    {
                        if(fds)
                        {
                            buffer[j++] = '0'; // Add a zero to the buffer
                        }
                    }
                    if (copy >= (float)1000) // Is copy greater than this?
                    {
                        digit = (int)(copy / (float)1000); // If it is, get the digit
                        c = (char)(digit + '0'); // Convert digit into a character
                        buffer[j++] = c; // Store it in the buffer
                        copy = copy - ((float)digit * (float)1000); // Subtract
                        fds = 1; // Set fds to true
                    }
                    else
                    {
                        if(fds)
                        {
                            buffer[j++] = '0'; // Add a zero to the buffer
                        }
                    }
                    if (copy >= (float)100) // Is copy greater than this?
                    {
                        digit = (int)(copy / (float)100); // If it is, get the digit
                        c = (char)(digit + '0'); // Convert digit into a character
                        buffer[j++] = c; // Store it in the buffer
                        copy = copy - ((float)digit * (float)100); // Subtract
                        fds = 1; // Set fds to true
                    }
                    else
                    {
                        if(fds)
                        {
                            buffer[j++] = '0'; // Add a zero to the buffer
                        }
                    }
                    if (copy >= (float)10) // Is copy greater than this?
                    {
                        digit = (int)(copy / (float)10); // If it is, get the digit
                        c = (char)(digit + '0'); // Convert digit into a character
                        buffer[j++] = c; // Store it in the buffer
                        copy = copy - ((float)digit * (float)10); // Subtract
                        fds = 1; // Set fds to true
                    }
                    else
                    {
                        if(fds)
                        {
                            buffer[j++] = '0'; // Add a zero to the buffer
                        }
                    }
                    if (copy >= (float)1) // Is copy greater than this?
                    {
                        digit = (int)(copy / (float)1); // If it is, get the digit
                        c = (char)(digit + '0'); // Convert digit into a character
                        buffer[j++] = c; // Store it in the buffer
                        copy = copy - ((float)digit * (float)1); // Subtract
                    }
                    else
                    {
                        buffer[j++] = '0'; // Always add a zero to the buffer
                    }
                    buffer[j++] = '.'; // Store the decimal point
                    if (copy >= (float)0.001) // Have we got anything in the three decimal places?
                    {
                        copy = copy * (float)1000; // Multiply by 1000 to reveal decimal places
                        if (copy >= (float)100) // Is copy greater than this?
                        {
                            digit = (int)(copy / (float)100); // If it is, get the digit
                            c = (char)(digit + '0'); // Convert digit into a character
                            buffer[j++] = c; // Store it in the buffer
                            copy = copy - ((float)digit * (float)100); // Subtract
                        }
                        else
                        {
                            buffer[j++] = '0'; // Add a zero to the buffer
                        }
                        if (copy >= (float)10) // Is copy greater than this?
                        {
                            digit = (int)(copy / (float)10); // If it is, get the digit
                            c = (char)(digit + '0'); // Convert digit into a character
                            buffer[j++] = c; // Store it in the buffer
                            copy = copy - ((float)digit * (float)10); // Subtract
                        }
                        else
                        {
                            buffer[j++] = '0'; // Add a zero to the buffer
                        }
                        if (copy >= (float)1) // Is copy greater than this?
                        {
                            digit = (int)(copy / (float)1); // If it is, get the digit
                            c = (char)(digit + '0'); // Convert digit into a character
                            buffer[j++] = c; // Store it in the buffer
                            copy = copy - ((float)digit * (float)1); // Subtract
                        }
                    }
                    else
                    {
                        buffer[j++] = '0'; // Add a single decimal place zero to the buffer
                    }
                    break;
                }
            }
        }
        else
        {
            buffer[j++] = string[i]; // Copy text characters
        }
    }
    return j; // Return the number of characters printed
}

