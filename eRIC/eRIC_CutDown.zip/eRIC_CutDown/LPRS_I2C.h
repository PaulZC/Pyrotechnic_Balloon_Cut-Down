// LPRS eRIC I2C Routines (Updated)
// Based extensively on the eRIC/eROS code examples kindly provided by LPRS:
// http://www.lprs.co.uk/products/easyradio-ism-modules/eric-soc-rf-modules.html
// http://www.lprs.co.uk/assets/files/eRIC4_9_Datasheet_1.34.pdf
// http://www.lprs.co.uk/assets/files/Custom%20programming%20eRIC.zip
// http://www.lprs.co.uk/knowledge-centre/code-examples.html
// http://www.lprs.co.uk/assets/files/eRIC_I2C_V1.1.zip
// http://www.lprs.co.uk/assets/files/eRIC_I2C1.1.pdf

unsigned char I2C_ReadAddress(char Address);

void I2C_WriteAddress(char Address, char Data);

