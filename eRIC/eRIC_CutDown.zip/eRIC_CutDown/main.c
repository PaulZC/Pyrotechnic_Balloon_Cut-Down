/* Code for the eRIC High Altitude Balloon Cut-Down Controller
 *
 * Based extensively on the eRIC/eROS code examples kindly provided by LPRS:
 * http://www.lprs.co.uk/products/easyradio-ism-modules/eric-soc-rf-modules.html
 * http://www.lprs.co.uk/assets/files/eRIC4_9_Datasheet_1.34.pdf
 * http://www.lprs.co.uk/assets/files/Custom%20programming%20eRIC.zip
 * http://www.lprs.co.uk/knowledge-centre/code-examples.html
 * http://www.lprs.co.uk/assets/files/eRIC_LowPowerMode_V1.1.zip
 * http://www.lprs.co.uk/assets/files/eRIC_I2C_V1.1.zip
 * http://www.lprs.co.uk/assets/files/eRIC_I2C1.1.pdf
 *
 * On power-up, transmits the eRIC serial number
 *
 * Then loops continuously checking for received radio data.
 * If the data contains the eRIC serial number, the FIRE signal goes high to trigger the cut-down
 * Pin 16 pulses an LED once per second.
 *
 * FIRE will go high if the eRIC receives:
 * * Its own serial number
 * * Its own serial number followed by a '1'
 *
 * FIRE will only go low again if the eRIC receives:
 * * Its own serial number followed by a '0'
 * or if the eRIC is reset
 *
 * The MPL3115A2 is not used in this version.
 * See eRIC_CutDown_Tx_Pressure_and_Temperature for examples of how to read the pressure and temperature.
 * Be aware that the error in the pressure reading is significant above 15km!
 *
 * The Watchdog Timer will generate a reset after three seconds if the main loop stalls
 *
 * Pin Allocations:
 * Pin 2 : CTS / Busy
 * Pin 3 : Serial RXD (Output)
 * Pin 4 : Serial TXD (Input)
 * Pin 5 : RTS / Ready
 * Pin 11: Boot
 * Pin 12: Boot
 * Pin 14: eRIC9 Frequency Select
 * Pin 15: Provides power for the MPL3115A2 sensor
 * Pin 16: LED
 * Pin 17: Provides power for the dual NOR gate controlling the FIRE signal
 * Pin 18: FIRE Enable (Active High)
 * Pin 19: FIRE Enable (Active Low)
 * Pin 20: I2C SCL
 * Pin 21: I2C SDA
 * Pin 22: ADC (PYRO voltage divided by 2)
 */

#include <cc430f5137.h>
#include "eRIC.h"
#include <stdio.h>
#include <string.h>
//#include "LPRS_I2C.h" // Not needed in this version
//#include "MPL3115A2.h" // Not needed in this version
//#include "sprint_float.h" // Not needed in this version

// Choose module type to ensure correct frequency selections
#define eRIC4
//#define   eRIC9

// Globals
volatile unsigned char MySerial[] = {'0','0','0','0','0','0','0','0'}; // Storage for the eRIC serial number
volatile unsigned char RxData[] = {'F','F','F','F','F','F','F','F','F'}; /// Storage for received data

// Main

int main(void)
{
    // First, set up the I/O pins

    // Initialise FIRE NOR gate power and signals
    // For FIRE to be high:
    // Pin 17 must be high (provides power to NOR gate)
    // Pin 18 must be high
    // Pin 19 must be low

    Pin19_SetHigh(); // Disable FIRE (before pin is changed to output)
    Pin19_SetAsOutput(); // Set Pin19 as Output to drive FIRE NOR gate
    Pin19_SetHigh(); // Disable FIRE

    Pin18_SetLow(); // Disable FIRE (before pin is changed to output)
    Pin18_SetAsOutput(); // Set Pin18 as Output to drive FIRE NOR gate (inverted)
    Pin18_SetLow(); // Disable FIRE

    Pin17_SetAsOutput(); // Set Pin17 as Output to provide power for FIRE NOR gate
    Pin17_SetHigh(); // Enable NOR gate

    // LED

    Pin16_SetAsOutput(); // Set Pin16 as Output to drive LED
    Pin16_SetHigh(); // Enable LED

    // MPL3115A2

    Pin15_SetAsOutput(); // Set Pin15 as Output to provide power for MPL3115A2
    Pin15_SetLow(); // Disable the MPL3115A2

    //Pin20_FunctionI2CB_SCl(); // Set Pin20 as I2C SCL // Not needed in this version
    //Pin21_FunctionI2CB_SDA(); // Set Pin 21 as I2C SDA // Not needed in this version

    // ADC for PYRO voltage
    // When FIRE is high, PYRO should be equal to the battery voltage
    // unless shorted to ground by the nichrome wire in the electric match
    // By reading the voltage on Pin22, you can tell if the nichrome wire
    // is present or has gone open circuit
    // The voltage on Pin22 is PYRO divided by 2

    Pin22_FunctionA2D(); // Set Pin22 as ADC to read PYRO voltage - currently unused

    // Now set up the eRIC

    eRIC_WDT_Stop(); // Disable WDT
    eRIC_GlobalInterruptDisable(); // Global interrupts disabled
    eRIC_SetCpuFrequency(1048576); // Set clock speed to 1.048MHz
    #ifdef eRIC4
        // eRIC4
        eROS_Initialise(434000000);       // eROS initialised at 434MHz
    #else
        // eRIC9
        Pin14_SetAsInput(); // Pin14 is set as input for swapping frequency
        Pin14_PullUpEnable(); // Enable pull-up on Pin14
        if(Pin14_Read()) // If Pin14 is open
        {
            eROS_Initialise(869750000);       //eROS initilaised at 869.75MHz
        }
        else // Pin14 is shorted to GND
        {
            eROS_Initialise(915000000);       //eROS initilaised at 915.00MHz
        }
    #endif
    eRIC_RfDataReceivedInterruptEnable(); // Enable Rf Data Rx interrupts
    eRIC_GlobalInterruptEnable(); // Enable interrupts

    eRIC_Rx_Enable(); // Enable receiver
    eRIC_ChannelSpacing = 100000; // Set channel spacing to 100kHz
    eRIC_Channel = 5; // Set channel 5
    eRIC_RfBaudRate = 1200; // Set over air baud rate to 1200
    eRIC_Power = 0; // Set transmit power to 0dBm
    eRIC_TxPowerLevel = 2; // Set Tx power saving (increases preamble length)
    eRIC_RxPowerLevel = 2; // Set Rx power saving (reduces receiver duty cycle)
    eRIC_RadioUpdate(); // Update settings

    eRIC_Delay(1000); // Wait

    // Get the eRIC serial number and transmit it

    eRIC_RadioTx_BuffCount = 0; // Reset the Tx buffer counter
    unsigned long sernum = eRIC_GetSerialNumber(); // Get the eRIC serial number
    unsigned char nibble = (unsigned char)((sernum >> 28) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)((sernum >> 24) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)((sernum >> 20) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)((sernum >> 16) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)((sernum >> 12) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)((sernum >> 8) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)((sernum >> 4) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)(sernum & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = 0x0A; // Add a new line character to Tx buffer

    eRIC_RfSenddata(); // Transmit the serial number
    while(eRIC_RadioTx_BuffCount); // wait for Tx to finish (eRIC_RfSenddata resets eRIC_RadioTx_BuffCount to zero when complete)

    volatile unsigned char i = 0;
    while(i<9) // Make sure RxData is clear
    {
        RxData[i++] = 'F';
    }

    // Initialise I2C communication // Not needed in this version
    /*
    eRIC_I2CB_Initialise(100000, 1, MPL3115A2_ADDRESS); // Set to 100kHz, eRIC is Master, MPL3115A2 unshifted address is 0x60
    setModeBarometer(); // Put MPL3115A2 into barometer mode
    setOversampleRate(0x07); // Set Oversample to the recommended 128
    enableEventFlags(); // Enable all three pressure and temp event flags
    eRIC_Delay(3000); // Allow 3 secs for MPL3115A2 to initialise
    // Read and discard Pressure and Temperature
    float pressure = readPressure();
    if (pressure >= 110000.0) pressure = 0.0; // Correct pressure wrap-around at extreme altitude
    float temperature = readTemp();
    */

    // Start the Watchdog Timer just before we enter the main loop
    eRIC_WDT_Setup(eRICWDT_Cs_10k+eRICWDT_Interval_32768); //Setup WDT with 10k clock and 32768 interval which would set flag after 3.28 secs
    eRIC_WDT_InterruptEnable(); //Enable WDT interrupt
    eRIC_WDT_Start(); //Start WDT

    while(1) // Loop continuously
    {
        eRIC_WDT_Stop(); //Stop WDT
        eRIC_WDT_Reset(); //Reset WDT
        eRIC_WDT_Start(); //Start WDT

        Pin16_SetHigh(); // Turn LED on
        eRIC_Delay(50); // Wait
        Pin16_SetLow(); // Turn LED off
        eRIC_Delay(950); // Wait

        // Compare RxData to MySerial, check for a match
        volatile int match = 1; // Flag to indicate a match. Initialise as true.
        // First check for the eRIC serial number followed by '1' or '0'
        i = 0;
        while(i < 8) // For each of the eight bytes
        {
            if (RxData[i] != MySerial[i]) // If the data does not match
            {
                match = 0; // Clear the flag
            }
            i++;
        }
        if (match) // If the serial number matches
        {
            if (RxData[8] == '1') // Check for a following '1'
            {
                Pin19_SetLow(); // Enable FIRE
                Pin18_SetHigh();
            }
            if (RxData[8] == '0') // Check for a following '0'
            {
                Pin19_SetHigh(); // Disable FIRE
                Pin18_SetLow();
            }
        }
        // Now check for the eRIC serial number on its own
        match = 1;
        i = 0;
        while(i < 8) // For each of the eight bytes
        {
            if (RxData[i+1] != MySerial[i]) // If the data does not match
            {
                match = 0; // Clear the flag
            }
            i++;
        }
        if (match) // If the data matches enable FIRE
        {
            Pin19_SetLow(); // Enable FIRE
            Pin18_SetHigh();
        }
    }

}// End of main

#pragma vector= WDT_VECTOR
__interrupt void WDT_ISR(void) // Watchdog Timer Interrupt Service Routine
{
    eRIC_PowerOnReset();           //Reset eRIC on WDT interrupt
}

void eRIC_RfDataReceivedInterrupt() // Deal with available received data. This is triggered when interrupt is enabled and a packet is received
{
    while(eRIC_Rxdata_available)
    {
        // Add the received character to RxData
        // Use RxData as a FIFO:
        //   shuffle each character along by one
        //   overwrite the oldest character in RxData[0]
        //   store the new character to RxData[8]
        char i = 0;
        while(i < 8)
        {
            RxData[i] = RxData[i+1]; // Shuffle each character along by one
            i++;
        }
        RxData[8] = eRIC_ReadRfByte(); // Store the new character in RxData[8]
    }
}


