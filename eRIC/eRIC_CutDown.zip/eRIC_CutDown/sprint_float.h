unsigned char sprint_float(char *buffer, char *string, float value);
