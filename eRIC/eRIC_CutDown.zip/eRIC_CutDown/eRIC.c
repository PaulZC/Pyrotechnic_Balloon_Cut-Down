/*
 * eRIC.c
 *
 *  Created on: May 2015
 *      Author: lprs.co.uk
 *      Version 1.4: Copied functions and variable from eRIC.h file and left eRIC.h file only with definition
 *                 : Modified ADC function, added ADC Ref Out on Pin 22 and also Temperature is also corrected based on modified ADC
 *      Version 1.5: AES modified/removed. Pin22 interrupt used.
 */

//Version added in V1.5
//Version added in V1.5.5

#include<cc430f5137.h>
#include "eRIC.h"

#pragma DATA_SECTION(eRIC_Port2Busy,".eRIC_port2busy")
volatile unsigned char eRIC_Port2Busy;

#pragma DATA_SECTION(eRIC_Port3Busy,".eRIC_port2busy")
volatile unsigned char eRIC_Port3Busy;

#pragma DATA_SECTION(CommonPassedVariable,".Commonpassedvariable")
volatile unsigned long CommonPassedVariable;
#pragma DATA_SECTION(CommonPassedVariable2,".Commonpassedvariable2")
volatile unsigned long CommonPassedVariable2; //All general variable passed through application into eROS
#pragma DATA_SECTION(CommonPassedVariable3,".Commonpassedvariable3")
volatile unsigned long CommonPassedVariable3;

#pragma DATA_SECTION(CommonReturnVariable,".Commonreturnvariable")
volatile unsigned long CommonReturnVariable;
#pragma DATA_SECTION(eRIC_RadioTx_Buffer,".eRIC_radiotx_buffer")  //Uart_Rx_Buff
unsigned char eRIC_RadioTx_Buffer[256];

#pragma DATA_SECTION(Read_Rf_Byte,".Read_rf_byte")
volatile unsigned char Read_Rf_Byte;

#pragma DATA_SECTION(DelayCycles,".Delaycycles")
volatile unsigned int DelayCycles;

#pragma DATA_SECTION(eRIC_Frequency,".eRIC_frequency")
volatile unsigned long eRIC_Frequency;
#pragma DATA_SECTION(eRIC_Power,".eRIC_power")
volatile signed char eRIC_Power;
#pragma DATA_SECTION(eRIC_Channel,".eRIC_channel")
volatile unsigned char eRIC_Channel;
#pragma DATA_SECTION(eRIC_ChannelSpacing,".eRIC_channelspacing")
volatile unsigned long eRIC_ChannelSpacing;
#pragma DATA_SECTION(eRIC_RfBaudRate,".eRIC_rfbaudrate")
volatile unsigned long eRIC_RfBaudRate;
#pragma DATA_SECTION(eRIC_CpuFrequency,".eRIC_cpufrequency")
volatile unsigned long eRIC_CpuFrequency;
#pragma DATA_SECTION(eRIC_RxPowerLevel,".eRIC_rxpowerlevel")
volatile char eRIC_RxPowerLevel;

#pragma DATA_SECTION(eRIC_TxPowerLevel,".eRIC_txpowerlevel")
volatile char eRIC_TxPowerLevel;

#pragma DATA_SECTION(eRIC_RadioTx_BuffCount,".eRIC_radiotx_buffcount")// Uart_Rx_buff_Count in eros
volatile unsigned char eRIC_RadioTx_BuffCount;
#pragma DATA_SECTION(eRIC_Rxdata_available,".eRIC_Rxdata_available")
volatile unsigned char eRIC_Rxdata_available;

#pragma DATA_SECTION(Eeprom_Address,".eeprom_address")
volatile unsigned char Eeprom_Address;

#pragma DATA_SECTION(Eeprom_Data,".eeprom_data")
volatile unsigned char Eeprom_Data;

#pragma DATA_SECTION(watch1,".watch1")
volatile unsigned int watch1;
#pragma DATA_SECTION(watch1_type,".watch1_type")
volatile unsigned int watch1_type;
#pragma DATA_SECTION(watch2,".watch2")
volatile unsigned int watch2;
#pragma DATA_SECTION(watch2_type,".watch2_type")
volatile unsigned int watch2_type;
#pragma DATA_SECTION(watch3,".watch3")
volatile unsigned int watch3;
#pragma DATA_SECTION(watch3_type,".watch3_type")
volatile unsigned int watch3_type;
#pragma DATA_SECTION(watch4,".watch4")
volatile unsigned int watch4;
#pragma DATA_SECTION(watch4_type,".watch4_type")
volatile unsigned int watch4_type;
#pragma DATA_SECTION(watch5,".watch5")
volatile unsigned int watch5;
#pragma DATA_SECTION(watch5_type,".watch5_type")
volatile unsigned int watch5_type;
#pragma DATA_SECTION(watch6,".watch6")
volatile unsigned int watch6;
#pragma DATA_SECTION(watch6_type,".watch6_type")
volatile unsigned int watch6_type;
#pragma DATA_SECTION(watch7,".watch7")
volatile unsigned int watch7;
#pragma DATA_SECTION(watch7_type,".watch7_type")
volatile unsigned int watch7_type;
#pragma DATA_SECTION(watch8,".watch8")
volatile unsigned int watch8;
#pragma DATA_SECTION(watch8_type,".watch8_type")
volatile unsigned int watch8_type;
#pragma DATA_SECTION(watch9,".watch9")
volatile unsigned int watch9;
#pragma DATA_SECTION(watch9_type,".watch9_type")
volatile unsigned int watch9_type;
#pragma DATA_SECTION(watch10,".watch10")
volatile unsigned int watch10;
#pragma DATA_SECTION(watch10_type,".watch10_type")
volatile unsigned int watch10_type;

#pragma DATA_SECTION(eRIC_Prog_Mode,".eRIC_prog_mode")
volatile unsigned char eRIC_Prog_Mode;

#pragma DATA_SECTION(eRIC_GroupID,".eRIC_groupid")
volatile unsigned int eRIC_GroupID;

#pragma DATA_SECTION(eRIC_FlagStatus,".eRIC_flagstatus")
unsigned int eRIC_FlagStatus;

#pragma DATA_SECTION(eRIC_RSSI,".eRIC_rssi")
volatile signed char eRIC_RSSI;
#pragma DATA_SECTION(eRIC_PACKETRSSI,".eRIC_packetrssi")
volatile signed char eRIC_PACKETRSSI;

#pragma DATA_SECTION(eRIC_AES_Key,".eRIC_aes_key")
volatile unsigned char eRIC_AES_Key[17];                        //V4.1

#pragma DATA_SECTION(eRIC_AES_Data,".eRIC_aes_data")
volatile unsigned char eRIC_AES_Data[16];                        //V4.1

#pragma DATA_SECTION(eRIC_LPMLevel,".eRIC_lpmlevel")
volatile unsigned char eRIC_LPMLevel;                        //V4.2

#pragma DATA_SECTION(eRIC_LastCauseOfReset,".eRIC_lastcauseofreset")
volatile unsigned int eRIC_LastCauseOfReset;                        //V4.5 V1.5.5 , last cause of reset can be retrieved from this variable





void SetAdcPin(volatile unsigned char eRICPinNumber)
{
//	ADC12CTL0 = ADC12SHT0_15 + ADC12ON;         // Sampling time, ADC12 on modified in V1.5.4 below
	ADC12CTL0 = ADC12SHT0_15;         // Sampling time, ADC12 on removed ADC on here added in read adc functin in V1.5.4
	ADC12CTL1 = ADC12SHP;                       // Use sampling timer
	ADC12MCTL0 = ADC12SREF_1;                 // Ref:vref+ =vref+ and vref-=Avss
	switch (eRICPinNumber)
	{
	case 1:
		Pin1_FunctionA2D();
		ADC12MCTL0 |= ADC12INCH_4;     // ADC input ch A4
		break;
	case 2:
		Pin2_FunctionA2D();
		ADC12MCTL0 |= ADC12INCH_3;     // ADC input ch A3
		break;
	case 3:
		Pin3_FunctionA2D();
		ADC12MCTL0 |= ADC12INCH_2;     // ADC input ch A2
		break;
	case 4:
		Pin4_FunctionA2D();
		ADC12MCTL0 |= ADC12INCH_1;     // ADC input ch A1
		break;
	case 5:
		Pin5_FunctionA2D();
		ADC12MCTL0 |= ADC12INCH_0;     // ADC input ch A0
		break;
	case 22:
		Pin22_FunctionA2D();
		ADC12MCTL0 |= ADC12INCH_5;     // ADC input ch A5
		break;
	case 10:
		ADC12MCTL0 |= ADC12INCH_10;     // ADC input ch A10
		break;
	default:
		break;
	}

	ADC12CTL1 |= ADC12CSTARTADD_0; //Mem0 selected//ADC12_A conversion start address. These bits select which ADC12_A
									   // conversion-memory register is used for a single conversion or for the first
									   // conversion in a sequence. The value of CSTARTADDx is 0 to 0Fh,
									   // corresponding to ADC12MEM0 to ADC12MEM15.

}

void SetAdcRefVolt(unsigned char eRIC_ReferenceVoltage,unsigned char RefOut_OnorOff_Pin22)
{
	//REFCTL0 = REFMSTR + (eRIC_ReferenceVoltage << 4) + REFON; // Enable REF module on chip with
	REFCTL0 = REFMSTR + (eRIC_ReferenceVoltage << 4); // Enable REF module on chip with  removed refon and turn it on only when needed,,either when readin adc or refout is enabled
	// Ref voltage according to the passed in Ref
	//eRIC_AdcRefVoltage= 0x0000-> 1.5v
	//eRIC_AdcRefVoltage= 0x0010-> 2.0v
	//eRIC_AdcRefVoltage= 0x0020-> 2.5v
	//eRIC_AdcRefVoltage= 0x0030-> 2.5v
	if(RefOut_OnorOff_Pin22)
	    REFCTL0|= (REFOUT+REFON);                         //REFCTL0|= REFOUT;      //Put reference voltage out on Pin 22

}

unsigned long ReadAdc()                 //Added or modified in V1.4
{
	unsigned long eRIC_AdcResult = 0;
	if(!(REFCTL0&REFON))
	    REFCTL0 |=REFON;
//	ADC12CTL0 |= ADC12ENC + ADC12SC;     // Enable and Start sampling/conversion
	ADC12CTL0 |= ADC12ON + ADC12ENC + ADC12SC;     // Added V1.5.4 turn on ADC and Enable and Start sampling/conversion
	while (ADC12CTL1 & ADC12BUSY);  // Wait until conversion finishes
	while(!(ADC12IFG & ADC12IFG0)); //V1.5.4 wait until ADC12Memo is loaded with conversion
	//if (ADC12IFG & ADC12IFG0)
	{
		eRIC_AdcResult = ADC12MEM0;  //Store result
	}

	ADC12CTL0&=~(ADC12ON+ADC12ENC);// Added V1.5.4 Turn off adc and disable conversion without this 240uA
	if(!(REFCTL0&REFOUT)) //Added V1.5.4 to reduce current and it only turns off REF when refout is not selected on pIn22
	    REFCTL0&=~REFON;

	return eRIC_AdcResult;
}

 float GetTemperature()
 {
	 int Temp_ADC = 0;
	 unsigned char readcalibration = 0;
	 long tempcalibration_30 = 0, tempcalibration_85 = 0;
	 unsigned char *ptrtempcalibration = (unsigned char *) 0x1A1A; //THis is the location for calibrated
	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	   // digital value for 30 celcius at 1.5v ref
	 readcalibration = *ptrtempcalibration;
	 tempcalibration_30 = (readcalibration & 0xFF);          //Get low byte first
	 ptrtempcalibration++;                            //NOw location is 0x1A1B
	 readcalibration = *ptrtempcalibration;
	 tempcalibration_30 |= ((readcalibration << 8) & 0xFF00); //Or with high byte
	 tempcalibration_30 &= 0xFFFF;            // TO get only 2 bytes just in case
	 ptrtempcalibration++; //NOw location is 0x1A1C, this is for calibrated
	 	 	 	 	 	   // digital value for 85 celcius at 1.5v ref
	 readcalibration = *ptrtempcalibration;
	 tempcalibration_85 = (readcalibration & 0xFF); //Get low byte first
	 ptrtempcalibration++;                         //NOw location is 0x1A1D
	 readcalibration = *ptrtempcalibration;
	 tempcalibration_85 |= ((readcalibration << 8) & 0xFF00); //Or with high byte
	 tempcalibration_85 &= 0xFFFF;            // TO get only 2 bytes just in case
	 //  eRIC_AdcPin = 10;//Adc channel 10 for temperature
	 //  eRIC_AdcRefVoltage = 0;//Adc reference 1.5v for temperature
	 //Temp_ADC = ReadAdc(10, 0); // Call adc //Removed in V1.4
	 //  Temp_ADC = eRIC_AdcResult;//get temperature using ReadAdc function
	 SetAdcPin(10);       //Added in V1.4
	 SetAdcRefVolt(0,0);   //Added in V1.4
	 Temp_ADC = ReadAdc();  //Added in V1.4
	 //return Temp_ADC;
	 //Based on formula in datasheet, refer data sheet.{[(temp-adc30)(85-30)]/(adc85-adc30)}+30
	 volatile long Temperature = (long) (Temp_ADC - tempcalibration_30);
	 Temperature *= 55;
	 float ActualTemp = (float) Temperature / (float) (tempcalibration_85 - tempcalibration_30);
	 ActualTemp += 30; //Gets temperatue in decimals points
	 //     return (char)Temp_ADC>>4;//Temperature;//(long) 21.85;
	 return ActualTemp;
	/*  long Temperature = (Temp_ADC - tempcalibration_30);
	 Temperature *= 550;
	 Temperature /= (long)(tempcalibration_85 - tempcalibration_30);
	 Temperature += 300; //Gets temperatue in decimals points
	 return (long)Temperature/10;*/

	/*   int eRIC_Temperature;
	 eRIC_Temperature = (char)Temperature; //Takes temperature real value
	 Temperature -= eRIC_Temperature;//Leaves temperatue only with decimal
	 P3OUT |= BIT3;
	 Temperature *=10;//makes it real value to 1 digit
	 eRIC_Temperature<<=8;//High byte is real value temperature
	 eRIC_Temperature |=(char)Temperature; //Low byte is decimal value temperature
	 return eRIC_Temperature;
	 */
}

//void Uart_SetBaud(unsigned long baud, unsigned long CpuFrequency);
//void Uart_SetBaud(volatile unsigned long baud,volatile unsigned long CpuFrequency)
void eRIC_UARTA_SetBaud(unsigned long Baudrate)
{
//	unsigned long freq = eRIC_CpuFrequency / Baudrate;
//	UCA0BR0 = freq;
//	UCA0BR1 = (freq >> 8);

    unsigned long freq = (eRIC_CpuFrequency*10) / Baudrate; //Will get one decimal point
    unsigned long tempfreq = freq/10;
    UCA0BR0 = tempfreq;
    UCA0BR1 = (tempfreq >> 8);
    tempfreq = freq - (tempfreq*10); //This is to get unit value from freq.Say  if freq  = 34, then 34-30 = 4.
    if(tempfreq>7)
        tempfreq=7; // UCBRS can go upto 7
    tempfreq<<=1;
    UCA0MCTL = tempfreq&0x0E; //UCBRF is always 0, UCOS16 is always0
}


//void UartInitialise(unsigned long baud, unsigned long CpuFrequency)
void eRIC_UARTAInitialise(unsigned long Baudrate)
{
    char interruptBool = eRIC_GlobalInterruptIsEnabled();//Get GIE interrupt status
    eRIC_GlobalInterruptDisable(); //Disable GIE
	UCA0CTL1 = UCSWRST;                      // **Put state machine in reset** V1.5

	if(eRIC_CpuFrequency>=30000 && eRIC_CpuFrequency<40000)
	    UCA0CTL1 |= UCSSEL__ACLK;                     // ACLK
	else
	    UCA0CTL1 |= UCSSEL_2;                     // SMCLK

	eRIC_UARTA_SetBaud(Baudrate);
	//Uart_SetBaud(baud, CpuFrequency);            //High byte baud value register
//	UCA0MCTL |= UCBRS_2 + UCBRF_0;            // Modulation UCBRSx=1, UCBRFx=0         //Removed in V1.5.5 and added in eRIC_UARTA_SetBaud()

	UCA0CTL1 &= ~UCSWRST;                   // **Initialize USCI state machine**
	if(interruptBool)
	    eRIC_GlobalInterruptEnable();
}



void eRIC_SpiAInitialise(unsigned long SpiClock) //added in V1.4
{
    char interruptBool = eRIC_GlobalInterruptIsEnabled();//Get GIE interrupt status
    eRIC_GlobalInterruptDisable(); //Disable GIE
	UCA0CTL1 |= UCSWRST;                      // **Put state machine in reset**
	UCA0CTL0 |= UCMST + UCSYNC + UCCKPH + UCMSB;    // 3-pin, 8-bit SPI master
	                                                // Clock polarity high, MSB
	UCA0CTL1 |= UCSSEL_2;                     // SMCLK
	//volatile unsigned long freq = CpuFrequency / SpiClock;
	volatile unsigned long freq = eRIC_CpuFrequency / SpiClock;
	UCA0BR0 = freq;                           //
	UCA0BR1 = (freq >> 8);                    //
	UCA0MCTL = 0;                             // No modulation
	UCA0CTL1 &= ~UCSWRST;                   // **Initialize USCI state machine**
	if(interruptBool)
	    eRIC_GlobalInterruptEnable();
}

unsigned char SpiATransfer(volatile unsigned char Data)
{
	while (eRIC_SpiATxBufferIsBusy());    // Wait for any possible transfer to have completed
	eRIC_SpiASendByte(Data);           	  // Send the Data. For receive this can be anything
	while (eRIC_SpiARxBufferIsBusy());    // Wait for Transfer of 8 clock cycles. If receiving, then the received byte will be ready in the biffer
	return eRIC_SpiAReceiveByte();        // Macro t/o return value received from SPI DI in UCA0RXBUF
}

void eRIC_SpiBInitialise(volatile unsigned long SpiClock)//Added in V1.4
{
    char interruptBool = eRIC_GlobalInterruptIsEnabled();//Get GIE interrupt status
    eRIC_GlobalInterruptDisable(); //Disable GIE
	UCB0CTL1 |= UCSWRST;                      // **Put state machine in reset**
	UCB0CTL0 |= UCMST + UCSYNC + UCCKPH + UCMSB;    // 3-pin, 8-bit SPI master
	                                                // Clock polarity high, MSB
	UCB0CTL1 |= UCSSEL_2;                     // SMCLK
	//volatile unsigned long freq = CpuFrequency / SpiClock;
	volatile unsigned long freq = eRIC_CpuFrequency / SpiClock;
	UCB0BR0 = freq;                           //
	UCB0BR1 = (freq >> 8);                    //
	// UCB0MCTL = 0;                             // No modulation
	UCB0CTL1 &= ~UCSWRST;                   // **Initialize USCI state machine**
	if(interruptBool)
	    eRIC_GlobalInterruptEnable();
}

unsigned char SpiBTransfer(volatile unsigned char Data)
{
	while (eRIC_SpiBTxBufferIsBusy());    // Wait for any possible transfer to have completed
	eRIC_SpiBSendByte(Data);	// Send the Data. For receive this can be anything
	while (eRIC_SpiBRxBufferIsBusy()); // Wait for Transfer of 8 clock cycles. If receiving, then the received byte will be ready in the biffer
	return eRIC_SpiBReceiveByte(); // Macro t/o return value received from SPI DI in UCA0RXBUF
}

void eRIC_Stringcopy(volatile unsigned char *destination, const char *source, volatile unsigned char count)
{
	volatile unsigned int i = 0;
	for (i = 0; i < count; i++)
	{
		destination[i] = source[i];
	}
}

unsigned char eRIC_Stringcompare(char *a, char *b, unsigned char count)
{
	volatile unsigned int i = 0;
	for (i = 0; i < count; i++)
	{
		if (a[i] != b[i])
			return 1;
	}
	return 0;
}

unsigned char eRIC_Stringlength(char *string)
{
	unsigned char i = 0;
	while (string[i++] != 0);
	return i;
}

unsigned char eRIC_Sprintf(char *buff, char *string, float val)
{
	unsigned char StringLength = eRIC_Stringlength(string);
	volatile unsigned char i = 0, j = 0;
	int longval = val;
	signed char decimal; // = longval*10;
	val -= longval;
	decimal = val * 10; ///0.1;//-3;// val - decimal;
	for (i = 0; i < StringLength; i++)
	{
		if (string[i] == '%') //if special vals then parse here
		{
			i++;
			switch (string[i])
			{
			case 'f':
			case 'd':
			{
				//				i++;
				if (longval < 0)
				{
					buff[j++] = '-'; // add minus sign
					longval = 0 - longval; // flip to a positive
				}
				//int fullIntegers = val;
				unsigned char hundreds = 0, tens = 0, units = 0; //
				tens = longval / 10;
				units = longval % 10;
				while (tens > 9)
				{
					hundreds++;
					tens -= 10;
				}
				if (hundreds)
				{
					buff[j++] = (hundreds) + '0';
				}
				if (tens | hundreds)
				{
					buff[j++] = (tens) + '0';
				}
				buff[j++] = units + '0';
				if (string[i] == 'f')
				{
					if (decimal < 0)
						decimal = 0 - decimal;
					buff[j++] = '.'; // add decimal point
					buff[j++] = decimal + '0';
				}
				break;
			}
			}
		}
		else
		{
			buff[j++] = string[i];
		}
	}
	return j;
}


void eRIC_Print(char* txt)
{
	unsigned char length = eRIC_Stringlength(txt);
	unsigned char i = 0;
	for (i = 0; i < length; i++)
	{
		while (!(UCA0IFG & UCTXIFG)); //while(eRIC_UartATxBufferIsBusy());
		UCA0TXBUF = txt[i]; //eRIC_UartASendByte(txt[i]);
	}
}

char eRIC_Ascii2Hex(char val)
{
	if (val >= 'a' && val <= 'f')
		return val - ('a' - 10);
	if (val >= 'A' && val <= 'F')
		return val - ('A' - 10);
	if (val >= '0' && val <= '9')
		return val - '0';
	return 0;
}

char eRIC_Int2Ascii(int val)
{
	if (val < 0xa)
	{
		return val + '0';
	}
	else
	{
		return (val - 10 + 'A');
	}
}



unsigned char Rx_data()
{
	asm(" CALLA #0X8030");
	return Read_Rf_Byte;
}

signed char GetPacketRSSI()
{
	volatile signed char TempRssi = eRIC_PACKETRSSI;
	if (TempRssi >= 128)
	{
		TempRssi = ((TempRssi - 256) / 2) - 74;
	}
	else
		TempRssi = (TempRssi / 2) - 74;
	return TempRssi;
}

unsigned char eRIC_Eeprom_Read(volatile unsigned char Address)
{
    unsigned char *Flash_ptr; //Added in V1.5.5, avoids calling eROS
    Flash_ptr = (unsigned char *)(0x1900+Address);
    Eeprom_Data = *Flash_ptr;

//	Eeprom_Address = Address;  //Removed in V1.5.5
//	asm(" CALLA #0x8044");
	return Eeprom_Data;
}

void eRIC_Eeprom_Write(volatile unsigned char Address,volatile unsigned char Data)
{
    if(eRIC_RxPowerLevel==0 || eRIC_RxPowerLevel==8 )
    {
	while (eRIC_Eeprom_Read(Address) != Data)
	{
	    Eeprom_Address = Address;
		Eeprom_Data = Data;
		asm(" CALLA #0x8040");
	}
    }
}

unsigned long GetSerialNumber()
{
	asm(" CALLA #0x8064");
	return CommonReturnVariable;
}


void SetUncalibratedFrequency()  //Added in V1.4
{
	unsigned char *ptr = (unsigned char *)0x1806;
	char offset = 0;
	float temp =0;
	if (*ptr != 0xFF)
	{
		offset = *ptr;
	}
	volatile unsigned long tempfrequency = eRIC_Frequency;
	temp = eRIC_Frequency/1000000;
	temp *= (offset & 0x7F);
	if(offset & 0x80)
		eRIC_Frequency -= temp;
	else
		eRIC_Frequency += temp;
	eRIC_RadioUpdate();
	eRIC_Frequency = tempfrequency;
} //Added in V1.4

signed char GetRSSI()
{
	asm(" CALLA #0x8054");
	//RSSI Function in
	return eRIC_RSSI;
}

void eRIC_RadioAsyncMode()
{
	CommonPassedVariable2 = 1;
	asm(" CALLA #0x8024");
}

void eRIC_RadioPacketMode()
{
	CommonPassedVariable2 = 0;
	asm(" CALLA #0x8024");
}

void eROS_Initialise(volatile unsigned long RadioFrequency)
{
	eRIC_Frequency = RadioFrequency;
	asm(" CALLA #0x8008"); //V1.4
//	eRIC_SetPMMVCoreLevel(3); //V1.5
	asm(" CALLA #0x8004");
}

void eRIC_SetCpuFrequency(volatile unsigned long ClockFrequency)
{
    if(ClockFrequency!=eRIC_CpuFrequency)
    {
        eRIC_CpuFrequency = ClockFrequency;
        asm(" CALLA #0x8034");
    }
}

void eRIC_FlashProgram_Mode(volatile unsigned char Mode /*0 = UART FLash*/)
{
	CommonPassedVariable = Mode;
	asm(" CALLA #0x805C");
}

void eRIC_Delay(volatile unsigned int MilliSeconds)
{
	DelayCycles = MilliSeconds;
	asm(" CALLA #0x8060");
}

void eRIC_Tx_CarrierOn()
{
	CommonPassedVariable2 = 1;
	asm(" CALLA #0X8020");
}

void eRIC_Tx_CarrierOff()
{
	CommonPassedVariable2 = 0;
	asm(" CALLA #0X8020");
}

void eRIC_GroupIDEnable(volatile unsigned int IDNumber)
{
	eRIC_FlagStatus |= BIT3;
	eRIC_GroupID = IDNumber;
	asm(" CALLA #0X8028");
}//Radio update also to update sync

void eRIC_GroupIDDisable()
{
	eRIC_FlagStatus &= ~(BIT3);
	asm(" CALLA #0X8028");
}

unsigned int IsGroupID_Enabled()
{
	return (eRIC_FlagStatus&(BIT3));
}

unsigned int IsRadio_Rx_Busy()
{
	return (eRIC_FlagStatus&(BIT0));
}

unsigned int Is60ByteLimitEnabled()
{
	return(eRIC_FlagStatus&(BIT1));
}

unsigned int IsAsyncModeEnabled()
{
	return (eRIC_FlagStatus&(BIT2));
}

void eRIC_FunctionClearUartABusy()
{
	eRIC_Port2Busy = 0;
	eRIC_Port3Busy = 0;
}


void eRIC_I2CB_Initialise(volatile unsigned long I2CClock,char MasterorSlave,char Address)
{
	if(eRIC_CpuFrequency)
		UCB0CTL1 = UCSSEL_1 + UCSWRST;            // Use ACLK, keep SW reset
	else
		UCB0CTL1 = UCSSEL_2 + UCSWRST;            // Use SMCLK, keep SW reset
	UCB0CTL0 = UCMODE_3 + UCSYNC;                 // I2C , synchronous mode
	if(MasterorSlave)                             // If Master
	{
		UCB0CTL0 |= UCMST;                        //I2C as Master
		eRIC_I2CB_AsTransmitter();                //I2C as Transmitter
		eRIC_I2CB_SlaveAddress = Address;         //Assign I2C Slave address
	}
	else                                          //If slave
	{
		UCB0CTL0 &= ~UCMST;                       //I2C as slave
		eRIC_I2CB_AsReceiver();                   //I2C as receiver
		eRIC_I2CB_OwnAddress = Address;           //Assign I2C Own address
	}
	UCB0BR0 = (eRIC_CpuFrequency/I2CClock)+1; //THis gets the required register value to go in UCB0BR0 for required I2CClock
	                                     //Condition CpuFrequency>=I2CClock*5
	UCB0BR1 = 0;

	eRIC_I2CB_SoftwareResetDisable();
}

unsigned char I2CBReceiveByte()
{
	while(eRIC_I2CB_RxBufferIsBusy());            //Wait until it received byte
    return UCB0RXBUF;
}

//V1.5
void eRIC_SetPMMVCoreLevel(volatile unsigned char Level)
{
    CommonPassedVariable = Level;
    asm(" CALLA #0X806C");

}

unsigned char RadioRegRead(unsigned char Address) //V1.5
{
    CommonPassedVariable = Address;
    asm(" CALLA #0X8080");
    return CommonReturnVariable;
}

/*void eRIC_RfDataReceivedInterrupt()   //V1.5.4 Add code here to deal with  available received data..THis is triggered when interrupt is enabled and a apcket is received
{
}*/


/*
 *
 * All interrupts are handled here, for now they do nothing.
 * CC1l01 interrupt is handled in EROS so not available for customers.
 *
 */

#pragma vector= ADC12_VECTOR
__interrupt void ADC12_ISR(void) {

}

#pragma vector= AES_VECTOR
__interrupt void AES_ISR(void) {

}

#pragma vector= COMP_B_VECTOR
__interrupt void COMP_B_ISR(void) {

}

#pragma vector= DMA_VECTOR
__interrupt void DMA_ISR(void) {

}

#pragma vector= PORT1_VECTOR         //V1.5.4
__interrupt void PORT1_ISR(void)
{
    switch(P1IV)
    {
    case 0x06:   //P1.2 interrupt
    {
        eRIC_RfDataReceivedInterrupt(); //V1.5.4
        break;
    }
    default:
        break;
    }

}

/*#pragma vector= PORT2_VECTOR
__interrupt void PORT2_ISR(void) {

}*/

#pragma vector= RTC_VECTOR
__interrupt void RTC_ISR(void) {

}

#pragma vector= SYSNMI_VECTOR
__interrupt void SYSNMI_ISR(void) {

}

#pragma vector= UNMI_VECTOR
__interrupt void UNMI_ISR(void) {

}

#pragma vector= USCI_B0_VECTOR
__interrupt void USCI_B0_ISR(void) {

}

/*
#pragma vector= WDT_VECTOR
__interrupt void WDT_ISR(void) {

}
*/

/*
 #pragma vector=TIMER0_A0_VECTOR      //Vector CC0
__interrupt void TIMER0__A0_ISR(void) 
{

}

#pragma vector=TIMER0_A1_VECTOR          //Vector for CC1-4
__interrupt void TIMER0__A1_ISR(void) 
{

}

 #pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
{

}

 */
