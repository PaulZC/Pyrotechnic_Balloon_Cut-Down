/* Code for V2 of the Pyrotechnic Balloon Cut-Down Device
 *
 * Based extensively on the eRIC/eROS code examples kindly provided by LPRS:
 * http://www.lprs.co.uk/products/easyradio-ism-modules/eric-soc-rf-modules.html
 * http://www.lprs.co.uk/assets/files/eRIC4_9_Datasheet_1.34.pdf
 * http://www.lprs.co.uk/assets/files/Custom%20programming%20eRIC.zip
 * http://www.lprs.co.uk/knowledge-centre/code-examples.html
 * http://www.lprs.co.uk/assets/files/eRIC_LowPowerMode_V1.1.zip
 *
 * Uses Alan Carvalho de Assis' fork of Mikal Hart's TinyGPS to parse data from the u-blox CAM_M8 GNSS
 * https://github.com/acassis/tinygps
 *
 * Pin Allocations:
 * Pin 1 : ADC (Bus voltage / 4.3) [P2.4] - Usually CD
 * Pin 2 : Connected to the "+" switch [P2.3] - Usually CTS
 * Pin 3 : Connected to the "10K" switch - Serial RXD (Output) in bootloader mode [P2.2]
 * Pin 4 : Connected to the "-" switch - Serial TXD (Input) in bootloader mode [P2.1]
 * Pin 5 : Connected to the "1K" switch [P2.0] - Usually RTS
 * Pin 10: Unused
 * Pin 11: Boot
 * Pin 12: Boot
 * Pin 13: Unused
 * Pin 14: eRIC9 Frequency Select
 * Pin 15: Enables 3.3V power for the CAM_M8 (Low = 3.3V is enabled)
 * Pin 16: LED
 * Pin 17: Provides power for the dual NOR gate controlling the FIRE signal
 * Pin 18: FIRE Enable (Active High)
 * Pin 19: FIRE Enable (Active Low)
 * Pin 20: UART Rx - connected to CAM_M8 TxD
 * Pin 21: UART Tx - connected to CAM_M8 RxD
 * Pin 22: Unused
 *
 * FIRE will go high if the eRIC receives:
 * * Its own serial number
 * * Its own serial number followed by a '1'
 * Or if the altitude limit is exceeded
 *
 * FIRE will only go low again if the eRIC receives:
 * * Its own serial number followed by a '0'
 * or if the eRIC is reset
 *
 * The altitude limit can be set via a radio packet if the cut-down receives its own serial number followed by "2xy"
 * where x is the 10km altitude limit and y is the 1km altitude limit.
 * I.e. the pyro will fire at xy000 metres
 * Setting the altitude to 99km will disable the CAM_M8 (to save power)
 *
 */

#define GNSS_LOW_POWER // Uncomment this line to enable GNSS low power mode
#define eRIC_RX_POWER // Uncomment this line to enable eRIC RX power saving
//#define TEST_ALT // Uncomment this line to set the altitude limit to TEST_ALT_LIM (and ignore the eeprom values)

#include <cc430f5137.h>
#include "eRIC.h"
#include <stdio.h>
#include <string.h>
#include "sprint_float.h"
#include "tinygps.h"
#include "LPRS_UART.h"
#include "ubx.h"

// Choose module type to ensure correct frequency selections
#define eRIC4
//#define eRIC9

// Pin definitions
#define CAM_M8_On() Pin15_SetLow()
#define CAM_M8_Off() Pin15_SetHigh()
#define LED_On() Pin16_SetHigh()
#define LED_Off() Pin16_SetLow()
#define LED_Toggle() Pin16_Toggle()

#define K10_Read() Pin3_Read()
#define K1_Read() Pin5_Read()
#define MINUS_Read() Pin4_Read()
#define PLUS_Read() Pin2_Read()

// Eeprom memory locations
#define PREFIX 128
#define ALT_LIM_10000 129
#define ALT_LIM_1000 130
#define CSUM 131

// Default values for eeprom
#define DEFAULT_ALT_10000 3 // Default altitude limit * 10km
#define DEFAULT_ALT_1000 3 // Default altitude limit * 1km
#define PREFIX_VAL 0xA5 // 10100101 binary - just a random value, the actual value is not significant
#define MAX_VAL_FIX 30 // Limit for valid GNSS fixes (used to put CAM-M8 into low power mode; allow 5 mins (30 * 10secs))

#define TEST_ALT_LIM 110.0f // Test altitude limit

// Limit the number of fires-at-altitude to this value
// This will allow the pyro output to be switched off (via radio) while still above the altitude limit
#define MAX_ALT_FIRES 3

// Globals
volatile unsigned char MySerial[] = {'0','0','0','0','0','0','0','0'}; // Storage for the eRIC serial number
volatile unsigned char RxData[] = {'F','F','F','F','F','F','F','F','F','F','F'}; /// Storage for received data
volatile unsigned char alt_lim_10000 = DEFAULT_ALT_10000; // GNSS Altitude Limit * 10km
volatile unsigned char alt_lim_1000 = DEFAULT_ALT_1000; // GNSS Altitude Limit * 1km
volatile unsigned char val_fix = 0; // How many valid fixes have been processed
volatile unsigned char ignore_GNSS = 0; // Flag to indicate if the GNSS should be ignored (powered down)
volatile unsigned char fires_at_altitude = 0; // How many times have we attempted to fire the pyro above altitude limit

// Main

int main(void)
{
    // Disable WDT and interrupts

    eRIC_WDT_Stop(); // Disable WDT
    eRIC_GlobalInterruptDisable(); // Global interrupts disabled

    // Initialise FIRE NOR gate power and signals
    // For FIRE to be high:
    // Pin 17 must be high (provides power to NOR gate)
    // Pin 18 must be high
    // Pin 19 must be low

    Pin19_SetHigh(); // Disable FIRE (before pin is changed to output)
    Pin19_SetAsOutput(); // Set Pin19 as Output to drive FIRE NOR gate
    Pin19_SetHigh(); // Disable FIRE

    Pin18_SetLow(); // Disable FIRE (before pin is changed to output)
    Pin18_SetAsOutput(); // Set Pin18 as Output to drive FIRE NOR gate (inverted)
    Pin18_SetLow(); // Disable FIRE

    Pin17_SetAsOutput(); // Set Pin17 as Output to provide power for FIRE NOR gate
    Pin17_SetHigh(); // Enable NOR gate

    // Set up the eRIC

#ifdef eRIC4
    // eRIC4
    eROS_Initialise(434000000);       // eROS initialised at 434MHz
#else
    // eRIC9
    Pin14_SetAsInput(); // Pin14 is set as input for swapping frequency
    Pin14_PullUpEnable(); // Enable pull-up on Pin14
    if(Pin14_Read()) // If Pin14 is open
    {
        eROS_Initialise(869750000);       //eROS initilaised at 869.75MHz
    }
    else // Pin14 is shorted to GND
    {
        eROS_Initialise(915000000);       //eROS initilaised at 915.00MHz
    }
#endif

    eRIC_SetCpuFrequency(1048576); // Set CPU clock speed to 1.048576MHz. LPRS recommend this is done *after* eROS_Initialise

    unsigned char i = 0;
    while(i < 11) // Make sure RxData is clear
    {
        RxData[i++] = 'F';
    }

    eRIC_RfDataReceivedInterruptEnable(); // Enable Rf Data Rx interrupts
    eRIC_GlobalInterruptEnable(); // Enable interrupts

    eRIC_Rx_Enable(); // Enable receiver
    eRIC_ChannelSpacing = 100000; // Set channel spacing to 100kHz
    eRIC_Channel = 5; // Set channel 5
    eRIC_RfBaudRate = 1200; // Set over air baud rate to 1200
    eRIC_Power = 0; // Set transmit power to 0dBm
    eRIC_TxPowerLevel = 2; // Set Tx power saving (increases preamble length)
    eRIC_RadioUpdate(); // Update the settings

    // Set up the I/O pins

    // ADC for bus voltage
    // The voltage on Pin1 is the bus divided by 4.3
    Pin1_InterruptDisable(); // Make sure Pin 1 cannot interrupt (redundant?)
    Pin1_FunctionNone(); // (redundant?)
    Pin1_FunctionA2D(); // Set Pin1 as ADC to read bus voltage
    eRIC_SetAdcPin(1); //Set Pin1 as ADC
    eRIC_SetAdcRefVoltage(eRICADCRef_2_5v,0); // Set reference to 2.5V

    Pin2_FunctionNone(); // (redundant?)
    Pin2_FunctionIO(); // (redundant?)
    Pin2_SetAsInput(); // Set Pin2 as Input for the PLUS switch
    Pin2_PullUpEnable(); // Enable pull-up on Pin2

    Pin3_FunctionNone(); // (redundant?)
    Pin3_FunctionIO(); // (redundant?)
    Pin3_SetAsInput(); // Set Pin3 as Input for the 10K switch
    Pin3_PullUpEnable(); // Enable pull-up on Pin3

    Pin4_FunctionNone(); // (redundant?)
    Pin4_FunctionIO(); // (redundant?)
    Pin4_SetAsInput(); // Set Pin4 as Input for the MINUS switch
    Pin4_PullUpEnable(); // Enable pull-up on Pin4

    Pin5_FunctionNone(); // (redundant?)
    Pin5_FunctionIO(); // (redundant?)
    Pin5_SetAsInput(); // Set Pin5 as Input for the 1K switch
    Pin5_PullUpEnable(); // Enable pull-up on Pin5

    Pin15_FunctionNone(); // (redundant?)
    Pin15_FunctionIO(); // (redundant?)
    Pin15_SetAsOutput(); // Set Pin15 as Output to enable 3.3V for the CAM_M8
    CAM_M8_Off(); // Disable the CAM_M8

    Pin16_FunctionNone(); // (redundant?)
    Pin16_FunctionIO(); // (redundant?)
    Pin16_SetAsOutput(); // Set Pin16 as Output to drive LED
    LED_Off(); // Disable LED

    Pin20_FunctionNone(); // (redundant?)
    Pin20_FunctionUartARxD(); // Make Pin20 UART RxD for serial data from the CAM_M8

    Pin21_FunctionNone(); // (redundant?)
    Pin21_FunctionUartATxOUT() // Make Pin15 UART TxD for serial data to the CAM_M8

    Pin22_FunctionNone(); // Pin22 is unused

    // Record switch state at reset (to see if we need to set the altitude limit)
    unsigned char switch_state = 0;
    if (PLUS_Read() == 0) switch_state |= 0x01; // Read plus switch
    if (MINUS_Read() == 0) switch_state |= 0x02; // Read minus switch
    if (K10_Read() == 0) switch_state |= 0x04; // Read the 10K switch
    if (K1_Read() == 0) switch_state |= 0x08; // Read the 1K switch

    // Initialise eeprom values if required
    // First read the values
    unsigned char eeprom_prefix = eRIC_Eeprom_Read(PREFIX); // Read prefix from eeprom
    unsigned char eeprom_alt_lim_10000 = eRIC_Eeprom_Read(ALT_LIM_10000); // Read 10km altitude limit from eeprom
    unsigned char eeprom_alt_lim_1000 = eRIC_Eeprom_Read(ALT_LIM_1000); // Read 1km altitude limit from eeprom
    unsigned char eeprom_csum = eRIC_Eeprom_Read(CSUM); // Read checksum from eeprom
    // Check the checksum
    unsigned int csum = eeprom_prefix + eeprom_alt_lim_10000 + eeprom_alt_lim_1000;
    // Check if data is valid
    csum = csum & 0xFF; // Limit checksum to 8 bits
    // Check if the eeprom data is valid (check if the prefix and checksum both match)
    if ((eeprom_prefix != PREFIX_VAL) || ((unsigned char)csum != eeprom_csum))
    {
        // eeprom data is invalid so initialise it
        alt_lim_10000 = DEFAULT_ALT_10000; // Initialise the 10km altitude limit
        alt_lim_1000 = DEFAULT_ALT_1000; // Initialise the 1km altitude limit
        eRIC_Eeprom_Write(PREFIX, PREFIX_VAL); // Initialise the eeprom prefix
        eRIC_Eeprom_Write(ALT_LIM_10000, DEFAULT_ALT_10000); // Initialise the eeprom 10km altitude limit
        eRIC_Eeprom_Write(ALT_LIM_1000, DEFAULT_ALT_1000); // Initialise the eeprom 1km altitude limit
        csum = PREFIX_VAL + DEFAULT_ALT_10000 + DEFAULT_ALT_1000; // Calculate the checksum
        csum = csum & 0xFF; // Limit checksum to 8 bits
        eRIC_Eeprom_Write(CSUM, (unsigned char)csum); // Initialise the eeprom checksum
    }
    else
    {
        // eeprom data is valid so use it
        alt_lim_10000 = eeprom_alt_lim_10000; // Use the 10km altitude limit from eeprom
        alt_lim_1000 = eeprom_alt_lim_1000; // Use the 1km altitude limit from eeprom
    }

    // Check if (only) the plus switch was pressed on reset (to see if we need to set the altitude limits)
    // If so, change and store the altitude limits in eeprom, and wait for reset
    if (switch_state == 0x01) // Check if plus bit was low
    {
        while (PLUS_Read() == 0) ; // Wait for switch to be released

        unsigned char alt_val = 3; // Initial value for the altitude limit

        while (1) // Keep doing this until reset
        {
            i = 0;
            unsigned char flash_state = alt_val * 4; // Use alt_val * 4 to control 100msec LED flashing
            switch_state = 0x00; // Clear the record of the switch state
            while (i < flash_state) // Flash the LED alt_val times while monitoring for switch presses
            {
                // Record switch state to see if we need to change or set the altitude limit
                if (PLUS_Read() == 0) switch_state |= 0x01; // Keep a record of whether plus switch has been pressed
                if (MINUS_Read() == 0) switch_state |= 0x02; // Keep a record of whether minus switch has been pressed
                if (K10_Read() == 0) switch_state |= 0x04; // Keep a record of whether 10K switch has been pressed
                if (K1_Read() == 0) switch_state |= 0x08; // Keep a record of whether 1K switch has been pressed
                if (switch_state != 0x00) // If any switch is pressed
                {
                    i = flash_state; // Stop flashing if any switch has been pressed
                    break;
                }
                if ((i % 4) < 2) // Flash the LED on for two 100msec periods, then off for two 100msec periods
                {
                    LED_On();
                }
                else
                {
                    LED_Off();
                }
                eRIC_Delay(100); // Delay (BLOCKING!)
                i++;
            }
            LED_Off(); // Make sure LED is off
            i = 0;
            while (i < 10) // Keep LED off for one second while monitoring switches (every 100msec)
            {
                // Record switch state to see if we need to change or set the altitude limit
                if (PLUS_Read() == 0) switch_state |= 0x01; // Keep a record of whether plus switch has been pressed
                if (MINUS_Read() == 0) switch_state |= 0x02; // Keep a record of whether minus switch has been pressed
                if (K10_Read() == 0) switch_state |= 0x04; // Keep a record of whether 10K switch has been pressed
                if (K1_Read() == 0) switch_state |= 0x08; // Keep a record of whether 1K switch has been pressed
                if (switch_state != 0x00) // If any switch is pressed
                {
                    i = 10; // Stop flashing if any switch has been pressed
                    break;
                }
                eRIC_Delay(100); // Delay (BLOCKING!)
                i++;
            }
            if (switch_state == 0x01) // If only the plus switch was pressed
            {
                if (alt_val < 9) // Limit alt_val to 9
                {
                    alt_val = alt_val + 1; // Increase alt_val by one
                }
            }
            else if (switch_state == 0x02) // If only the minus switch was pressed
            {
                if (alt_val > 0) // Do not allow alt_val to go negative
                {
                    alt_val = alt_val - 1; // Decrease alt_val by one
                }
            }
            else if (switch_state == 0x04) // If only the 10K switch was pressed
            {
                // Update alt_lim_10000 and write to eeprom
                alt_lim_10000 = alt_val;

                eRIC_Eeprom_Write(PREFIX, PREFIX_VAL); // Update the eeprom prefix
                eRIC_Eeprom_Write(ALT_LIM_10000, alt_lim_10000); // Update the eeprom 10km altitude limit
                eRIC_Eeprom_Write(ALT_LIM_1000, alt_lim_1000); // Update the eeprom 1km altitude limit
                csum = PREFIX_VAL + alt_lim_10000 + alt_lim_1000; // Calculate the checksum
                csum = csum & 0xFF; // Limit checksum to 8 bits
                eRIC_Eeprom_Write(CSUM, (unsigned char)csum); // Update the eeprom checksum
                // Flash the LED to show data has been written to eeprom
                LED_On();
                eRIC_Delay(2000);
                LED_Off();
                eRIC_Delay(1000);
            }
            else if (switch_state == 0x08) // If only the 1K switch was pressed
            {
                // Update alt_lim_1000 and write to eeprom
                alt_lim_1000 = alt_val;

                eRIC_Eeprom_Write(PREFIX, PREFIX_VAL); // Update the eeprom prefix
                eRIC_Eeprom_Write(ALT_LIM_10000, alt_lim_10000); // Update the eeprom 10km altitude limit
                eRIC_Eeprom_Write(ALT_LIM_1000, alt_lim_1000); // Update the eeprom 1km altitude limit
                csum = PREFIX_VAL + alt_lim_10000 + alt_lim_1000; // Calculate the checksum
                csum = csum & 0xFF; // Limit checksum to 8 bits
                eRIC_Eeprom_Write(CSUM, (unsigned char)csum); // Update the eeprom checksum
                // Flash the LED to show data has been written to eeprom
                LED_On();
                eRIC_Delay(2000);
                LED_Off();
                eRIC_Delay(1000);
            }
            if (switch_state > 0) // If any switch was pressed, wait for it to be released
            {
                while (switch_state > 0)
                {
                    switch_state = 0;
                    if (PLUS_Read() == 0) switch_state |= 0x01; // Keep a record of whether plus switch has been pressed
                    if (MINUS_Read() == 0) switch_state |= 0x02; // Keep a record of whether minus switch has been pressed
                    if (K10_Read() == 0) switch_state |= 0x04; // Keep a record of whether 10K switch has been pressed
                    if (K1_Read() == 0) switch_state |= 0x08; // Keep a record of whether 1K switch has been pressed
                }
            }
        }
    }


    // Flash the LED to show altitude limit
    i = 0;
    if (alt_lim_10000 > 0) // Is the 10km altitude limit > 0 ?
    {
        while (i < alt_lim_10000) // If so, flash the LED alt_lim times
        {
            LED_On();
            eRIC_Delay(200);
            LED_Off();
            eRIC_Delay(200);
            i++;
        }
    }
    else
    {
        LED_On(); // Replace zero with a long flash
        eRIC_Delay(2000);
        LED_Off();
    }
    eRIC_Delay(1000); // Pause for 1 sec
    i = 0;
    if (alt_lim_1000 > 0) // Is the 1km altitude limit > 0 ?
    {
        while (i < alt_lim_1000) // If so, now flash the LED alt_lim times
        {
            LED_On();
            eRIC_Delay(200);
            LED_Off();
            eRIC_Delay(200);
            i++;
        }
    }
    else
    {
        LED_On(); // Replace zero with a long flash
        eRIC_Delay(2000);
        LED_Off();
    }

    // Put the eRIC into RX power saving if required now that eeprom access is complete
#ifdef eRIC_RX_POWER
    eRIC_RxPowerLevel = 2; // Set Rx power saving (reduces receiver duty cycle)
    eRIC_RadioUpdate(); // Update the settings
    eRIC_Delay(1000);
#endif

    // Get the eRIC serial number and transmit it together with the altitude limit

    eRIC_RadioTx_BuffCount = 0; // Reset the Tx buffer counter
    unsigned long sernum = eRIC_GetSerialNumber(); // Get the eRIC serial number
    unsigned char nibble = (unsigned char)((sernum >> 28) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)((sernum >> 24) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)((sernum >> 20) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)((sernum >> 16) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)((sernum >> 12) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)((sernum >> 8) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)((sernum >> 4) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)(sernum & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter

    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = ' '; // Add a space to Tx buffer
    nibble = (alt_lim_10000 & 0x0F) + '0'; // Add alt_lim_10000 to the buffer
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (alt_lim_1000 & 0x0F) + '0'; // Add alt_lim_1000 to the buffer
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = '0'; // Add a zero to Tx buffer
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = '0'; // Add a zero to Tx buffer
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = '0'; // Add a zero to Tx buffer
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = 'm'; // Add 'm' to Tx buffer
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = 0x0A; // Add a new line character to Tx buffer

    eRIC_RfSenddata(); // Transmit the serial number
    while(eRIC_RadioTx_BuffCount); // Wait for Tx to finish (eRIC_RfSenddata resets eRIC_RadioTx_BuffCount to zero when complete)

    // Check if the altitude limit has been set to 99km. If it has, set ignore_GNSS to 1
    ignore_GNSS = 0;
    if ((alt_lim_10000 == 9) && (alt_lim_1000 == 9))
    {
        ignore_GNSS = 1;
    }

    // Initialise the UART and TinyGPS so both are ready now or later
    UARTinit();
    gps_init();

    if (!ignore_GNSS) // Check if we are ignoring the GNSS
    {
        // Power up the CAM_M8
        CAM_M8_On(); // Enable the CAM_M8
        eRIC_Delay(2000); // Let the CAM_M8 power up

        // Initialise the M8 by clearing the stored configuration and then loading it
        sendUBX(clearConf, len_Conf); // Clear stored configuration
        eRIC_Delay(100);
        sendUBX(loadConf, len_Conf); // Load configuration
        eRIC_Delay(2100);

        // Disable all GNSS NMEA messages
        UART_Println("$PUBX,40,GLL,0,0,0,0*5C"); // Disable GLL
        eRIC_Delay(100);
        UART_Println("$PUBX,40,ZDA,0,0,0,0*44"); // Disable ZDA
        eRIC_Delay(100);
        UART_Println("$PUBX,40,VTG,0,0,0,0*5E"); // Disable VTG
        eRIC_Delay(100);
        UART_Println("$PUBX,40,GSV,0,0,0,0*59"); // Disable GSV
        eRIC_Delay(100);
        UART_Println("$PUBX,40,GSA,0,0,0,0*4E"); // Disable GSA
        eRIC_Delay(100);
        UART_Println("$PUBX,40,RMC,0,0,0,0*47"); // Disable RMC
        eRIC_Delay(100);
        //UART_Println("$PUBX,40,GGA,0,1,0,0*5B"); // Send GGA every 1 seconds
        //UART_Println("$PUBX,40,GGA,0,2,0,0*58"); // Send GGA every 2 seconds
        //UART_Println("$PUBX,40,GGA,0,5,0,0*5F"); // Send GGA every 5 seconds
        UART_Println("$PUBX,40,GGA,0,10,0,0*6B"); // Send GGA every 10 seconds
        eRIC_Delay(100);
        sendUBX(disableTimePulse, len_setTimePulse); // Disable Time Pulse
        eRIC_Delay(100);
        sendUBX(setNavAir, len_setNav); // Set Airborne <1G Navigation Mode
        eRIC_Delay(100);
        sendUBX(setNMEA, len_setNMEA); // Set NMEA configuration (use GP prefix instead of GN otherwise parsing will fail)
        eRIC_Delay(100);
        sendUBX(setGNSS, len_setGNSS); // Set GNSS - causes a reset of the M8!
        eRIC_Delay(3100);

        // Clear the UART Rx buffer to erase ubx acknowledgements
        UARTclearRxBuffer();

        fires_at_altitude = 0; // Make sure fires_at_altitude is initialised
        val_fix = 0; // Make sure the number of valid fixes is initialised
    }


    // Enter the actual main loop

    while(1) // Loop continuously
    {
        // Compare RxData to MySerial, check for a match
        // If the data matches, enable or disable FIRE as required
        volatile int match = 1; // Flag to indicate a match. Initialise as true.
        // First check for the eRIC serial number on its own
        i = 0;
        while(i < 8) // For each of the eight bytes
        {
            if (RxData[i+3] != MySerial[i]) // If the data does not match (include 3 char offset)
            {
                match = 0; // Clear the flag
                break; // Exit the while loop
            }
            i++;
        }
        if (match) // If the data matches, enable FIRE
        {
            Pin19_SetLow(); // Enable FIRE
            Pin18_SetHigh();
            i = 0;
            while(i < 11) // Clear RxData
            {
                RxData[i++] = 'F';
            }
        }
        // Next check for the eRIC serial number followed by '0' or '1'
        match = 1;
        i = 0;
        while(i < 8) // For each of the eight bytes
        {
            if (RxData[i+2] != MySerial[i]) // If the data does not match
            {
                match = 0; // Clear the flag
                break; // Exit the while loop
            }
            i++;
        }
        if (match) // If the serial number matches
        {
            if (RxData[10] == '1') // Check for a following '1'
            {
                Pin19_SetLow(); // Enable FIRE
                Pin18_SetHigh();
            }
            if (RxData[10] == '0') // Check for a following '0'
            {
                Pin19_SetHigh(); // Disable FIRE
                Pin18_SetLow();
            }
            i = 0;
            while(i<11) // Clear RxData since we found a match
            {
                RxData[i++] = 'F';
            }
        }
        // Now check for the eRIC serial number followed by "2" and the altitude limit
        match = 1;
        i = 0;
        while(i < 8) // For each of the eight bytes
        {
            if (RxData[i] != MySerial[i]) // If the data does not match
            {
                match = 0; // Clear the flag
                break; // Exit the while loop
            }
            i++;
        }
        if (match) // If the data matches, check for "2" followed by two 0-9 digits
        {
            if (RxData[8] == '2') // Check for a following '2'
            {
                // Check that "00" to "99" follows
                if (((RxData[9] >= '0') && (RxData[9] <= '9')) && ((RxData[10] >= '0') && (RxData[10] <= '9')))
                {
                    // Disable Rx power saving to allow eeprom writes
                    eRIC_RxPowerLevel = 0; // Disable Rx power saving (enables eeprom writes)
                    eRIC_RadioUpdate(); // Update the settings
                    // Update alt_lim_10000 and alt_lim_1000 and write to eeprom
                    alt_lim_10000 = RxData[9] - '0';
                    alt_lim_1000 = RxData[10] - '0';
                    eRIC_Eeprom_Write(PREFIX, PREFIX_VAL); // Update the eeprom prefix
                    eRIC_Eeprom_Write(ALT_LIM_10000, alt_lim_10000); // Update the eeprom 10km altitude limit
                    eRIC_Eeprom_Write(ALT_LIM_1000, alt_lim_1000); // Update the eeprom 1km altitude limit
                    csum = PREFIX_VAL + alt_lim_10000 + alt_lim_1000; // Calculate the checksum
                    csum = csum & 0xFF; // Limit checksum to 8 bits
                    eRIC_Eeprom_Write(CSUM, (unsigned char)csum); // Update the eeprom checksum
                    // Re-enable Rx power saving
#ifdef eRIC_RX_POWER
                    eRIC_RxPowerLevel = 2; // Set Rx power saving (reduces receiver duty cycle and disables eeprom writes)
                    eRIC_RadioUpdate(); // Update the settings
#endif
                    // Check if a new altitude limit of 99km was received
                    // If it was, disable the GNSS
                    if ((alt_lim_10000 == 9) && (alt_lim_1000 == 9))
                    {
                        CAM_M8_Off();
                        ignore_GNSS = 1;
                    }
                    else if (ignore_GNSS == 1)
                        // If the new altitude limit is not 99km and ignore_GNSS is already set
                        // then (re)start the CAM_M8
                    {
                        // Power up the CAM_M8
                        CAM_M8_On(); // Enable the CAM_M8
                        eRIC_Delay(2000); // Let the CAM_M8 power up

                        // Initialise the M8 by clearing the stored configuration and then loading it
                        sendUBX(clearConf, len_Conf); // Clear stored configuration
                        eRIC_Delay(100);
                        sendUBX(loadConf, len_Conf); // Load configuration
                        eRIC_Delay(2100);

                        // Disable all GNSS NMEA messages
                        UART_Println("$PUBX,40,GLL,0,0,0,0*5C"); // Disable GLL
                        eRIC_Delay(100);
                        UART_Println("$PUBX,40,ZDA,0,0,0,0*44"); // Disable ZDA
                        eRIC_Delay(100);
                        UART_Println("$PUBX,40,VTG,0,0,0,0*5E"); // Disable VTG
                        eRIC_Delay(100);
                        UART_Println("$PUBX,40,GSV,0,0,0,0*59"); // Disable GSV
                        eRIC_Delay(100);
                        UART_Println("$PUBX,40,GSA,0,0,0,0*4E"); // Disable GSA
                        eRIC_Delay(100);
                        UART_Println("$PUBX,40,RMC,0,0,0,0*47"); // Disable RMC
                        eRIC_Delay(100);
                        //UART_Println("$PUBX,40,GGA,0,1,0,0*5B"); // Send GGA every 1 seconds
                        //UART_Println("$PUBX,40,GGA,0,2,0,0*58"); // Send GGA every 2 seconds
                        //UART_Println("$PUBX,40,GGA,0,5,0,0*5F"); // Send GGA every 5 seconds
                        UART_Println("$PUBX,40,GGA,0,10,0,0*6B"); // Send GGA every 10 seconds
                        eRIC_Delay(100);
                        sendUBX(disableTimePulse, len_setTimePulse); // Disable Time Pulse
                        eRIC_Delay(100);
                        sendUBX(setNavAir, len_setNav); // Set Airborne <1G Navigation Mode
                        eRIC_Delay(100);
                        sendUBX(setNMEA, len_setNMEA); // Set NMEA configuration (use GP prefix instead of GN otherwise parsing will fail)
                        eRIC_Delay(100);
                        sendUBX(setGNSS, len_setGNSS); // Set GNSS - causes a reset of the M8!
                        eRIC_Delay(3100);

                        // Clear the UART Rx buffer to erase ubx acknowledgements which would confuse TinyGPS
                        UARTclearRxBuffer();

                        fires_at_altitude = 0; // Make sure fires_at_altitude is initialised
                        val_fix = 0; // Make sure the number of valid fixes is initialised
                        ignore_GNSS = 0; // Clear ignore_GNSS
                    }
                }
            }
            i = 0;
            while(i < 11) // Clear RxData
            {
                RxData[i++] = 'F';
            }
        }


        if (!ignore_GNSS)
        {
            // Encode the serial data from the GNSS
            if(UARTavailable()) // If a character is available
            {
                if(gps_encode(UARTreadRx())) // Encode the character and check if sentence is valid
                {
                    LED_On(); // Flash the LED while processing a new NMEA sentence

                    // If the GNSS sentence is valid
#ifdef GNSS_LOW_POWER
                    if (val_fix == MAX_VAL_FIX) // Check if val_fix has reached MAX_VAL_FIX
                    {
                        // Put CAM_M8 into low power mode
                        // Only do this once, when val_fix == MAX_VAL_FIX
                        sendUBX(confPowerBalanced, len_confPower); // Configure low power mode
                        eRIC_Delay(100); // Wait
                        sendUBX(setLP, len_setLP); // Put CAM_M8 into low power mode
                        eRIC_Delay(1100); // Wait
                        sendUBX(saveConf, len_Conf); // Save configuration
                        eRIC_Delay(1100);
                        UARTclearRxBuffer(); // Clear the UART Rx buffer to erase ubx acknowledgements
                    }
#endif
                    if (val_fix <= MAX_VAL_FIX) // Increment val_fix now that we have a valid sentence
                    {
                        val_fix++; // val_fix will increase until it reaches MAX_VAL_FIX + 1
                    }

                    float gps_alt = gps_f_altitude(); // Get the GNSS altitude
#ifndef TEST_ALT
                    float alt_limit = ((float)alt_lim_10000) * 10000.0f; // Calculate the altitude limit
                    alt_limit = alt_limit + (((float)alt_lim_1000) * 1000.0f);
#else
                    float alt_limit = TEST_ALT_LIM; // Use the test altitude limit
#endif

                    if (gps_alt > alt_limit) // Has the altitude limit been reached?
                    {
                        if (fires_at_altitude < MAX_ALT_FIRES) // Only attempt to fire the pyro this many times
                        {
                            // altitude limit has been reached so enable FIRE
                            Pin19_SetLow(); // Enable FIRE
                            Pin18_SetHigh();
                            fires_at_altitude++; // Increment the number of attempts
                        }
                    }

                    LED_Off(); // Stop flashing LED
                }
            }
        }
    }
}// End of main

void eRIC_RfDataReceivedInterrupt() // Deal with available received data. This is triggered when interrupt is enabled and a packet is received
{
    while(eRIC_Rxdata_available)
    {
        // Add the received character to RxData
        // Use RxData as a FIFO:
        //   shuffle each character along by one
        //   overwrite the oldest character in RxData[0]
        //   store the new character to RxData[10]
        unsigned int ii = 0;
        while(ii < 10)
        {
            RxData[ii] = RxData[ii+1]; // Shuffle each character along by one
            ii++;
        }
        RxData[10] = eRIC_ReadRfByte(); // Store the new character in RxData[10]
    }
}

