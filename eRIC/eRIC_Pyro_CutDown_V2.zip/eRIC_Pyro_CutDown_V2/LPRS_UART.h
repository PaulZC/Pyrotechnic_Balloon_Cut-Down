/*
 * LPRS_UART.h
 *
 *  Interrupt service routine copied from eRICxeasyRadioV1.5.5
 *
 *  Some functions borrowed from Arduino core RingBuffer.h
 */

#ifndef LPRS_UART_H_
#define LPRS_UART_H_

void UARTinit();
int UARTisRxBufferFull();
int UARTavailable();
char UARTreadRx();
void UARTclearRxBuffer();

void UART_Println(char *message);

#endif /* LPRS_UART_H_ */
