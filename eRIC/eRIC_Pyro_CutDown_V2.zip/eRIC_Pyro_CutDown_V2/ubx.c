#include <cc430f5137.h>
#include "eRIC.h"
#include "ubx.h"

// Send message in u-blox UBX format
// Calculates and appends the two checksum bytes
// Doesn't add the 0xb5 and 0x62 sync chars (these need to be included at the start of the message)
// BLOCKING!! Will stall while UART transmit is busy
void sendUBX(const unsigned char *message, const unsigned char len)
{
  unsigned int csum1 = 0; // Checksum bytes
  unsigned int csum2 = 0;
  unsigned char j;
  for (j=0; j<len; j++) { // For each byte in the message
    while (!(UCA0IFG & UCTXIFG)); //while(eRIC_UartATxBufferIsBusy());
    UCA0TXBUF = message[j]; //eRIC_UartASendByte(txt[i]);
    if (j >= 2) { // Don't include the sync chars in the checksum
      csum1 = csum1 + message[j]; // Update the checksum bytes
      csum2 = csum2 + csum1;
    }
  }
  csum1 = csum1 & 0xff; // Limit checksums to 8-bits
  csum2 = csum2 & 0xff;
  while (!(UCA0IFG & UCTXIFG)); //while(eRIC_UartATxBufferIsBusy());
  UCA0TXBUF = (unsigned char)csum1; // Send the checksum bytes
  while (!(UCA0IFG & UCTXIFG)); //while(eRIC_UartATxBufferIsBusy());
  UCA0TXBUF = (unsigned char)csum2;
}
