/*
 * LPRS_UART.c
 *
 *  Interrupt service routine copied from eRICxeasyRadioV1.5.5
 *
 *  Some functions borrowed from Arduino core RingBuffer.h
 */

#include <cc430f5137.h>
#include "LPRS_UART.h"
#include "eRIC.h"

char UART_RX_Buffer[256];
volatile unsigned char UART_RX_Ptr_In;
volatile unsigned char UART_RX_Ptr_Out;

void UART_Println(char *message)
// Send a serial message, avoiding the null terminator, followed by CR+LF
// (eRIC_Stringlength actually returns the length + 1)
{
    unsigned char length = eRIC_Stringlength(message);
    unsigned char i = 0;
    if (length > 1)
    {
        for (i = 0; i < (length - 1); i++)
        {
            while (!(UCA0IFG & UCTXIFG)); //while(eRIC_UartATxBufferIsBusy());
            UCA0TXBUF = message[i]; //eRIC_UartASendByte(txt[i]);
        }
    }
    while (!(UCA0IFG & UCTXIFG)); //while(eRIC_UartATxBufferIsBusy());
    UCA0TXBUF = 0x0D; // Send the CR
    while (!(UCA0IFG & UCTXIFG)); //while(eRIC_UartATxBufferIsBusy());
    UCA0TXBUF = 0x0A; // Send the LF
}

void UARTinit()
{
    UART_RX_Ptr_In = 0; // Initialise the RX buffer pointers
    UART_RX_Ptr_Out = 0;

    eRIC_UARTAInitialise(9600); // Initialise the UART at 9600 baud
    eRIC_UartARxInteruptEnable(); // Enable the UART Rx interrupt
}

void UARTclearRxBuffer()
{
    UART_RX_Ptr_Out = UART_RX_Ptr_In; // 'Clear' the buffer by making the pointers equal
}

int UARTisRxBufferFull()
// Return true if the Rx buffer is full
// I.e. if the In pointer is one less than the Out pointer
{
    if (UART_RX_Ptr_Out == 0)
    {
        if (UART_RX_Ptr_In == 255)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    if (UART_RX_Ptr_Out == UART_RX_Ptr_In + 1)
    {
        return 1;
    }
    return 0;
}

int UARTavailable()
// Return true if a character is available in the Rx buffer
// I.e. if the In and Out pointers are not equal
{
    if (UART_RX_Ptr_In == UART_RX_Ptr_Out)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

char UARTreadRx()
// Read a character from the Rx buffer
{
    return UART_RX_Buffer[UART_RX_Ptr_Out++];
}

// UART Interrupt Vector
#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
{
    volatile unsigned int function = UCA0IV; // Read Interrupt Vector triggered
    switch(function)
    {
    case USCI_NONE: // Vector 0 - no interrupt
        break;
    case USCI_UCRXIFG: // Vector 2 - RXIFG UART RECEIVE
        if (!UARTisRxBufferFull()) // If buffer is not full
        {
            UART_RX_Buffer[UART_RX_Ptr_In++] = eRIC_UartAReceiveByte(); // Add received character to the Rx buffer
        }
        else
        {
            char c = eRIC_UartAReceiveByte(); // Eat received character (redundant?)
        }
        break;
    case USCI_UCTXIFG:                   // Vector 4 - TXIFG
        // Update this at some point to provide interrupt-driven transmit
        break;
    default:
        break;
    }
}

