#include <cc430f5137.h>
#include "eRIC.h"
#include "sprint_float.h"

// This function is sprintf-like
// Based on LPRS' eRIC_Sprintf but adapted to handle floats
// Uses a sledgehammer-to-crack-a-wallnut approach...
// Could do with a little finessing!
// Returns the number of characters printed
// Will only handle floats less than 10,000,000
// and with up to three decimal places
unsigned char sprint_float(char *buffer, char *string, float value)
{
    unsigned char StringLength = eRIC_Stringlength(string);
    unsigned char i = 0, j = 0;
    float copy = value;
    if (copy >= 10000000.0f) // Ignore values >= 10,000,000
    {
        copy = 9999999.9f;
    }
    for (i = 0; i < StringLength; i++)
    {
        if (string[i] == '%') //if special vals then parse here
        {
            i++;
            switch (string[i])
            {
                case 'f':
                {
                    int digit = 0;
                    char c;
                    int fds = 0; // First digit seen
                    if (copy < 0) // Is value < zero?
                    {
                        buffer[j++] = '-'; // If it is, include a minus sign
                        copy = 0 - copy; // Make the copy positive
                    }
                    if (copy >= 1000000.0f) // Is copy greater than this?
                    {
                        digit = (int)(copy / 1000000.0f); // If it is, get the digit
                        c = (char)(digit + '0'); // Convert digit into a character
                        buffer[j++] = c; // Store it in the buffer
                        copy = copy - ((float)digit * 1000000.0f); // Subtract
                        fds = 1; // Set fds to true
                    }
                    if (copy >= 100000.0f) // Is copy greater than this?
                    {
                        digit = (int)(copy / 100000.0f); // If it is, get the digit
                        c = (char)(digit + '0'); // Convert digit into a character
                        buffer[j++] = c; // Store it in the buffer
                        copy = copy - ((float)digit * 100000.0f); // Subtract
                        fds = 1; // Set fds to true
                    }
                    else
                    {
                        if(fds)
                        {
                            buffer[j++] = '0'; // Add a zero to the buffer
                        }
                    }
                    if (copy >= 10000.0f) // Is copy greater than this?
                    {
                        digit = (int)(copy / 10000.0f); // If it is, get the digit
                        c = (char)(digit + '0'); // Convert digit into a character
                        buffer[j++] = c; // Store it in the buffer
                        copy = copy - ((float)digit * 10000.0f); // Subtract
                        fds = 1; // Set fds to true
                    }
                    else
                    {
                        if(fds)
                        {
                            buffer[j++] = '0'; // Add a zero to the buffer
                        }
                    }
                    if (copy >= 1000.0f) // Is copy greater than this?
                    {
                        digit = (int)(copy / 1000.0f); // If it is, get the digit
                        c = (char)(digit + '0'); // Convert digit into a character
                        buffer[j++] = c; // Store it in the buffer
                        copy = copy - ((float)digit * 1000.0f); // Subtract
                        fds = 1; // Set fds to true
                    }
                    else
                    {
                        if(fds)
                        {
                            buffer[j++] = '0'; // Add a zero to the buffer
                        }
                    }
                    if (copy >= 100.0f) // Is copy greater than this?
                    {
                        digit = (int)(copy / 100.0f); // If it is, get the digit
                        c = (char)(digit + '0'); // Convert digit into a character
                        buffer[j++] = c; // Store it in the buffer
                        copy = copy - ((float)digit * 100.0); // Subtract
                        fds = 1; // Set fds to true
                    }
                    else
                    {
                        if(fds)
                        {
                            buffer[j++] = '0'; // Add a zero to the buffer
                        }
                    }
                    if (copy >= 10.0f) // Is copy greater than this?
                    {
                        digit = (int)(copy / 10.0f); // If it is, get the digit
                        c = (char)(digit + '0'); // Convert digit into a character
                        buffer[j++] = c; // Store it in the buffer
                        copy = copy - ((float)digit * 10.0f); // Subtract
                        fds = 1; // Set fds to true
                    }
                    else
                    {
                        if(fds)
                        {
                            buffer[j++] = '0'; // Add a zero to the buffer
                        }
                    }
                    if (copy >= 1.0f) // Is copy greater than this?
                    {
                        digit = (int)(copy / 1.0f); // If it is, get the digit
                        c = (char)(digit + '0'); // Convert digit into a character
                        buffer[j++] = c; // Store it in the buffer
                        copy = copy - ((float)digit * 1.0f); // Subtract
                    }
                    else
                    {
                        buffer[j++] = '0'; // Always add a zero to the buffer
                    }
                    buffer[j++] = '.'; // Store the decimal point
                    if (copy >= 0.001f) // Have we got anything in the three decimal places?
                    {
                        copy = copy * 1000.0f; // Multiply by 1000 to reveal decimal places
                        if (copy >= 100.0f) // Is copy greater than this?
                        {
                            digit = (int)(copy / 100.0f); // If it is, get the digit
                            c = (char)(digit + '0'); // Convert digit into a character
                            buffer[j++] = c; // Store it in the buffer
                            copy = copy - ((float)digit * 100.0f); // Subtract
                        }
                        else
                        {
                            buffer[j++] = '0'; // Add a zero to the buffer
                        }
                        if (copy >= 10.0f) // Is copy greater than this?
                        {
                            digit = (int)(copy / 10.0f); // If it is, get the digit
                            c = (char)(digit + '0'); // Convert digit into a character
                            buffer[j++] = c; // Store it in the buffer
                            copy = copy - ((float)digit * 10.0f); // Subtract
                        }
                        else
                        {
                            buffer[j++] = '0'; // Add a zero to the buffer
                        }
                        if (copy >= 1.0f) // Is copy greater than this?
                        {
                            digit = (int)(copy / 1.0f); // If it is, get the digit
                            c = (char)(digit + '0'); // Convert digit into a character
                            buffer[j++] = c; // Store it in the buffer
                            copy = copy - ((float)digit * 1.0f); // Subtract
                        }
                    }
                    else
                    {
                        buffer[j++] = '0'; // Add a single decimal place zero to the buffer
                    }
                    break;
                }
            }
        }
        else
        {
            buffer[j++] = string[i]; // Copy text characters
        }
    }
    return j; // Return the number of characters printed
}

