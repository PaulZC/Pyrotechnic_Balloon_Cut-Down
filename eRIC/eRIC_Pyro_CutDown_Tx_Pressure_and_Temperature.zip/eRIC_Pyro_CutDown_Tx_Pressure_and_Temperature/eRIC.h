/********************************************************************
 *
 * lprs.co.uk
 *
 * Any thing Prefixed with eRIC_ can be used in the application and all other definitions
 * and variable are for internal eROS only.
 *
 */

//Version added in V1.5.4
//Version added in V1.5.5
#ifndef _eric_h
#define _eric_h


extern volatile unsigned char eRIC_Port2Busy;

extern volatile unsigned char eRIC_Port3Busy;

extern volatile unsigned long CommonPassedVariable;
extern volatile unsigned long CommonPassedVariable2; //All general variable passed through application into eROS
extern volatile unsigned long CommonPassedVariable3;

extern volatile unsigned long CommonReturnVariable;
extern unsigned char eRIC_RadioTx_Buffer[256];

extern volatile unsigned char Read_Rf_Byte;

extern volatile unsigned int DelayCycles;
extern volatile unsigned long eRIC_Frequency;
extern volatile signed char eRIC_Power;
extern volatile unsigned char eRIC_Channel;
extern volatile unsigned long eRIC_ChannelSpacing;
extern volatile unsigned long eRIC_RfBaudRate;
//extern volatile unsigned long CpuFrequency;

extern volatile unsigned long eRIC_CpuFrequency;

extern volatile char eRIC_RxPowerLevel;
extern volatile char eRIC_TxPowerLevel;

extern volatile unsigned char eRIC_RadioTx_BuffCount;
extern volatile unsigned char eRIC_Rxdata_available;

extern volatile unsigned char Eeprom_Address;
extern volatile unsigned char Eeprom_Data;

extern volatile unsigned int watch1;
extern volatile unsigned int watch1_type;
extern volatile unsigned int watch2;
extern volatile unsigned int watch2_type;
extern volatile unsigned int watch3;
extern volatile unsigned int watch3_type;
extern volatile unsigned int watch4;
extern volatile unsigned int watch4_type;
extern volatile unsigned int watch5;
extern volatile unsigned int watch5_type;
extern volatile unsigned int watch6;
extern volatile unsigned int watch6_type;
extern volatile unsigned int watch7;
extern volatile unsigned int watch7_type;
extern volatile unsigned int watch8;
extern volatile unsigned int watch8_type;
extern volatile unsigned int watch9;
extern volatile unsigned int watch9_type;
extern volatile unsigned int watch10;
extern volatile unsigned int watch10_type;

extern volatile unsigned char eRIC_Prog_Mode;

extern volatile unsigned int eRIC_GroupID;


extern unsigned int eRIC_FlagStatus;

extern volatile signed char eRIC_RSSI;
extern volatile signed char eRIC_PACKETRSSI;

extern volatile unsigned char eRIC_AES_Key[17];                        // from eROS V4.1

extern volatile unsigned char eRIC_AES_Data[16];                        // from eROS V4.1

extern volatile unsigned char eRIC_LPMLevel;   //V4.2

extern volatile unsigned int eRIC_LastCauseOfReset;                        //V4.5 V1.5.5 , last cause of reset can be retrieved from this variable




/************************************************************
 * DEBUG PIN LED OUT DEFINITIONS FOR DEV BOARD
 ************************************************************/
#define LED1_Set()   									   (P3OUT |= BIT5)
#define LED1_Clear() 									   (P3OUT &= ~BIT5)
#define LED2_Set()  	 								   (P3OUT |= BIT4)
#define LED2_Clear() 									   (P3OUT &= ~BIT4)
#define LED3_Set()   									   (P3OUT |= BIT3)
#define LED3_Clear() 									   (P3OUT &= ~BIT3)
#define LED4_Set()  	 								   (P3OUT |= BIT2)
#define LED4_Clear()   									   (P3OUT &= ~BIT2)

#define SW1Read()   									    Pin16_Read()
#define SW2Read()    									    Pin17_Read()
#define SW3Read()    									    Pin18_Read()
#define SW4Read()    									    Pin19_Read()

#define SW1Enable() 									   {Pin16_SetAsInput();Pin16_PullDownEnable();}
#define SW2Enable() 									   {Pin17_SetAsInput();Pin17_PullDownEnable();}
#define SW3Enable() 									   {Pin18_SetAsInput();Pin18_PullDownEnable();}
#define SW4Enable() 									   {Pin19_SetAsInput();Pin19_PullDownEnable();}

#define LED1Enable() 									    Pin16_SetAsOutput()
#define LED2Enable() 									    Pin17_SetAsOutput()
#define LED3Enable() 									    Pin18_SetAsOutput()
#define LED4Enable() 									    Pin19_SetAsOutput()

/************************************************************
 * UARTA0 DEFINITIONS
 ************************************************************/

void eRIC_UARTA_SetBaud(unsigned long Baudrate);
void eRIC_UARTAInitialise(unsigned long Baudrate);

#define eRIC_UartATxInteruptDisable() 					   {UCA0IE &= ~UCTXIE;UCA0IFG |= UCTXIFG;} /* Turn off Tx Interrupt*/
#define eRIC_UartATxInteruptEnable() 					   {UCA0IE |= UCTXIE; UCA0IFG |= UCTXIFG;} /* Turn on Tx Interrupt*/
#define eRIC_UartATxIsEnabled()      					   (UCA0IE & UCTXIE)
#define eRIC_UartATxBufferIsEmpty()   					   (UCA0IFG & UCTXIFG)
#define eRIC_UartATxBufferIsBusy()   					   (!eRIC_UartATxBufferIsEmpty())
#define eRIC_UartATxSetInterruptFlag()                     {UCA0IFG |= UCTXIFG;}                 //V1.5
#define eRIC_UartATxClearInterruptFlag()                   {UCA0IFG &= ~UCTXIFG;}                //V1.5
#define eRIC_UartATxHasInterrupted()                       (UCA0IFG & UCTXIFG)                   //V1.5

#define eRIC_UartARxInteruptDisable() 					   {UCA0IE &= ~UCRXIE;UCA0IFG |= UCRXIFG;} /* Turn off Rx Interrupt*/
#define eRIC_UartARxInteruptEnable() 					   {UCA0IE |= UCRXIE;}// UCA0IFG |= UCRXIFG;} /* Turn on Rx Interrupt*/
#define eRIC_UartARxIsEnabled()       					   (UCA0IE & UCRXIE)
#define eRIC_UartARxBufferIsEmpty()  					   (UCA0IFG & UCRXIFG)
#define eRIC_UartARxBufferIsBusy()   					   (!eRIC_UartARxBufferIsEmpty())
#define eRIC_UartARxSetInterruptFlag()                     {UCA0IFG |= UCRXIFG;}                 //V1.5
#define eRIC_UartARxClearInterruptFlag()                   {UCA0IFG &= ~UCRXIFG;}                //V1.5
#define eRIC_UartARxHasInterrupted()                       (UCA0IFG & UCRXIFG)                   //V1.5


#define eRIC_UartASendByte(Data)      					    UCA0TXBUF = Data
#define eRIC_UartAReceiveByte()      					    UCA0RXBUF


//Added below uart definition in V1.4
#define eRIC_UartA_SyncMode()         					    UCA0CTL0|= UCSYNC
#define eRIC_UartA_ASyncMode()        					    UCA0CTL0&= ~UCSYNC

#define eRIC_UartA_2StopBits()        					    UCA0CTL0|= UCSPB
#define eRIC_UartA_1StopBit()         					    UCA0CTL0&= ~UCSPB

#define eRIC_UartA_7Bit()             					    UCA0CTL0|= UC7BIT
#define eRIC_UartA_8Bit()             					    UCA0CTL0&= ~UC7BIT

#define eRIC_UartA_MsbFirst()          					    UCA0CTL0|= UCMSB
#define eRIC_UartA_LsbFirst()       				        UCA0CTL0&= ~UCMSB

#define eRIC_UartA_EvenParity()      					    UCA0CTL0|= UCPAR
#define eRIC_UartA_OddParity()       					    UCA0CTL0&= ~UCPAR

#define eRIC_UartA_ParityEnable()    					    UCA0CTL0|= UCPEN
#define eRIC_UartA_ParityDisable()   					    UCA0CTL0&= ~UCPEN


#define eRIC_UartABusy()                                   (UCA0STAT&UCBUSY)   //V1.5.4


/************************************************************
 * SPIA0 DEFINITIONS
 ************************************************************/
void eRIC_SpiAInitialise(unsigned long SpiClock); //added in V1.4
unsigned char SpiATransfer(volatile unsigned char Data);

#define eRIC_SpiATxInteruptDisable()					   {UCA0IE &= ~UCTXIE;UCA0IFG |= UCTXIFG;} /* Turn off Interrupt*/
#define eRIC_SpiATxInteruptEnable() 					   {UCA0IE |= UCTXIE; UCA0IFG |= UCTXIFG;} /* Turn on Interrupt*/
#define eRIC_SpiATxIsEnabled()      					   (UCA0IE & UCTXIE)
#define eRIC_SpiATxBufferIsEmpty()  					   (UCA0IFG & UCTXIFG)
#define eRIC_SpiATxBufferIsBusy()   					   (!eRIC_SpiATxBufferIsEmpty())
#define eRIC_SpiARxInteruptDisable()					   {UCA0IE &= ~UCRXIE;UCA0IFG |= UCRXIFG;} /* Turn off Rx Interrupt*/
#define eRIC_SpiARxInteruptEnable() 					   {UCA0IE |= UCRXIE; UCA0IFG |= UCRXIFG;} /* Turn on Rx Interrupt*/
#define eRIC_SpiARxIsEnabled()      					   (UCA0IE & UCRXIE)
#define eRIC_SpiARxBufferIsEmpty()  					   (UCA0IFG & UCRXIFG)
#define eRIC_SpiARxBufferIsBusy()   					   (!eRIC_SpiARxBufferIsEmpty())

#define eRIC_SpiASendByte(Data)      					    UCA0TXBUF = Data
#define eRIC_SpiAReceiveByte()      					    UCA0RXBUF

#define eRIC_SpiAWrite(Data)         					    SpiATransfer(Data)
#define eRIC_SpiARead(Data)          					    SpiATransfer(Data)

#define eRIC_SpiA_SyncMode()        					    UCA0CTL0|= UCSYNC
#define eRIC_SpiA_ASyncMode()        					    UCA0CTL0&= ~UCSYNC

#define eRIC_SpiA_3PinMode()        					    UCA0CTL0|= UCMODE_0
#define eRIC_SpiA_4Pin_SteActiveHigh()					    UCA0CTL0|= UCMODE_1//Slave is active when UCxSTE is high
#define eRIC_SpiA_4Pin_SteActiveLow()					    UCA0CTL0|= UCMODE_2 //Slave is Enabled when UCxSTE is Low
#define eRIC_SpiA_MasterMode()       					    UCA0CTL0|= UCMST
#define eRIC_SpiA_SlaveMode()       					    UCA0CTL0&= ~UCMST

#define eRIC_SpiA_7Bit()             					    UCA0CTL0|= UC7BIT
#define eRIC_SpiA_8Bit()            					    UCA0CTL0&= ~UC7BIT

#define eRIC_SpiA_MsbFirst()        					    UCA0CTL0|= UCMSB
#define eRIC_SpiA_LsbFirst()         					    UCA0CTL0&= ~UCMSB

#define eRIC_SpiA_ClkIdleHigh()     					    UCA0CTL0|= UCCKPL
#define eRIC_SpiA_ClkIdleLow()        				        UCA0CTL0&= ~UCCKPL

#define eRIC_SpiA_DataOn1stUclkEdge()					    UCA0CTL0|= UCCKPH
#define eRIC_SpiA_DataOn2ndUclkEdge()					    UCA0CTL0&= ~UCCKPH

#define eRIC_SpiABusy()                                    (UCA0STAT&UCBUSY)   //V1.5.4


/************************************************************
 * SPIB0 DEFINITIONS
 ************************************************************/

void eRIC_SpiBInitialise(volatile unsigned long SpiClock);//Added in V1.4
unsigned char SpiBTransfer(volatile unsigned char Data);


#define eRIC_SpiBTxInteruptDisable()				   	   {UCB0IE &= ~UCTXIE;UCB0IFG |= UCTXIFG;} /* Turn off Interrupt*/
#define eRIC_SpiBTxInteruptEnable() 					   {UCB0IE |= UCTXIE; UCB0IFG |= UCTXIFG;} /* Turn on Interrupt*/
#define eRIC_SpiBTxIsEnabled()      					   (UCB0IE & UCTXIE)
#define eRIC_SpiBTxBufferIsEmpty()  					   (UCB0IFG & UCTXIFG)
#define eRIC_SpiBTxBufferIsBusy()   					   (!eRIC_SpiBTxBufferIsEmpty())
#define eRIC_SpiBRxInteruptDisable() 					   {UCB0IE &= ~UCRXIE;UCB0IFG |= UCRXIFG;} /* Turn off Rx Interrupt*/
#define eRIC_SpiBRxInteruptEnable() 					   {UCB0IE |= UCRXIE; UCB0IFG |= UCRXIFG;} /* Turn on Rx Interrupt*/
#define eRIC_SpiBRxIsEnabled()      					   (UCB0IE & UCRXIE)
#define eRIC_SpiBRxBufferIsEmpty()  					   (UCB0IFG & UCRXIFG)
#define eRIC_SpiBRxBufferIsBusy()   					   (!eRIC_SpiBRxBufferIsEmpty())

#define eRIC_SpiBSendByte(Data)       					    UCB0TXBUF = Data
#define eRIC_SpiBReceiveByte()      					    UCB0RXBUF

#define eRIC_SpiBWrite(Data)        					    SpiBTransfer(Data)
#define eRIC_SpiBRead(Data)         					    SpiBTransfer(Data)

#define eRIC_SpiB_SyncMode()        					    UCB0CTL0|= UCSYNC
#define eRIC_SpiB_ASyncMode()       					    UCB0CTL0&= ~UCSYNC

#define eRIC_SpiB_3PinMode()        					    UCB0CTL0|= UCMODE_0
#define eRIC_SpiB_4Pin_SteActiveHigh()					    UCB0CTL0|= UCMODE_1//Slave is active when UCxSTE is high
#define eRIC_SpiB_4Pin_SteActiveLow()					    UCB0CTL0|= UCMODE_2 //Slave is Enabled when UCxSTE is Low
#define eRIC_SpiB_MasterMode()      					    UCB0CTL0|= UCMST
#define eRIC_SpiB_SlaveMode()       					    UCB0CTL0&= ~UCMST

#define eRIC_SpiB_7Bit()            					    UCB0CTL0|= UC7BIT
#define eRIC_SpiB_8Bit()            					    UCB0CTL0&= ~UC7BIT

#define eRIC_SpiB_MsbFirst()        					    UCB0CTL0|= UCMSB
#define eRIC_SpiB_LsbFirst()        					    UCB0CTL0&= ~UCMSB

#define eRIC_SpiB_ClkIdleHigh()     	 				    UCB0CTL0|= UCCKPL
#define eRIC_SpiB_ClkIdleLow()       					    UCB0CTL0&= ~UCCKPL

#define eRIC_SpiB_DataOn1stUclkEdge()					    UCB0CTL0|= UCCKPH
#define eRIC_SpiB_DataOn2ndUclkEdge()					    UCB0CTL0&= ~UCCKPH

#define eRIC_SpiBBusy()                                    (UCB0STAT&UCBUSY)   //V1.5.4

/************************************************************
 * I2C DEFINITIONS
 ************************************************************/
//Added in V1.4

void eRIC_I2CB_Initialise(volatile unsigned long I2CClock,char MasterorSlave,char Address);
unsigned char I2CBReceiveByte();


#define eRIC_I2CB_TxInteruptDisable() 				   	   {UCB0IE &= ~UCTXIE;UCB0IFG |= UCTXIFG;} /* Turn off Interrupt*/
#define eRIC_I2CB_TxInteruptEnable() 				       {UCB0IE |= UCTXIE; UCB0IFG |= UCTXIFG;} /* Turn on Interrupt*/
#define eRIC_I2CB_TxIsEnabled()      				       (UCB0IE & UCTXIE)
#define eRIC_I2CB_TxBufferIsEmpty()    					   (UCB0IFG & UCTXIFG)
#define eRIC_I2CB_TxBufferIsBusy()    					   (!eRIC_I2CB_TxBufferIsEmpty())
#define eRIC_I2CB_RxInteruptDisable() 					   {UCB0IE &= ~UCRXIE;UCB0IFG |= UCRXIFG;} /* Turn off Rx Interrupt*/
#define eRIC_I2CB_RxInteruptEnable()  					   {UCB0IE |= UCRXIE; UCB0IFG |= UCRXIFG;} /* Turn on Rx Interrupt*/
#define eRIC_I2CB_RxIsEnabled()       					   (UCB0IE & UCRXIE)
#define eRIC_I2CB_RxBufferIsEmpty()   					   (UCB0IFG & UCRXIFG)
#define eRIC_I2CB_RxBufferIsBusy()    					   (!eRIC_I2CB_RxBufferIsEmpty())

#define eRIC_I2CB_SendByte(Data)      					   {while(eRIC_I2CB_TxBufferIsBusy());UCB0TXBUF = Data;}
#define eRIC_I2CB_ReceiveByte()        					    I2CBReceiveByte()


#define eRIC_I2CB_SyncMode()          					    UCB0CTL0|= UCSYNC
#define eRIC_I2CB_ASyncMode()          					    UCB0CTL0&= ~UCSYNC

#define eRIC_I2CB_MasterMode()         					    UCB0CTL0|= UCMST
#define eRIC_I2CB_SlaveMode()          					    UCB0CTL0&= ~UCMST

#define eRIC_I2CB_MultiMasterMode()    					    UCB0CTL0|= UCMM
#define eRIC_I2CB_SingleMasterMode()   					    UCB0CTL0&= ~UCMM

#define eRIC_I2CB_10BitSlaveAddress()  					    UCB0CTL0|= UCSLA10
#define eRIC_I2CB_7BitSlaveAddress()    				    UCB0CTL0&= ~UCSLA10

#define eRIC_I2CB_10BitOwnAddress()    					    UCB0CTL0|= UCA10
#define eRIC_I2CB_7BitOwnAddress()     					    UCB0CTL0&= ~UCA10

#define eRIC_I2CB_SoftwareResetEnable()					    UCB0CTL1|= UCSWRST
#define eRIC_I2CB_SoftwareResetDisable()				    UCB0CTL1&= ~UCSWRST

#define eRIC_I2CB_IsStartActive()     					    UCB0CTL1 & UCTXSTT

#define eRIC_I2CB_Start()             					    UCB0CTL1|= UCTXSTT

#define eRIC_I2CB_Stop()             					   {while(eRIC_I2CB_TxBufferIsBusy());UCB0CTL1|=UCTXSTP;}
#define eRIC_I2CB_IsStopConditionOn()  					    UCB0CTL1 & UCTXSTP

#define eRIC_I2CB_NackOn()             					    UCB0CTL1|=UCTXNACK
#define eRIC_I2CB_NackOff()            					    UCB0CTL1&= ~UCTXNACK

#define eRIC_I2CB_AsTransmitter()     					    UCB0CTL1|=UCTR
#define eRIC_I2CB_AsReceiver()        					    UCB0CTL1&= ~UCTR

#define eRIC_I2CB_IsSCL_Low()         					    UCB0STAT&UCSCLLOW

#define eRIC_I2CB_IsBusBusy()         					    UCB0STAT&UCBBUSY

#define eRIC_I2CB_OwnAddress         				        UCB0I2COA

#define eRIC_I2CB_SlaveAddress        					    UCB0I2CSA

#define eRIC_I2CB_WaitforACK()       				        eRIC_I2CB_IsStartActive()

#define eRIC_I2CB_NackReceived()       					    UCB0IFG&UCNACKIFG

/************************************************************
 * PORT PIN DEFINITIONS
 ************************************************************/

//eRIC_Pin1 Definitions
//PullUp/Down Resistor
#define Pin1_PullUpEnable()                                {P2REN |= BIT4;P2OUT|=BIT4;}
#define Pin1_PullDownEnable()                              {P2REN |= BIT4;P2OUT&=~BIT4;}
#define Pin1_PullUpDisable()                                P2REN &= ~BIT4

//O/P
#define Pin1_SetAsOutput()                                  P2DIR |= BIT4
#define Pin1_SetHigh()                                      P2OUT |= BIT4
#define Pin1_SetLow()                                       P2OUT &=~ BIT4
#define Pin1_Toggle()                                       P2OUT ^= BIT4;    //V1.4
//I/P
#define Pin1_SetAsInput()                                   P2DIR &=~ BIT4
#define Pin1_Read()                                        (P2IN & BIT4)

//Pin Drive Strength (sets maximum drive capabilities of each pin individually - default = low 6mA)
#define Pin1_HighDriveStrength_15mA()                      {P2DS |= BIT4;}    /*Sets Logic High and Low of pins for  High Drive strength */
#define PIn1_LowDriveStrength_6mA()                        {P2DS &= ~BIT4;}    /*Sets Logic High and Low of pins for  Low Drive strength */

//Pin Interrupt Edge Direction
#define Pin1_InterruptLow2High()                           {P2IES &= ~BIT4;}       /*Set Interrupt Flag on PIN Low to High*/
#define Pin1_InterruptHigh2Low()                           {P2IES |= BIT4;}        /*Set Interrupt Flag on PIN High to Low*/
#define Pin1_InterruptDirection()                          (P2IES & BIT4)      /*Read Interrupt Edge selection*/

//Pin Change Interrupt Enable/Disable
#define Pin1_InterruptEnable()                             {P2IE |= BIT4;}        /*Enable Pin Interrupt, only use when using Interrupt Service Routine*/
#define Pin1_InterruptDisable()                            {P2IE &= ~BIT4;}       /*Disable Pin Interrupt*/
#define Pin1_InterruptEnabled()                            (P2IE & BIT4)        /*Read Interrupt Enabled status*/

//Pin Interrupt Flag
#define Pin1_SetInterruptFlag()                            {P2IFG |= BIT4;}
#define Pin1_ClearInterruptFlag()                          {P2IFG &= ~BIT4;}     /*Reset Interrupt flag*/
#define Pin1_HasIntterupted()                              (P2IFG & BIT4)       /*Test if Pin has changed*/

//Secondary function mapping
#define Pin1_FunctionIO()                                  {P2SEL &= ~BIT4;}  /* */

#define Pin1_FunctionNone()                                {PMAPPWD = 0x02D52;P2MAP4 = PM_NONE;PMAPPWD = 0;P2SEL |= BIT4;P2DIR |= BIT4;P2SEL &= ~BIT4;}  /* */

#define Pin1_FunctionAclk()                                {PMAPPWD = 0x02D52;P2MAP4 = PM_ACLK;PMAPPWD = 0;P2SEL |= BIT4;P2DIR |= BIT4;}
#define Pin1_FunctionMclk()                                {PMAPPWD = 0x02D52;P2MAP4 = PM_MCLK;PMAPPWD = 0;P2SEL |= BIT4;P2DIR |= BIT4;}
#define Pin1_FunctionSmclk()                               {PMAPPWD = 0x02D52;P2MAP4 = PM_SMCLK;PMAPPWD = 0;P2SEL |= BIT4;P2DIR |= BIT4;}

#define Pin1_FunctionTA0clkIN()                            {PMAPPWD = 0x02D52;P2MAP4 = PM_TA0CLK;PMAPPWD = 0;P2SEL |= BIT4;P2DIR &= ~BIT4;}

#define Pin1_FunctionA2D()              				   {PMAPPWD = 0x02D52;P2MAP4 = PM_ANALOG;PMAPPWD = 0;P2SEL |= BIT4;}

#define Pin1_FunctionUartATxOUT()     					   {PMAPPWD = 0x02D52;P2MAP4 = PM_UCA0TXD;PMAPPWD = 0;P2SEL |= BIT4;P2DIR |= BIT4;}
#define Pin1_FunctionUartARxD()    					       {PMAPPWD = 0x02D52;P2MAP4 = PM_UCA0RXD;PMAPPWD = 0;P2SEL |= BIT4;}

#define Pin1_FunctionUartABusy()     					   {eRIC_Port2Busy = 0x10; eRIC_Port3Busy = 0x00;Pin1_SetAsOutput();Pin1_SetLow();} /*Set Port Direction*//*Clear the pin*/

#define Pin1_FunctionSpiA_MI()   					       {PMAPPWD = 0x02D52;P2MAP4 = PM_UCA0SOMI;PMAPPWD = 0;P2DIR &= ~BIT4;P2SEL |= BIT4;}
#define Pin1_FunctionSpiA_MO()      				       {PMAPPWD = 0x02D52;P2MAP4 = PM_UCA0SIMO;PMAPPWD = 0;P2DIR |= BIT4;P2SEL |= BIT4;}
#define Pin1_FunctionSpiA_SO()   					       {PMAPPWD = 0x02D52;P2MAP4 = PM_UCA0SOMI;PMAPPWD = 0;P2DIR |= BIT4;P2SEL |= BIT4;}
#define Pin1_FunctionSpiA_SI()     					       {PMAPPWD = 0x02D52;P2MAP4 = PM_UCA0SIMO;PMAPPWD = 0;P2DIR &= ~BIT4;P2SEL |= BIT4;}
#define Pin1_FunctionSpiA_SCLKOUT()					       {PMAPPWD = 0x02D52;P2MAP4 = PM_UCA0CLK;PMAPPWD = 0;P2DIR |=BIT4;P2SEL |= BIT4;}
#define Pin1_FunctionSpiA_STE()  					       {PMAPPWD = 0x02D52;P2MAP4 = PM_UCA0STE;PMAPPWD = 0;P2SEL |= BIT4;}

#define Pin1_FunctionSpiB_MI()  				           {PMAPPWD = 0x02D52;P2MAP4 = PM_UCB0SOMI;PMAPPWD = 0;P2DIR &= ~BIT4;P2SEL |= BIT4;}
#define Pin1_FunctionSpiB_MO()   					       {PMAPPWD = 0x02D52;P2MAP4 = PM_UCB0SIMO;PMAPPWD = 0;P2DIR |= BIT4;P2SEL |= BIT4;}
#define Pin1_FunctionSpiB_SO()   					       {PMAPPWD = 0x02D52;P2MAP4 = PM_UCB0SOMI;PMAPPWD = 0;P2DIR |= BIT4;P2SEL |= BIT4;}
#define Pin1_FunctionSpiB_SI()   					       {PMAPPWD = 0x02D52;P2MAP4 = PM_UCB0SIMO;PMAPPWD = 0;P2DIR &= ~BIT4;P2SEL |= BIT4}
#define Pin1_FunctionSpiB_SCLKOUT() 				       {PMAPPWD = 0x02D52;P2MAP4 = PM_UCB0CLK;PMAPPWD = 0;P2DIR |=BIT4;P2SEL |= BIT4;}
#define Pin1_FunctionSpiB_STE()  					       {PMAPPWD = 0x02D52;P2MAP4 = PM_UCB0STE;PMAPPWD = 0;P2SEL |= BIT4;}

#define Pin1_FunctionI2CB_SCl()  					       {PMAPPWD = 0x02D52;P2MAP4 = PM_UCB0SCL;PMAPPWD = 0;P2SEL |= BIT4;}
#define Pin1_FunctionI2CB_SDA()  					       {PMAPPWD = 0x02D52;P2MAP4 = PM_UCB0SDA;PMAPPWD = 0;P2SEL |= BIT4;}

#define Pin1_FunctionGDOSignal()                           {PMAPPWD = 0x02D52;P2MAP4 = PM_RFGDO2;PMAPPWD = 0;P2SEL |= BIT4;} //V1.5 and eROS V4.1

#define Pin1_SetAsAsyncRxData() 				           {PMAPPWD = 0x02D52;P2MAP4 = PM_RFGDO1;PMAPPWD = 0;P2SEL |= BIT4;}
#define Pin1_SetAsAsyncTxData()  					       {PMAPPWD = 0x02D52;P2MAP4 = PM_RFGDO0;PMAPPWD = 0;P2SEL |= BIT4;P2REN |= BIT4;}


#define Pin1_FunctionTA0CompareOut0() 					   {PMAPPWD = 0x02D52;P2MAP4 = PM_TA0CCR0A;PMAPPWD = 0;P2DIR |= BIT4;P2SEL |= BIT4;}
#define Pin1_FunctionTA0CompareOut1() 					   {PMAPPWD = 0x02D52;P2MAP4 = PM_TA0CCR1A;PMAPPWD = 0;P2DIR |= BIT4;P2SEL |= BIT4;}
#define Pin1_FunctionPWM1()      					       {Pin1_FunctionTA0CompareOut1();}
#define Pin1_FunctionTA0CompareOut2() 					   {PMAPPWD = 0x02D52;P2MAP4 = PM_TA0CCR2A;PMAPPWD = 0;P2DIR |= BIT4;P2SEL |= BIT4;}
#define Pin1_FunctionPWM2()   					           {Pin1_FunctionTA0CompareOut2();}
#define Pin1_FunctionTA0CompareOut3()					   {PMAPPWD = 0x02D52;P2MAP4 = PM_TA0CCR3A;PMAPPWD = 0;P2DIR |= BIT4;P2SEL |= BIT4;}
#define Pin1_FunctionPWM3()    					           {Pin1_FunctionTA0CompareOut3();}
#define Pin1_FunctionTA0CompareOut4() 					   {PMAPPWD = 0x02D52;P2MAP4 = PM_TA0CCR4A;PMAPPWD = 0;P2DIR |= BIT4;P2SEL |= BIT4;}
#define Pin1_FunctionPWM4()    					           {Pin1_FunctionTA0CompareOut4();}

#define Pin1_FunctionTA0CaptureIn0()				       {PMAPPWD = 0x02D52;P2MAP4 = PM_TA0CCR0A;PMAPPWD = 0;P2DIR &= ~BIT4;P2SEL |= BIT4;}
#define Pin1_FunctionTA0CaptureIn1()				       {PMAPPWD = 0x02D52;P2MAP4 = PM_TA0CCR1A;PMAPPWD = 0;P2DIR &= ~BIT4;P2SEL |= BIT4;}
#define Pin1_FunctionTA0CaptureIn2()				       {PMAPPWD = 0x02D52;P2MAP4 = PM_TA0CCR2A;PMAPPWD = 0;P2DIR &= ~BIT4;P2SEL |= BIT4;}
#define Pin1_FunctionTA0CaptureIn3()				       {PMAPPWD = 0x02D52;P2MAP4 = PM_TA0CCR3A;PMAPPWD = 0;P2DIR &= ~BIT4;P2SEL |= BIT4;}
#define Pin1_FunctionTA0CaptureIn4()				       {PMAPPWD = 0x02D52;P2MAP4 = PM_TA0CCR4A;PMAPPWD = 0;P2DIR &= ~BIT4;P2SEL |= BIT4;}

//eRIC_Pin2 Definitions
//PullUp/Down Resistor
#define Pin2_PullUpEnable() 							   {P2REN |= BIT3;P2OUT|=BIT3;}
#define Pin2_PullDownEnable()							   {P2REN |= BIT3;P2OUT&=~BIT3;}
#define Pin2_PullUpDisable() 							    P2REN &= ~BIT3

//O/P
#define Pin2_SetAsOutput()  							    P2DIR |= BIT3
#define Pin2_SetHigh()      						        P2OUT |= BIT3
#define Pin2_SetLow()      							        P2OUT &=~ BIT3
#define Pin2_Toggle()                                       P2OUT ^= BIT3;    //V1.4
//I/P
#define Pin2_SetAsInput()  							        P2DIR &=~ BIT3
#define Pin2_Read()        							       (P2IN & BIT3)

//Pin Drive Strength (sets maximum drive capabilities of each pin individually - default = low 6mA)
#define Pin2_HighDriveStrength_15mA() 					   {P2DS |= BIT3;}    /*Sets Logic High and Low of pins for  High Drive strength */
#define PIn2_LowDriveStrength_6mA()						   {P2DS &= ~BIT3;}    /*Sets Logic High and Low of pins for  Low Drive strength */

//Pin Interrupt Edge Direction
#define Pin2_InterruptLow2High()						   {P2IES &= ~BIT3;}       /*Set Interrupt Flag on PIN Low to High*/
#define Pin2_InterruptHigh2Low()						   {P2IES |= BIT3;}        /*Set Interrupt Flag on PIN High to Low*/
#define Pin2_InterruptDirection()  						   (P2IES & BIT3)      /*Read Interrupt Edge selection*/

//Pin Change Interrupt Enable/Disable
#define Pin2_InterruptEnable() 							   {P2IE |= BIT3;}        /*Enable Pin Interrupt, only use when using Interrupt Service Routine*/
#define Pin2_InterruptDisable()							   {P2IE &= ~BIT3;}       /*Disable Pin Interrupt*/
#define Pin2_InterruptEnabled() 					       (P2IE & BIT3)        /*Read Interrupt Enabled status*/

//Pin Interrupt Flag
#define Pin2_SetInterruptFlag()                            {P2IFG |= BIT3;}
#define Pin2_ClearInterruptFlag()						   {P2IFG &= ~BIT3;}     /*Reset Interrupt flag*/
#define Pin2_HasIntterupted()    						   (P2IFG & BIT3)      /*Test if Pin has changed*/

//Secondary function mapping
#define Pin2_FunctionIO()          					       {P2SEL &= ~BIT3;}  /* */

#define Pin2_FunctionNone()     				           {PMAPPWD = 0x02D52;P2MAP3 = PM_NONE;PMAPPWD = 0;P2SEL |= BIT3;P2DIR |= BIT3;P2SEL &= ~BIT3;}  /* */

#define Pin2_FunctionAclk()    					           {PMAPPWD = 0x02D52;P2MAP3 = PM_ACLK;PMAPPWD = 0;P2SEL |= BIT3;P2DIR |= BIT3;}
#define Pin2_FunctionMclk()     				           {PMAPPWD = 0x02D52;P2MAP3 = PM_MCLK;PMAPPWD = 0;P2SEL |= BIT3;P2DIR |= BIT3;}
#define Pin2_FunctionSmclk()     					       {PMAPPWD = 0x02D52;P2MAP3 = PM_SMCLK;PMAPPWD = 0;P2SEL |= BIT3;P2DIR |= BIT3;}

#define Pin2_FunctionTA0clkIN()  					       {PMAPPWD = 0x02D52;P2MAP3 = PM_TA0CLK;PMAPPWD = 0;P2SEL |= BIT3;P2DIR &= ~BIT3;}

#define Pin2_FunctionA2D()       					       {PMAPPWD = 0x02D52;P2MAP3 = PM_ANALOG;PMAPPWD = 0;P2SEL |= BIT3;}

#define Pin2_FunctionUartATxOUT() 					       {PMAPPWD = 0x02D52;P2MAP3 = PM_UCA0TXD;PMAPPWD = 0;P2SEL |= BIT3;P2DIR |= BIT3;}
#define Pin2_FunctionUartARxD()   					       {PMAPPWD = 0x02D52;P2MAP3 = PM_UCA0RXD;PMAPPWD = 0;P2SEL |= BIT3;}

#define Pin2_FunctionUartABusy()   					       {eRIC_Port2Busy = 0x08; eRIC_Port3Busy = 0x00;Pin2_SetAsOutput();Pin2_SetLow();} /*Set Port Direction*//*Clear the pin*/

#define Pin2_FunctionSpiA_MI()     					       {PMAPPWD = 0x02D52;P2MAP3 = PM_UCA0SOMI;PMAPPWD = 0;P2DIR &= ~BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionSpiA_MO() 					           {PMAPPWD = 0x02D52;P2MAP3 = PM_UCA0SIMO;PMAPPWD = 0;P2DIR |= BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionSpiA_SO()   				           {PMAPPWD = 0x02D52;P2MAP3 = PM_UCA0SOMI;PMAPPWD = 0;P2DIR |= BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionSpiA_SI() 				               {PMAPPWD = 0x02D52;P2MAP3 = PM_UCA0SIMO;PMAPPWD = 0;P2DIR &= ~BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionSpiA_SCLKOUT() 				       {PMAPPWD = 0x02D52;P2MAP3 = PM_UCA0CLK;PMAPPWD = 0;P2DIR |=BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionSpiA_STE()					           {PMAPPWD = 0x02D52;P2MAP3 = PM_UCA0STE;PMAPPWD = 0;P2SEL |= BIT3;}

#define Pin2_FunctionSpiB_MI()  				           {PMAPPWD = 0x02D52;P2MAP3 = PM_UCB0SOMI;PMAPPWD = 0;P2DIR &= ~BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionSpiB_MO()  				           {PMAPPWD = 0x02D52;P2MAP3 = PM_UCB0SIMO;PMAPPWD = 0;P2DIR |= BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionSpiB_SO()   				           {PMAPPWD = 0x02D52;P2MAP3 = PM_UCB0SOMI;PMAPPWD = 0;P2DIR |= BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionSpiB_SI() 					           {PMAPPWD = 0x02D52;P2MAP3 = PM_UCB0SIMO;PMAPPWD = 0;P2DIR &= ~BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionSpiB_SCLKOUT() 			           {PMAPPWD = 0x02D52;P2MAP3 = PM_UCB0CLK;PMAPPWD = 0;P2DIR |=BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionSpiB_STE() 				           {PMAPPWD = 0x02D52;P2MAP3 = PM_UCB0STE;PMAPPWD = 0;P2SEL |= BIT3;}

#define Pin2_FunctionI2CB_SCl() 				           {PMAPPWD = 0x02D52;P2MAP3 = PM_UCB0SCL;PMAPPWD = 0;P2SEL |= BIT3;}
#define Pin2_FunctionI2CB_SDA()   					       {PMAPPWD = 0x02D52;P2MAP3 = PM_UCB0SDA;PMAPPWD = 0;P2SEL |= BIT3;}

#define Pin2_SetAsAsyncRxData()   					       {PMAPPWD = 0x02D52;P2MAP3 = PM_RFGDO1;PMAPPWD = 0;P2SEL |= BIT3;}
#define Pin2_SetAsAsyncTxData()  				           {PMAPPWD = 0x02D52;P2MAP3 = PM_RFGDO0;PMAPPWD = 0;P2SEL |= BIT3;P2REN |= BIT3;}


#define Pin2_FunctionTA0CompareOut0() 					   {PMAPPWD = 0x02D52;P2MAP3 = PM_TA0CCR0A;PMAPPWD = 0;P2DIR |= BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionTA0CompareOut1()                      {PMAPPWD = 0x02D52;P2MAP3 = PM_TA0CCR1A;PMAPPWD = 0;P2DIR |= BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionPWM1()                                {Pin2_FunctionTA0CompareOut1();}
#define Pin2_FunctionTA0CompareOut2()                      {PMAPPWD = 0x02D52;P2MAP3 = PM_TA0CCR2A;PMAPPWD = 0;P2DIR |= BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionPWM2()         				       {Pin2_FunctionTA0CompareOut2();}
#define Pin2_FunctionTA0CompareOut3() 				       {PMAPPWD = 0x02D52;P2MAP3 = PM_TA0CCR3A;PMAPPWD = 0;P2DIR |= BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionPWM3()       					       {Pin2_FunctionTA0CompareOut3();}
#define Pin2_FunctionTA0CompareOut4()				       {PMAPPWD = 0x02D52;P2MAP3 = PM_TA0CCR4A;PMAPPWD = 0;P2DIR |= BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionPWM4()       					       {Pin2_FunctionTA0CompareOut4();}

#define Pin2_FunctionTA0CaptureIn0()				       {PMAPPWD = 0x02D52;P2MAP3 = PM_TA0CCR0A;PMAPPWD = 0;P2DIR &= ~BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionTA0CaptureIn1() 				       {PMAPPWD = 0x02D52;P2MAP3 = PM_TA0CCR1A;PMAPPWD = 0;P2DIR &= ~BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionTA0CaptureIn2()  					   {PMAPPWD = 0x02D52;P2MAP3 = PM_TA0CCR2A;PMAPPWD = 0;P2DIR &= ~BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionTA0CaptureIn3()  					   {PMAPPWD = 0x02D52;P2MAP3 = PM_TA0CCR3A;PMAPPWD = 0;P2DIR &= ~BIT3;P2SEL |= BIT3;}
#define Pin2_FunctionTA0CaptureIn4()  					   {PMAPPWD = 0x02D52;P2MAP3 = PM_TA0CCR4A;PMAPPWD = 0;P2DIR &= ~BIT3;P2SEL |= BIT3;}


#define Pin2_FunctionGDOSignal()                           {PMAPPWD = 0x02D52;P2MAP3 = PM_RFGDO2;PMAPPWD = 0;P2SEL |= BIT3;} //V1.5 and eROS V4.1

//eRIC_Pin3 Definitions
//PullUp/Down Resistor
#define Pin3_PullUpEnable()  							   {P2REN |= BIT2;P2OUT|=BIT2;}
#define Pin3_PullDownEnable() 							   {P2REN |= BIT2;P2OUT&=~BIT2;}
#define Pin3_PullUpDisable()  							    P2REN &= ~BIT2

//O/P
#define Pin3_SetAsOutput()    							    P2DIR |= BIT2
#define Pin3_SetHigh()      						        P2OUT |= BIT2
#define Pin3_SetLow()         					            P2OUT &=~ BIT2
#define Pin3_Toggle()                                       P2OUT ^= BIT2;    //V1.4
//I/P
#define Pin3_SetAsInput()   							    P2DIR &=~ BIT2
#define Pin3_Read()       							       (P2IN & BIT2)

//Pin Drive Strength (sets maximum drive capabilities of each pin individually - default = low 6mA)
#define Pin3_HighDriveStrength_15mA()					   {P2DS |= BIT2;}    /*Sets Logic High and Low of pins for  High Drive strength */
#define PIn3_LowDriveStrength_6mA() 					   {P2DS &= ~BIT2;}    /*Sets Logic High and Low of pins for  Low Drive strength */

//Pin Interrupt Edge Direction
#define Pin3_InterruptLow2High()						   {P2IES &= ~BIT2;}       /*Set Interrupt Flag on PIN Low to High*/
#define Pin3_InterruptHigh2Low()						   {P2IES |= BIT2;}        /*Set Interrupt Flag on PIN High to Low*/
#define Pin3_InterruptDirection()                          (P2IES & BIT2)      /*Read Interrupt Edge selection*/

//Pin Change Interrupt Enable/Disable
#define Pin3_InterruptEnable()                             {P2IE |= BIT2;}        /*Enable Pin Interrupt, only use when using Interrupt Service Routine*/
#define Pin3_InterruptDisable()                            {P2IE &= ~BIT2;}       /*Disable Pin Interrupt*/
#define Pin3_InterruptEnabled()                            (P2IE & BIT2)        /*Read Interrupt Enabled status*/

//Pin Interrupt Flag
#define Pin3_SetInterruptFlag()                            {P2IFG |= BIT2;}
#define Pin3_ClearInterruptFlag()                          {P2IFG &= ~BIT2;}     /*Reset Interrupt flag*/
#define Pin3_HasIntterupted()    						   (P2IFG & BIT2)       /*Test if Pin has changed*/

//Secondary function mapping
#define Pin3_FunctionIO()       				           {P2SEL &= ~BIT2;}  /* */

#define Pin3_FunctionNone()     				           {PMAPPWD = 0x02D52;P2MAP2 = PM_NONE;PMAPPWD = 0;P2SEL |= BIT2;P2DIR |= BIT2;P2SEL &= ~BIT2;}  /* */

#define Pin3_FunctionAclk()       				           {PMAPPWD = 0x02D52;P2MAP2 = PM_ACLK;PMAPPWD = 0;P2SEL |= BIT2;P2DIR |= BIT2;}
#define Pin3_FunctionMclk()        					       {PMAPPWD = 0x02D52;P2MAP2 = PM_MCLK;PMAPPWD = 0;P2SEL |= BIT2;P2DIR |= BIT2;}
#define Pin3_FunctionSmclk()      					       {PMAPPWD = 0x02D52;P2MAP2 = PM_SMCLK;PMAPPWD = 0;P2SEL |= BIT2;P2DIR |= BIT2;}

#define Pin3_FunctionTA0clkIN()     				       {PMAPPWD = 0x02D52;P2MAP2 = PM_TA0CLK;PMAPPWD = 0;P2SEL |= BIT2;P2DIR &= ~BIT2;}

#define Pin3_FunctionA2D()   					           {PMAPPWD = 0x02D52;P2MAP2 = PM_ANALOG;PMAPPWD = 0;P2SEL |= BIT2;}

#define Pin3_FunctionUartATxOUT()  					       {PMAPPWD = 0x02D52;P2MAP2 = PM_UCA0TXD;PMAPPWD = 0;P2SEL |= BIT2;P2DIR |= BIT2;}
#define Pin3_FunctionUartARxD() 				           {PMAPPWD = 0x02D52;P2MAP2 = PM_UCA0RXD;PMAPPWD = 0;P2SEL |= BIT2;}

#define Pin3_FunctionUartABusy()  					       {eRIC_Port2Busy = 0x04; eRIC_Port3Busy = 0x00;Pin3_SetAsOutput();Pin3_SetLow();} /*Set Port Direction*//*Clear the pin*/

#define Pin3_FunctionSpiA_MI()  				           {PMAPPWD = 0x02D52;P2MAP2 = PM_UCA0SOMI;PMAPPWD = 0;P2DIR &= ~BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionSpiA_MO()    					       {PMAPPWD = 0x02D52;P2MAP2 = PM_UCA0SIMO;PMAPPWD = 0;P2DIR |= BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionSpiA_SO()  				           {PMAPPWD = 0x02D52;P2MAP2 = PM_UCA0SOMI;PMAPPWD = 0;P2DIR |= BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionSpiA_SI()  				           {PMAPPWD = 0x02D52;P2MAP2 = PM_UCA0SIMO;PMAPPWD = 0;P2DIR &= ~BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionSpiA_SCLKOUT() 		               {PMAPPWD = 0x02D52;P2MAP2 = PM_UCA0CLK;PMAPPWD = 0;P2DIR |=BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionSpiA_STE()   				           {PMAPPWD = 0x02D52;P2MAP2 = PM_UCA0STE;PMAPPWD = 0;P2SEL |= BIT2;}

#define Pin3_FunctionSpiB_MI()    					       {PMAPPWD = 0x02D52;P2MAP2 = PM_UCB0SOMI;PMAPPWD = 0;P2DIR &= ~BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionSpiB_MO()  				           {PMAPPWD = 0x02D52;P2MAP2 = PM_UCB0SIMO;PMAPPWD = 0;P2DIR |= BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionSpiB_SO()					           {PMAPPWD = 0x02D52;P2MAP2 = PM_UCB0SOMI;PMAPPWD = 0;P2DIR |= BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionSpiB_SI()   					       {PMAPPWD = 0x02D52;P2MAP2 = PM_UCB0SIMO;PMAPPWD = 0;P2DIR &= ~BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionSpiB_SCLKOUT()					       {PMAPPWD = 0x02D52;P2MAP2 = PM_UCB0CLK;PMAPPWD = 0;P2DIR |=BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionSpiB_STE()  				           {PMAPPWD = 0x02D52;P2MAP2 = PM_UCB0STE;PMAPPWD = 0;P2SEL |= BIT2;}

#define Pin3_FunctionI2CB_SCl()    					       {PMAPPWD = 0x02D52;P2MAP2 = PM_UCB0SCL;PMAPPWD = 0;P2SEL |= BIT2;}
#define Pin3_FunctionI2CB_SDA()  				           {PMAPPWD = 0x02D52;P2MAP2 = PM_UCB0SDA;PMAPPWD = 0;P2SEL |= BIT2;}

#define Pin3_SetAsAsyncRxData()  				           {PMAPPWD = 0x02D52;P2MAP2 = PM_RFGDO1;PMAPPWD = 0;P2SEL |= BIT2;}
#define Pin3_SetAsAsyncTxData() 				           {PMAPPWD = 0x02D52;P2MAP2 = PM_RFGDO0;PMAPPWD = 0;P2SEL |= BIT2;P2REN |= BIT2;}


#define Pin3_FunctionTA0CompareOut0() 				       {PMAPPWD = 0x02D52;P2MAP2 = PM_TA0CCR0A;PMAPPWD = 0;P2DIR |= BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionTA0CompareOut1() 					   {PMAPPWD = 0x02D52;P2MAP2 = PM_TA0CCR1A;PMAPPWD = 0;P2DIR |= BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionPWM1()  					           {Pin3_FunctionTA0CompareOut1();}
#define Pin3_FunctionTA0CompareOut2() 					   {PMAPPWD = 0x02D52;P2MAP2 = PM_TA0CCR2A;PMAPPWD = 0;P2DIR |= BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionPWM2()    					           {Pin3_FunctionTA0CompareOut2();}
#define Pin3_FunctionTA0CompareOut3()				       {PMAPPWD = 0x02D52;P2MAP2 = PM_TA0CCR3A;PMAPPWD = 0;P2DIR |= BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionPWM3()       					       {Pin3_FunctionTA0CompareOut3();}
#define Pin3_FunctionTA0CompareOut4() 					   {PMAPPWD = 0x02D52;P2MAP2 = PM_TA0CCR4A;PMAPPWD = 0;P2DIR |= BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionPWM4()    					           {Pin3_FunctionTA0CompareOut4();}

#define Pin3_FunctionTA0CaptureIn0() 					   {PMAPPWD = 0x02D52;P2MAP2 = PM_TA0CCR0A;PMAPPWD = 0;P2DIR &= ~BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionTA0CaptureIn1()				       {PMAPPWD = 0x02D52;P2MAP2 = PM_TA0CCR1A;PMAPPWD = 0;P2DIR &= ~BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionTA0CaptureIn2()  					   {PMAPPWD = 0x02D52;P2MAP2 = PM_TA0CCR2A;PMAPPWD = 0;P2DIR &= ~BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionTA0CaptureIn3()  				       {PMAPPWD = 0x02D52;P2MAP2 = PM_TA0CCR3A;PMAPPWD = 0;P2DIR &= ~BIT2;P2SEL |= BIT2;}
#define Pin3_FunctionTA0CaptureIn4()				       {PMAPPWD = 0x02D52;P2MAP2 = PM_TA0CCR4A;PMAPPWD = 0;P2DIR &= ~BIT2;P2SEL |= BIT2;}

#define Pin3_FunctionGDOSignal()                           {PMAPPWD = 0x02D52;P2MAP2 = PM_RFGDO2;PMAPPWD = 0;P2SEL |= BIT2;} //V1.5 and eROS V4.1

//eRIC_Pin4 Definitions
//PullUp/Down Resistor
#define Pin4_PullUpEnable() 							   {P2REN |= BIT1;P2OUT|=BIT1;}
#define Pin4_PullDownEnable() 							   {P2REN |= BIT1;P2OUT&=~BIT1;}
#define Pin4_PullUpDisable() 					            P2REN &= ~BIT1

//O/P
#define Pin4_SetAsOutput()                                  P2DIR |= BIT1
#define Pin4_SetHigh()                                      P2OUT |= BIT1
#define Pin4_SetLow()                                       P2OUT &=~ BIT1
#define Pin4_Toggle()                                       P2OUT ^= BIT1;    //V1.4
//I/P
#define Pin4_SetAsInput()                                   P2DIR &=~ BIT1
#define Pin4_Read()                                        (P2IN & BIT1)

//Pin Drive Strength (sets maximum drive capabilities of each pin individually - default = low 6mA)
#define Pin4_HighDriveStrength_15mA()                      {P2DS |= BIT1;}    /*Sets Logic High and Low of pins for  High Drive strength */
#define PIn4_LowDriveStrength_6mA()                        {P2DS &= ~BIT1;}    /*Sets Logic High and Low of pins for  Low Drive strength */

//Pin Interrupt Edge Direction
#define Pin4_InterruptLow2High()                           {P2IES &= ~BIT1;}       /*Set Interrupt Flag on PIN Low to High*/
#define Pin4_InterruptHigh2Low()                           {P2IES |= BIT1;}        /*Set Interrupt Flag on PIN High to Low*/
#define Pin4_InterruptDirection()                          (P2IES & BIT1)      /*Read Interrupt Edge selection*/

//Pin Change Interrupt Enable/Disable
#define Pin4_InterruptEnable()                             {P2IE |= BIT1;}        /*Enable Pin Interrupt, only use when using Interrupt Service Routine*/
#define Pin4_InterruptDisable()                            {P2IE &= ~BIT1;}       /*Disable Pin Interrupt*/
#define Pin4_InterruptEnabled()                            (P2IE & BIT1)        /*Read Interrupt Enabled status*/

//Pin Interrupt Flag
#define Pin4_SetInterruptFlag()                            {P2IFG |= BIT1;}
#define Pin4_ClearInterruptFlag()                          {P2IFG &= ~BIT1;}     /*Reset Interrupt flag*/
#define Pin4_HasIntterupted()                              (P2IFG & BIT1)       /*Test if Pin has changed*/

//Secondary function mapping
#define Pin4_FunctionIO()                                  {P2SEL &= ~BIT1;}  /* */

#define Pin4_FunctionNone()                                {PMAPPWD = 0x02D52;P2MAP1 = PM_NONE;PMAPPWD = 0;P2SEL |= BIT1;P2DIR |= BIT1;P2SEL &= ~BIT1;}  /* */

#define Pin4_FunctionAclk()                                {PMAPPWD = 0x02D52;P2MAP1 = PM_ACLK;PMAPPWD = 0;P2SEL |= BIT1;P2DIR |= BIT1;}
#define Pin4_FunctionMclk()                                {PMAPPWD = 0x02D52;P2MAP1 = PM_MCLK;PMAPPWD = 0;P2SEL |= BIT1;P2DIR |= BIT1;}
#define Pin4_FunctionSmclk()                               {PMAPPWD = 0x02D52;P2MAP1 = PM_SMCLK;PMAPPWD = 0;P2SEL |= BIT1;P2DIR |= BIT1;}

#define Pin4_FunctionTA0clkIN()                            {PMAPPWD = 0x02D52;P2MAP1 = PM_TA0CLK;PMAPPWD = 0;P2SEL |= BIT1;P2DIR &= ~BIT1;}

#define Pin4_FunctionA2D()                                 {PMAPPWD = 0x02D52;P2MAP1 = PM_ANALOG;PMAPPWD = 0;P2SEL |= BIT1;}

#define Pin4_FunctionUartATxOUT()                          {PMAPPWD = 0x02D52;P2MAP1 = PM_UCA0TXD;PMAPPWD = 0;P2SEL |= BIT1;P2DIR |= BIT1;}
#define Pin4_FunctionUartARxD()                            {PMAPPWD = 0x02D52;P2MAP1 = PM_UCA0RXD;PMAPPWD = 0;P2SEL |= BIT1;}

#define Pin4_FunctionUartABusy()                           {eRIC_Port2Busy = 0x02; eRIC_Port3Busy = 0x00;Pin4_SetAsOutput();Pin4_SetLow();} /*Set Port Direction*//*Clear the pin*/

#define Pin4_FunctionSpiA_MI()                             {PMAPPWD = 0x02D52;P2MAP1 = PM_UCA0SOMI;PMAPPWD = 0;P2DIR &= ~BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionSpiA_MO()                             {PMAPPWD = 0x02D52;P2MAP1 = PM_UCA0SIMO;PMAPPWD = 0;P2DIR |= BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionSpiA_SO()                             {PMAPPWD = 0x02D52;P2MAP1 = PM_UCA0SOMI;PMAPPWD = 0;P2DIR |= BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionSpiA_SI()                             {PMAPPWD = 0x02D52;P2MAP1 = PM_UCA0SIMO;PMAPPWD = 0;P2DIR &= ~BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionSpiA_SCLKOUT()                        {PMAPPWD = 0x02D52;P2MAP1 = PM_UCA0CLK;PMAPPWD = 0;P2DIR |=BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionSpiA_STE()                            {PMAPPWD = 0x02D52;P2MAP1 = PM_UCA0STE;PMAPPWD = 0;P2SEL |= BIT1;}

#define Pin4_FunctionSpiB_MI()                             {PMAPPWD = 0x02D52;P2MAP1 = PM_UCB0SOMI;PMAPPWD = 0;P2DIR &= ~BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionSpiB_MO()                             {PMAPPWD = 0x02D52;P2MAP1 = PM_UCB0SIMO;PMAPPWD = 0;P2DIR |= BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionSpiB_SO()                             {PMAPPWD = 0x02D52;P2MAP1 = PM_UCB0SOMI;PMAPPWD = 0;P2DIR |= BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionSpiB_SI()                             {PMAPPWD = 0x02D52;P2MAP1 = PM_UCB0SIMO;PMAPPWD = 0;P2DIR &= ~BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionSpiB_SCLKOUT()                        {PMAPPWD = 0x02D52;P2MAP1 = PM_UCB0CLK;PMAPPWD = 0;P2DIR |=BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionSpiB_STE()                            {PMAPPWD = 0x02D52;P2MAP1 = PM_UCB0STE;PMAPPWD = 0;P2SEL |= BIT1;}

#define Pin4_FunctionI2CB_SCl()                            {PMAPPWD = 0x02D52;P2MAP1 = PM_UCB0SCL;PMAPPWD = 0;P2SEL |= BIT1;}
#define Pin4_FunctionI2CB_SDA()                            {PMAPPWD = 0x02D52;P2MAP1 = PM_UCB0SDA;PMAPPWD = 0;P2SEL |= BIT1;}

#define Pin4_SetAsAsyncRxData()                            {PMAPPWD = 0x02D52;P2MAP1 = PM_RFGDO1;PMAPPWD = 0;P2SEL |= BIT1;}
#define Pin4_SetAsAsyncTxData()                            {PMAPPWD = 0x02D52;P2MAP1 = PM_RFGDO0;PMAPPWD = 0;P2SEL |= BIT1;P2REN |= BIT1;}


#define Pin4_FunctionTA0CompareOut0()                      {PMAPPWD = 0x02D52;P2MAP1 = PM_TA0CCR0A;PMAPPWD = 0;P2DIR |= BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionTA0CompareOut1()  					   {PMAPPWD = 0x02D52;P2MAP1 = PM_TA0CCR1A;PMAPPWD = 0;P2DIR |= BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionPWM1()          					   {Pin4_FunctionTA0CompareOut1();}
#define Pin4_FunctionTA0CompareOut2()  					   {PMAPPWD = 0x02D52;P2MAP1 = PM_TA0CCR2A;PMAPPWD = 0;P2DIR |= BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionPWM2()         				       {Pin4_FunctionTA0CompareOut2();}
#define Pin4_FunctionTA0CompareOut3()                      {PMAPPWD = 0x02D52;P2MAP1 = PM_TA0CCR3A;PMAPPWD = 0;P2DIR |= BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionPWM3()                                {Pin4_FunctionTA0CompareOut3();}
#define Pin4_FunctionTA0CompareOut4()					   {PMAPPWD = 0x02D52;P2MAP1 = PM_TA0CCR4A;PMAPPWD = 0;P2DIR |= BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionPWM4()         				       {Pin4_FunctionTA0CompareOut4();}

#define Pin4_FunctionTA0CaptureIn0() 					   {PMAPPWD = 0x02D52;P2MAP1 = PM_TA0CCR0A;PMAPPWD = 0;P2DIR &= ~BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionTA0CaptureIn1() 					   {PMAPPWD = 0x02D52;P2MAP1 = PM_TA0CCR1A;PMAPPWD = 0;P2DIR &= ~BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionTA0CaptureIn2()  					   {PMAPPWD = 0x02D52;P2MAP1 = PM_TA0CCR2A;PMAPPWD = 0;P2DIR &= ~BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionTA0CaptureIn3() 					   {PMAPPWD = 0x02D52;P2MAP1 = PM_TA0CCR3A;PMAPPWD = 0;P2DIR &= ~BIT1;P2SEL |= BIT1;}
#define Pin4_FunctionTA0CaptureIn4() 					   {PMAPPWD = 0x02D52;P2MAP1 = PM_TA0CCR4A;PMAPPWD = 0;P2DIR &= ~BIT1;P2SEL |= BIT1;}

#define Pin4_FunctionGDOSignal()                           {PMAPPWD = 0x02D52;P2MAP1 = PM_RFGDO2;PMAPPWD = 0;P2SEL |= BIT1;} //V1.5 and eROS V4.1

//eRIC_Pin5 Definitions
//PullUp/Down Resistor
#define Pin5_PullUpEnable() 							   {P2REN |= BIT0;P2OUT|=BIT0;}
#define Pin5_PullDownEnable()							   {P2REN |= BIT0;P2OUT&=~BIT0;}
#define Pin5_PullUpDisable() 							    P2REN &= ~BIT0

//O/P
#define Pin5_SetAsOutput()  							    P2DIR |= BIT0
#define Pin5_SetHigh()        							    P2OUT |= BIT0
#define Pin5_SetLow()         							    P2OUT &=~ BIT0
#define Pin5_Toggle()         							    P2OUT ^= BIT0;    //V1.4
//I/P
#define Pin5_SetAsInput()   							    P2DIR &=~ BIT0
#define Pin5_Read()         						       (P2IN & BIT0)

//Pin Drive Strength (sets maximum drive capabilities of each pin individually - default = low 6mA)
#define Pin5_HighDriveStrength_15mA()					   {P2DS |= BIT0;}    /*Sets Logic High and Low of pins for  High Drive strength */
#define PIn5_LowDriveStrength_6mA()						   {P2DS &= ~BIT0;}    /*Sets Logic High and Low of pins for  Low Drive strength */

//Pin Interrupt Edge Direction
#define Pin5_InterruptLow2High()						   {P2IES &= ~BIT0;}       /*Set Interrupt Flag on PIN Low to High*/
#define Pin5_InterruptHigh2Low()						   {P2IES |= BIT0;}        /*Set Interrupt Flag on PIN High to Low*/
#define Pin5_InterruptDirection()						   (P2IES & BIT0)     /*Read Interrupt Edge selection*/

//Pin Change Interrupt Enable/Disable
#define Pin5_InterruptEnable()							   {P2IE |= BIT0;}        /*Enable Pin Interrupt, only use when using Interrupt Service Routine*/
#define Pin5_InterruptDisable()							   {P2IE &= ~BIT0;}       /*Disable Pin Interrupt*/
#define Pin5_InterruptEnabled()							   (P2IE & BIT0)        /*Read Interrupt Enabled status*/

//Pin Interrupt Flag
#define Pin5_SetInterruptFlag()                            {P2IFG |= BIT0;}
#define Pin5_ClearInterruptFlag()						   {P2IFG &= ~BIT0;}     /*Reset Interrupt flag*/
#define Pin5_HasIntterupted()                			   (P2IFG & BIT0)       /*Test if Pin has changed*/

//Secondary function mapping
#define Pin5_FunctionIO()           				       {P2SEL &= ~BIT0;}  /* */

#define Pin5_FunctionNone()         				       {PMAPPWD = 0x02D52;P2MAP0 = PM_NONE;PMAPPWD = 0;P2SEL |= BIT0;P2DIR |= BIT0;P2SEL &= ~BIT0;}  /* */

#define Pin5_FunctionAclk()          					   {PMAPPWD = 0x02D52;P2MAP0 = PM_ACLK;PMAPPWD = 0;P2SEL |= BIT0;P2DIR |= BIT0;}
#define Pin5_FunctionMclk()          					   {PMAPPWD = 0x02D52;P2MAP0 = PM_MCLK;PMAPPWD = 0;P2SEL |= BIT0;P2DIR |= BIT0;}
#define Pin5_FunctionSmclk()         					   {PMAPPWD = 0x02D52;P2MAP0 = PM_SMCLK;PMAPPWD = 0;P2SEL |= BIT0;P2DIR |= BIT0;}

#define Pin5_FunctionTA0clkIN()      					   {PMAPPWD = 0x02D52;P2MAP0 = PM_TA0CLK;PMAPPWD = 0;P2SEL |= BIT0;P2DIR &= ~BIT0;}

#define Pin5_FunctionA2D()          				       {PMAPPWD = 0x02D52;P2MAP0 = PM_ANALOG;PMAPPWD = 0;P2SEL |= BIT0;}

#define Pin5_FunctionUartATxOUT()    					   {PMAPPWD = 0x02D52;P2MAP0 = PM_UCA0TXD;PMAPPWD = 0;P2SEL |= BIT0;P2DIR |= BIT0;}
#define Pin5_FunctionUartARxD()      					   {PMAPPWD = 0x02D52;P2MAP0 = PM_UCA0RXD;PMAPPWD = 0;P2SEL |= BIT0;}

#define Pin5_FunctionUartABusy()     					   {eRIC_Port2Busy = 0x01; eRIC_Port3Busy = 0x00;Pin5_SetAsOutput();Pin5_SetLow();} /*Set Port Direction*//*Clear the pin*/

#define Pin5_FunctionSpiA_MI()       					   {PMAPPWD = 0x02D52;P2MAP0 = PM_UCA0SOMI;PMAPPWD = 0;P2DIR &= ~BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionSpiA_MO()       					   {PMAPPWD = 0x02D52;P2MAP0 = PM_UCA0SIMO;PMAPPWD = 0;P2DIR |= BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionSpiA_SO()      				       {PMAPPWD = 0x02D52;P2MAP0 = PM_UCA0SOMI;PMAPPWD = 0;P2DIR |= BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionSpiA_SI()       					   {PMAPPWD = 0x02D52;P2MAP0 = PM_UCA0SIMO;PMAPPWD = 0;P2DIR &= ~BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionSpiA_SCLKOUT()  					   {PMAPPWD = 0x02D52;P2MAP0 = PM_UCA0CLK;PMAPPWD = 0;P2DIR |=BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionSpiA_STE()      					   {PMAPPWD = 0x02D52;P2MAP0 = PM_UCA0STE;PMAPPWD = 0;P2SEL |= BIT0;}

#define Pin5_FunctionSpiB_MI()      				       {PMAPPWD = 0x02D52;P2MAP0 = PM_UCB0SOMI;PMAPPWD = 0;P2DIR &= ~BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionSpiB_MO()       					   {PMAPPWD = 0x02D52;P2MAP0 = PM_UCB0SIMO;PMAPPWD = 0;P2DIR |= BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionSpiB_SO()      	 				   {PMAPPWD = 0x02D52;P2MAP0 = PM_UCB0SOMI;PMAPPWD = 0;P2DIR |= BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionSpiB_SI()       					   {PMAPPWD = 0x02D52;P2MAP0 = PM_UCB0SIMO;PMAPPWD = 0;P2DIR &= ~BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionSpiB_SCLKOUT()  					   {PMAPPWD = 0x02D52;P2MAP0 = PM_UCB0CLK;PMAPPWD = 0;P2DIR |=BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionSpiB_STE()      					   {PMAPPWD = 0x02D52;P2MAP0 = PM_UCB0STE;PMAPPWD = 0;P2SEL |= BIT0;}

#define Pin5_FunctionI2CB_SCl()      					   {PMAPPWD = 0x02D52;P2MAP0 = PM_UCB0SCL;PMAPPWD = 0;P2SEL |= BIT0;}
#define Pin5_FunctionI2CB_SDA()      					   {PMAPPWD = 0x02D52;P2MAP0 = PM_UCB0SDA;PMAPPWD = 0;P2SEL |= BIT0;}

#define Pin5_SetAsAsyncRxData()       					   {PMAPPWD = 0x02D52;P2MAP0 = PM_RFGDO1;PMAPPWD = 0;P2SEL |= BIT0;}
#define Pin5_SetAsAsyncTxData()       					   {PMAPPWD = 0x02D52;P2MAP0 = PM_RFGDO0;PMAPPWD = 0;P2SEL |= BIT0;P2REN |= BIT0;}


#define Pin5_FunctionTA0CompareOut0()					   {PMAPPWD = 0x02D52;P2MAP0 = PM_TA0CCR0A;PMAPPWD = 0;P2DIR |= BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionTA0CompareOut1()					   {PMAPPWD = 0x02D52;P2MAP0 = PM_TA0CCR1A;PMAPPWD = 0;P2DIR |= BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionPWM1()          					   {Pin5_FunctionTA0CompareOut1();}
#define Pin5_FunctionTA0CompareOut2()					   {PMAPPWD = 0x02D52;P2MAP0 = PM_TA0CCR2A;PMAPPWD = 0;P2DIR |= BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionPWM2()          					   {Pin5_FunctionTA0CompareOut2();}
#define Pin5_FunctionTA0CompareOut3()					   {PMAPPWD = 0x02D52;P2MAP0 = PM_TA0CCR3A;PMAPPWD = 0;P2DIR |= BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionPWM3()          					   {Pin5_FunctionTA0CompareOut3();}
#define Pin5_FunctionTA0CompareOut4()					   {PMAPPWD = 0x02D52;P2MAP0 = PM_TA0CCR4A;PMAPPWD = 0;P2DIR |= BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionPWM4()          					   {Pin5_FunctionTA0CompareOut4();}

#define Pin5_FunctionTA0CaptureIn0() 					   {PMAPPWD = 0x02D52;P2MAP0 = PM_TA0CCR0A;PMAPPWD = 0;P2DIR &= ~BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionTA0CaptureIn1()				       {PMAPPWD = 0x02D52;P2MAP0 = PM_TA0CCR1A;PMAPPWD = 0;P2DIR &= ~BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionTA0CaptureIn2() 					   {PMAPPWD = 0x02D52;P2MAP0 = PM_TA0CCR2A;PMAPPWD = 0;P2DIR &= ~BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionTA0CaptureIn3() 					   {PMAPPWD = 0x02D52;P2MAP0 = PM_TA0CCR3A;PMAPPWD = 0;P2DIR &= ~BIT0;P2SEL |= BIT0;}
#define Pin5_FunctionTA0CaptureIn4() 					   {PMAPPWD = 0x02D52;P2MAP0 = PM_TA0CCR4A;PMAPPWD = 0;P2DIR &= ~BIT0;P2SEL |= BIT0;}

#define Pin5_FunctionGDOSignal()                           {PMAPPWD = 0x02D52;P2MAP0 = PM_RFGDO2;PMAPPWD = 0;P2SEL |= BIT0;} //V1.5 and eROS V4.1

//eRIC_Pin10 Definitions
//PullUp/Down Resistor
#define Pin10_PullUpEnable() 							   {PJREN |= BIT3;PJOUT|=BIT3;}
#define Pin10_PullDownEnable()							   {PJREN |= BIT3;PJOUT&=~BIT3;}
#define Pin10_PullUpDisable() 							    PJREN &= ~BIT3

//O/P
#define Pin10_SetAsOutput()   							    PJDIR |= BIT3
#define Pin10_SetHigh()        							    PJOUT |= BIT3
#define Pin10_SetLow()         							    PJOUT &=~ BIT3
#define Pin10_Toggle()        							    PJOUT ^= BIT3;    //V1.4
//I/P
#define Pin10_SetAsInput()   							    PJDIR &=~ BIT3
#define Pin10_Read()         						       (PJIN & BIT3)

//eRIC_Pin11 Definitions
//PullUp/Down Resistor
#define Pin11_PullUpEnable() 							   {PJREN |= BIT2;PJOUT|=BIT2;}
#define Pin11_PullDownEnable()							   {PJREN |= BIT2;PJOUT&=~BIT2;}
#define Pin11_PullUpDisable()							    PJREN &= ~BIT2

//O/P
#define Pin11_SetAsOutput()  							    PJDIR |= BIT2
#define Pin11_SetHigh()       		 					    PJOUT |= BIT2
#define Pin11_SetLow()         							    PJOUT &=~ BIT2
#define Pin11_Toggle()        							    PJOUT ^= BIT2;    //V1.4
//I/P
#define Pin11_SetAsInput()   							    PJDIR &=~ BIT2
#define Pin11_Read()          							   (PJIN & BIT2)

//eRIC_Pin12 Definitions
//PullUp/Down Resistor
#define Pin12_PullUpEnable() 							   {PJREN |= BIT1;PJOUT|=BIT1;}
#define Pin12_PullDownEnable()							   {PJREN |= BIT1;PJOUT&=~BIT1;}
#define Pin12_PullUpDisable()							    PJREN &= ~BIT1

//O/P
#define Pin12_SetAsOutput()  							    PJDIR |= BIT1
#define Pin12_SetHigh()        							    PJOUT |= BIT1
#define Pin12_SetLow()         							    PJOUT &=~ BIT1
#define Pin12_Toggle()        							    PJOUT ^= BIT1;    //V1.4
//I/P
#define Pin12_SetAsInput()   							    PJDIR &=~ BIT1
#define Pin12_Read()        						       (PJIN & BIT1)

//eRIC_Pin13 Definitions
//PullUp/Down Resistor
#define Pin13_PullUpEnable()							   {PJREN |= BIT0;PJOUT|=BIT0;}
#define Pin13_PullDownEnable()							   {PJREN |= BIT0;PJOUT&=~BIT0;}
#define Pin13_PullUpDisable()							    PJREN &= ~BIT0

//O/P
#define Pin13_SetAsOutput()  							    PJDIR |= BIT0
#define Pin13_SetHigh()       						        PJOUT |= BIT0
#define Pin13_SetLow()         							    PJOUT &=~ BIT0
#define Pin13_Toggle()        							    PJOUT ^= BIT0;    //V1.4
//I/P
#define Pin13_SetAsInput()    							    PJDIR &=~ BIT0
#define Pin13_Read()         						       (PJIN & BIT0)

//eRIC_Pin14 Definitions
//PullUp/Down Resistor
#define Pin14_PullUpEnable() 							   {P3REN |= BIT7;P3OUT|=BIT7;}
#define Pin14_PullDownEnable()							   {P3REN |= BIT7;P3OUT&=~BIT7;}
#define Pin14_PullUpDisable() 							    P3REN &= ~BIT7

//O/P
#define Pin14_SetAsOutput()  							    P3DIR |= BIT7
#define Pin14_SetHigh()        							    P3OUT |= BIT7
#define Pin14_SetLow()         							    P3OUT &=~ BIT7
#define Pin14_Toggle()         							    P3OUT ^= BIT7;    //V1.4
//I/P
#define Pin14_SetAsInput()   							    P3DIR &=~ BIT7
#define Pin14_Read()         						       (P3IN & BIT7)

//Secondary function mapping
#define Pin14_FunctionIO()          				       {P3SEL &= ~BIT7;}  /* */

#define Pin14_FunctionNone()         					   {PMAPPWD = 0x02D52;P3MAP7 = PM_NONE;PMAPPWD = 0;P3SEL |= BIT7;P3DIR |= BIT7;P3SEL &= ~BIT7;}  /* */

#define Pin14_FunctionAclk()           					   {PMAPPWD = 0x02D52;P3MAP7 = PM_ACLK;PMAPPWD = 0;P3SEL |= BIT7;P3DIR |= BIT7;}
#define Pin14_FunctionMclk()         					   {PMAPPWD = 0x02D52;P3MAP7 = PM_MCLK;PMAPPWD = 0;P3SEL |= BIT7;P3DIR |= BIT7;}
#define Pin14_FunctionSmclk()        					   {PMAPPWD = 0x02D52;P3MAP7 = PM_SMCLK;PMAPPWD = 0;P3SEL |= BIT7;P3DIR |= BIT7;}

#define Pin14_FunctionTA0clkIN()     					   {PMAPPWD = 0x02D52;P3MAP7 = PM_TA0CLK;PMAPPWD = 0;P3SEL |= BIT7;P3DIR &= ~BIT7;}

#define Pin14_FunctionUartATxOUT()   					   {PMAPPWD = 0x02D52;P3MAP7 = PM_UCA0TXD;PMAPPWD = 0;P3SEL |= BIT7;P3DIR |= BIT7;}
#define Pin14_FunctionUartARxD()     					   {PMAPPWD = 0x02D52;P3MAP7 = PM_UCA0RXD;PMAPPWD = 0;P3SEL |= BIT7;}

#define Pin14_FunctionUartABusy()    					   {eRIC_Port2Busy = 0x00; eRIC_Port3Busy = 0x80;Pin14_SetAsOutput();Pin14_SetLow();} /*Set Port Direction*//*Clear the pin*/

#define Pin14_FunctionSpiA_MI()      					   {PMAPPWD = 0x02D52;P3MAP7 = PM_UCA0SOMI;PMAPPWD = 0;P3DIR &= ~BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionSpiA_MO()      					   {PMAPPWD = 0x02D52;P3MAP7 = PM_UCA0SIMO;PMAPPWD = 0;P3DIR |= BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionSpiA_SO()      					   {PMAPPWD = 0x02D52;P3MAP7 = PM_UCA0SOMI;PMAPPWD = 0;P3DIR |= BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionSpiA_SI()      					   {PMAPPWD = 0x02D52;P3MAP7 = PM_UCA0SIMO;PMAPPWD = 0;P3DIR &= ~BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionSpiA_SCLKOUT() 					   {PMAPPWD = 0x02D52;P3MAP7 = PM_UCA0CLK;PMAPPWD = 0;P3DIR |=BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionSpiA_STE()     					   {PMAPPWD = 0x02D52;P3MAP7 = PM_UCA0STE;PMAPPWD = 0;P3SEL |= BIT7;}

#define Pin14_FunctionSpiB_MI()      					   {PMAPPWD = 0x02D52;P3MAP7 = PM_UCB0SOMI;PMAPPWD = 0;P3DIR &= ~BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionSpiB_MO()      					   {PMAPPWD = 0x02D52;P3MAP7 = PM_UCB0SIMO;PMAPPWD = 0;P3DIR |= BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionSpiB_SO()      					   {PMAPPWD = 0x02D52;P3MAP7 = PM_UCB0SOMI;PMAPPWD = 0;P3DIR |= BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionSpiB_SI()      					   {PMAPPWD = 0x02D52;P3MAP7 = PM_UCB0SIMO;PMAPPWD = 0;P3DIR &= ~BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionSpiB_SCLKOUT() 					   {PMAPPWD = 0x02D52;P3MAP7 = PM_UCB0CLK;PMAPPWD = 0;P3DIR |=BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionSpiB_STE()     					   {PMAPPWD = 0x02D52;P3MAP7 = PM_UCB0STE;PMAPPWD = 0;P3SEL |= BIT7;}

#define Pin14_FunctionI2CB_SCl()     					   {PMAPPWD = 0x02D52;P3MAP7 = PM_UCB0SCL;PMAPPWD = 0;P3SEL |= BIT7;}
#define Pin14_FunctionI2CB_SDA()     					   {PMAPPWD = 0x02D52;P3MAP7 = PM_UCB0SDA;PMAPPWD = 0;P3SEL |= BIT7;}

#define Pin14_SetAsAsyncRxData()     					   {PMAPPWD = 0x02D52;P3MAP7 = PM_RFGDO1;PMAPPWD = 0;P3SEL |= BIT7;}
#define Pin14_SetAsAsyncTxData()     					   {PMAPPWD = 0x02D52;P3MAP7 = PM_RFGDO0;PMAPPWD = 0;P3SEL |= BIT7;P3REN |= BIT7;}

#define Pin14_FunctionTA0CompareOut0()					   {PMAPPWD = 0x02D52;P3MAP7 = PM_TA0CCR0A;PMAPPWD = 0;P3DIR |= BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionTA0CompareOut1()					   {PMAPPWD = 0x02D52;P3MAP7 = PM_TA0CCR1A;PMAPPWD = 0;P3DIR |= BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionPWM1()         					   {Pin14_FunctionTA0CompareOut1();}
#define Pin14_FunctionTA0CompareOut2()					   {PMAPPWD = 0x02D52;P3MAP7 = PM_TA0CCR2A;PMAPPWD = 0;P3DIR |= BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionPWM2()          					   {Pin14_FunctionTA0CompareOut2();}
#define Pin14_FunctionTA0CompareOut3()					   {PMAPPWD = 0x02D52;P3MAP7 = PM_TA0CCR3A;PMAPPWD = 0;P3DIR |= BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionPWM3()         					   {Pin14_FunctionTA0CompareOut3();}
#define Pin14_FunctionTA0CompareOut4()					   {PMAPPWD = 0x02D52;P3MAP7 = PM_TA0CCR4A;PMAPPWD = 0;P3DIR |= BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionPWM4()         					   {Pin14_FunctionTA0CompareOut4();}

#define Pin14_FunctionTA0CaptureIn0()					   {PMAPPWD = 0x02D52;P3MAP7 = PM_TA0CCR0A;PMAPPWD = 0;P3DIR &= ~BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionTA0CaptureIn1()					   {PMAPPWD = 0x02D52;P3MAP7 = PM_TA0CCR1A;PMAPPWD = 0;P3DIR &= ~BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionTA0CaptureIn2()					   {PMAPPWD = 0x02D52;P3MAP7 = PM_TA0CCR2A;PMAPPWD = 0;P3DIR &= ~BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionTA0CaptureIn3()					   {PMAPPWD = 0x02D52;P3MAP7 = PM_TA0CCR3A;PMAPPWD = 0;P3DIR &= ~BIT7;P3SEL |= BIT7;}
#define Pin14_FunctionTA0CaptureIn4()					   {PMAPPWD = 0x02D52;P3MAP7 = PM_TA0CCR4A;PMAPPWD = 0;P3DIR &= ~BIT7;P3SEL |= BIT7;}

#define Pin14_FunctionGDOSignal()                          {PMAPPWD = 0x02D52;P3MAP7 = PM_RFGDO2;PMAPPWD = 0;P3SEL |= BIT7;} //V1.5 and eROS V4.1

//eRIC_Pin15 Definitions
//PullUp/Down Resistor
#define Pin15_PullUpEnable() 							   {P3REN |= BIT6;P3OUT|=BIT6;}
#define Pin15_PullDownEnable()							   {P3REN |= BIT6;P3OUT&=~BIT6;}
#define Pin15_PullUpDisable() 							    P3REN &= ~BIT6

//O/P
#define Pin15_SetAsOutput()  							    P3DIR |= BIT6
#define Pin15_SetHigh()        							    P3OUT |= BIT6
#define Pin15_SetLow()         						        P3OUT &=~ BIT6
#define Pin15_Toggle()         							    P3OUT ^= BIT6;    //V1.4
//I/P
#define Pin15_SetAsInput()    							    P3DIR &=~ BIT6
#define Pin15_Read()         	 						   (P3IN & BIT6)

//Secondary function mapping
#define Pin15_FunctionIO()          			           {P3SEL &= ~BIT6;}  /* */

#define Pin15_FunctionNone()        				       {PMAPPWD = 0x02D52;P3MAP6 = PM_NONE;PMAPPWD = 0;P3SEL |= BIT6;P3DIR |= BIT6;P3SEL &= ~BIT6;}  /* */

#define Pin15_FunctionAclk()         					   {PMAPPWD = 0x02D52;P3MAP6 = PM_ACLK;PMAPPWD = 0;P3SEL |= BIT6;P3DIR |= BIT6;}
#define Pin15_FunctionMclk()         					   {PMAPPWD = 0x02D52;P3MAP6 = PM_MCLK;PMAPPWD = 0;P3SEL |= BIT6;P3DIR |= BIT6;}
#define Pin15_FunctionSmclk()        					   {PMAPPWD = 0x02D52;P3MAP6 = PM_SMCLK;PMAPPWD = 0;P3SEL |= BIT6;P3DIR |= BIT6;}

#define Pin15_FunctionTA0clkIN()     					   {PMAPPWD = 0x02D52;P3MAP6 = PM_TA0CLK;PMAPPWD = 0;P3SEL |= BIT6;P3DIR &= ~BIT6;}

#define Pin15_FunctionUartATxOUT()   					   {PMAPPWD = 0x02D52;P3MAP6 = PM_UCA0TXD;PMAPPWD = 0;P3SEL |= BIT6;P3DIR |= BIT6;}
#define Pin15_FunctionUartARxD()     					   {PMAPPWD = 0x02D52;P3MAP6 = PM_UCA0RXD;PMAPPWD = 0;P3SEL |= BIT6;}

#define Pin15_FunctionUartABusy()    					   {eRIC_Port2Busy = 0x00; eRIC_Port3Busy = 0x40;Pin15_SetAsOutput();Pin15_SetLow();} /*Set Port Direction*//*Clear the pin*/

#define Pin15_FunctionSpiA_MI()      					   {PMAPPWD = 0x02D52;P3MAP6 = PM_UCA0SOMI;PMAPPWD = 0;P3DIR &= ~BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionSpiA_MO()      					   {PMAPPWD = 0x02D52;P3MAP6 = PM_UCA0SIMO;PMAPPWD = 0;P3DIR |= BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionSpiA_SO()      					   {PMAPPWD = 0x02D52;P3MAP6 = PM_UCA0SOMI;PMAPPWD = 0;P3DIR |= BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionSpiA_SI()      					   {PMAPPWD = 0x02D52;P3MAP6 = PM_UCA0SIMO;PMAPPWD = 0;P3DIR &= ~BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionSpiA_SCLKOUT() 					   {PMAPPWD = 0x02D52;P3MAP6 = PM_UCA0CLK;PMAPPWD = 0;P3DIR |=BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionSpiA_STE()     					   {PMAPPWD = 0x02D52;P3MAP6 = PM_UCA0STE;PMAPPWD = 0;P3SEL |= BIT6;}

#define Pin15_FunctionSpiB_MI()      					   {PMAPPWD = 0x02D52;P3MAP6 = PM_UCB0SOMI;PMAPPWD = 0;P3DIR &= ~BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionSpiB_MO()      					   {PMAPPWD = 0x02D52;P3MAP6 = PM_UCB0SIMO;PMAPPWD = 0;P3DIR |= BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionSpiB_SO()      					   {PMAPPWD = 0x02D52;P3MAP6 = PM_UCB0SOMI;PMAPPWD = 0;P3DIR |= BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionSpiB_SI()      					   {PMAPPWD = 0x02D52;P3MAP6 = PM_UCB0SIMO;PMAPPWD = 0;P3DIR &= ~BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionSpiB_SCLKOUT() 					   {PMAPPWD = 0x02D52;P3MAP6 = PM_UCB0CLK;PMAPPWD = 0;P3DIR |=BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionSpiB_STE()     					   {PMAPPWD = 0x02D52;P3MAP6 = PM_UCB0STE;PMAPPWD = 0;P3SEL |= BIT6;}

#define Pin15_FunctionI2CB_SCl()     					   {PMAPPWD = 0x02D52;P3MAP6 = PM_UCB0SCL;PMAPPWD = 0;P3SEL |= BIT6;}
#define Pin15_FunctionI2CB_SDA()     					   {PMAPPWD = 0x02D52;P3MAP6 = PM_UCB0SDA;PMAPPWD = 0;P3SEL |= BIT6;}

#define Pin15_SetAsAsyncRxData()      				       {PMAPPWD = 0x02D52;P3MAP6 = PM_RFGDO1;PMAPPWD = 0;P3SEL |= BIT6;}
#define Pin15_SetAsAsyncTxData()       					   {PMAPPWD = 0x02D52;P3MAP6 = PM_RFGDO0;PMAPPWD = 0;P3SEL |= BIT6;P3REN |= BIT6;}

#define Pin15_FunctionTA0CompareOut0()					   {PMAPPWD = 0x02D52;P3MAP6 = PM_TA0CCR0A;PMAPPWD = 0;P3DIR |= BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionTA0CompareOut1()					   {PMAPPWD = 0x02D52;P3MAP6 = PM_TA0CCR1A;PMAPPWD = 0;P3DIR |= BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionPWM1()         					   {Pin15_FunctionTA0CompareOut1();}
#define Pin15_FunctionTA0CompareOut2()					   {PMAPPWD = 0x02D52;P3MAP6 = PM_TA0CCR2A;PMAPPWD = 0;P3DIR |= BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionPWM2()         					   {Pin15_FunctionTA0CompareOut2();}
#define Pin15_FunctionTA0CompareOut3()					   {PMAPPWD = 0x02D52;P3MAP6 = PM_TA0CCR3A;PMAPPWD = 0;P3DIR |= BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionPWM3()         					   {Pin15_FunctionTA0CompareOut3();}
#define Pin15_FunctionTA0CompareOut4()					   {PMAPPWD = 0x02D52;P3MAP6 = PM_TA0CCR4A;PMAPPWD = 0;P3DIR |= BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionPWM4()         					   {Pin15_FunctionTA0CompareOut4();}

#define Pin15_FunctionTA0CaptureIn0()					   {PMAPPWD = 0x02D52;P3MAP6 = PM_TA0CCR0A;PMAPPWD = 0;P3DIR &= ~BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionTA0CaptureIn1()					   {PMAPPWD = 0x02D52;P3MAP6 = PM_TA0CCR1A;PMAPPWD = 0;P3DIR &= ~BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionTA0CaptureIn2()					   {PMAPPWD = 0x02D52;P3MAP6 = PM_TA0CCR2A;PMAPPWD = 0;P3DIR &= ~BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionTA0CaptureIn3()					   {PMAPPWD = 0x02D52;P3MAP6 = PM_TA0CCR3A;PMAPPWD = 0;P3DIR &= ~BIT6;P3SEL |= BIT6;}
#define Pin15_FunctionTA0CaptureIn4() 				       {PMAPPWD = 0x02D52;P3MAP6 = PM_TA0CCR4A;PMAPPWD = 0;P3DIR &= ~BIT6;P3SEL |= BIT6;}

#define Pin15_FunctionGDOSignal()                          {PMAPPWD = 0x02D52;P3MAP6 = PM_RFGDO2;PMAPPWD = 0;P3SEL |= BIT6;} //V1.5 and eROS V4.1

//eRIC_Pin16 Definitions
//PullUp/Down Resistor
#define Pin16_PullUpEnable() 							   {P3REN |= BIT5;P3OUT|=BIT5;}
#define Pin16_PullDownEnable()							   {P3REN |= BIT5;P3OUT&=~BIT5;}
#define Pin16_PullUpDisable() 							    P3REN &= ~BIT5

//O/P
#define Pin16_SetAsOutput()   							    P3DIR |= BIT5
#define Pin16_SetHigh()        							    P3OUT |= BIT5
#define Pin16_SetLow()         							    P3OUT &=~ BIT5
#define Pin16_Toggle()        							    P3OUT ^= BIT5;  //V1.4
//I/P
#define Pin16_SetAsInput()   							    P3DIR &=~ BIT5
#define Pin16_Read()          							   (P3IN & BIT5)

#define Pin16_HighDriveStrength_15mA()					   {P3DS |= BIT5;}    /*Sets Logic High and Low of pins for  High Drive strength */
#define PIn16_LowDriveStrength_6mA()					   {P3DS &= ~BIT5;}    /*Sets Logic High and Low of pins for  Low Drive strength */

//Secondary function mapping
#define Pin16_FunctionIO()       	 	   				   {P3SEL &= ~BIT5;}  /* */

#define Pin16_FunctionNone()         					   {PMAPPWD = 0x02D52;P3MAP5 = PM_NONE;PMAPPWD = 0;P3SEL |= BIT5;P3DIR |= BIT5;P3SEL &= ~BIT5;}  /* */

#define Pin16_FunctionAclk()         					   {PMAPPWD = 0x02D52;P3MAP5 = PM_ACLK;PMAPPWD = 0;P3SEL |= BIT5;P3DIR |= BIT5;}
#define Pin16_FunctionMclk()         					   {PMAPPWD = 0x02D52;P3MAP5 = PM_MCLK;PMAPPWD = 0;P3SEL |= BIT5;P3DIR |= BIT5;}
#define Pin16_FunctionSmclk()        					   {PMAPPWD = 0x02D52;P3MAP5 = PM_SMCLK;PMAPPWD = 0;P3SEL |= BIT5;P3DIR |= BIT5;}

#define Pin16_FunctionTA0clkIN()     					   {PMAPPWD = 0x02D52;P3MAP5 = PM_TA0CLK;PMAPPWD = 0;P3SEL |= BIT5;P3DIR &= ~BIT5;}

#define Pin16_FunctionUartATxOUT()   					   {PMAPPWD = 0x02D52;P3MAP5 = PM_UCA0TXD;PMAPPWD = 0;P3SEL |= BIT5;P3DIR |= BIT5;}
#define Pin16_FunctionUartARxD()      					   {PMAPPWD = 0x02D52;P3MAP5 = PM_UCA0RXD;PMAPPWD = 0;P3SEL |= BIT5;}

#define Pin16_FunctionUartABusy()    					   {eRIC_Port2Busy = 0x00; eRIC_Port3Busy = 0x20;Pin16_SetAsOutput();Pin16_SetLow();} /*Set Port Direction*//*Clear the pin*/

#define Pin16_FunctionSpiA_MI()      					   {PMAPPWD = 0x02D52;P3MAP5 = PM_UCA0SOMI;PMAPPWD = 0;P3DIR &= ~BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionSpiA_MO()      					   {PMAPPWD = 0x02D52;P3MAP5 = PM_UCA0SIMO;PMAPPWD = 0;P3DIR |= BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionSpiA_SO()      					   {PMAPPWD = 0x02D52;P3MAP5 = PM_UCA0SOMI;PMAPPWD = 0;P3DIR |= BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionSpiA_SI()      					   {PMAPPWD = 0x02D52;P3MAP5 = PM_UCA0SIMO;PMAPPWD = 0;P3DIR &= ~BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionSpiA_SCLKOUT()  					   {PMAPPWD = 0x02D52;P3MAP5 = PM_UCA0CLK;PMAPPWD = 0;P3DIR |=BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionSpiA_STE()     					   {PMAPPWD = 0x02D52;P3MAP5 = PM_UCA0STE;PMAPPWD = 0;P3SEL |= BIT5;}

#define Pin16_FunctionSpiB_MI()      					   {PMAPPWD = 0x02D52;P3MAP5 = PM_UCB0SOMI;PMAPPWD = 0;P3DIR &= ~BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionSpiB_MO()      					   {PMAPPWD = 0x02D52;P3MAP5 = PM_UCB0SIMO;PMAPPWD = 0;P3DIR |= BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionSpiB_SO()      					   {PMAPPWD = 0x02D52;P3MAP5 = PM_UCB0SOMI;PMAPPWD = 0;P3DIR |= BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionSpiB_SI()      					   {PMAPPWD = 0x02D52;P3MAP5 = PM_UCB0SIMO;PMAPPWD = 0;P3DIR &= ~BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionSpiB_SCLKOUT() 					   {PMAPPWD = 0x02D52;P3MAP5 = PM_UCB0CLK;PMAPPWD = 0;P3DIR |=BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionSpiB_STE()     					   {PMAPPWD = 0x02D52;P3MAP5 = PM_UCB0STE;PMAPPWD = 0;P3SEL |= BIT5;}

#define Pin16_FunctionI2CB_SCl()     					   {PMAPPWD = 0x02D52;P3MAP5 = PM_UCB0SCL;PMAPPWD = 0;P3SEL |= BIT5;}
#define Pin16_FunctionI2CB_SDA()     					   {PMAPPWD = 0x02D52;P3MAP5 = PM_UCB0SDA;PMAPPWD = 0;P3SEL |= BIT5;}

#define Pin16_SetAsAsyncRxData()       					   {PMAPPWD = 0x02D52;P3MAP5 = PM_RFGDO1;PMAPPWD = 0;P3SEL |= BIT5;}
#define Pin16_SetAsAsyncTxData()       					   {PMAPPWD = 0x02D52;P3MAP5 = PM_RFGDO0;PMAPPWD = 0;P3SEL |= BIT5;P3REN |= BIT5;}

#define Pin16_FunctionTA0CompareOut0()					   {PMAPPWD = 0x02D52;P3MAP5 = PM_TA0CCR0A;PMAPPWD = 0;P3DIR |= BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionTA0CompareOut1()					   {PMAPPWD = 0x02D52;P3MAP5 = PM_TA0CCR1A;PMAPPWD = 0;P3DIR |= BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionPWM1()         					   {Pin16_FunctionTA0CompareOut1();}
#define Pin16_FunctionTA0CompareOut2()					   {PMAPPWD = 0x02D52;P3MAP5 = PM_TA0CCR2A;PMAPPWD = 0;P3DIR |= BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionPWM2()         					   {Pin16_FunctionTA0CompareOut2();}
#define Pin16_FunctionTA0CompareOut3()					   {PMAPPWD = 0x02D52;P3MAP5 = PM_TA0CCR3A;PMAPPWD = 0;P3DIR |= BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionPWM3()         					   {Pin16_FunctionTA0CompareOut3();}
#define Pin16_FunctionTA0CompareOut4()					   {PMAPPWD = 0x02D52;P3MAP5 = PM_TA0CCR4A;PMAPPWD = 0;P3DIR |= BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionPWM4()         					   {Pin16_FunctionTA0CompareOut4();}

#define Pin16_FunctionTA0CaptureIn0() 					   {PMAPPWD = 0x02D52;P3MAP5 = PM_TA0CCR0A;PMAPPWD = 0;P3DIR &= ~BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionTA0CaptureIn1()					   {PMAPPWD = 0x02D52;P3MAP5 = PM_TA0CCR1A;PMAPPWD = 0;P3DIR &= ~BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionTA0CaptureIn2()					   {PMAPPWD = 0x02D52;P3MAP5 = PM_TA0CCR2A;PMAPPWD = 0;P3DIR &= ~BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionTA0CaptureIn3()					   {PMAPPWD = 0x02D52;P3MAP5 = PM_TA0CCR3A;PMAPPWD = 0;P3DIR &= ~BIT5;P3SEL |= BIT5;}
#define Pin16_FunctionTA0CaptureIn4()					   {PMAPPWD = 0x02D52;P3MAP5 = PM_TA0CCR4A;PMAPPWD = 0;P3DIR &= ~BIT5;P3SEL |= BIT5;}

#define Pin16_FunctionGDOSignal()                          {PMAPPWD = 0x02D52;P3MAP5 = PM_RFGDO2;PMAPPWD = 0;P3SEL |= BIT5;} //V1.5 and eROS V4.1

//eRIC_Pin17 Definitions
//PullUp/Down Resistor
#define Pin17_PullUpEnable() 							   {P3REN |= BIT4;P3OUT|=BIT4;}
#define Pin17_PullDownEnable()							   {P3REN |= BIT4;P3OUT&=~BIT4;}
#define Pin17_PullUpDisable() 							    P3REN &= ~BIT4

//O/P
#define Pin17_SetAsOutput()  	 						    P3DIR |= BIT4
#define Pin17_SetHigh()        			 				    P3OUT |= BIT4
#define Pin17_SetLow()          						    P3OUT &=~ BIT4
#define Pin17_Toggle()         							    P3OUT ^= BIT4;    //V1.4
//I/P
#define Pin17_SetAsInput()   							    P3DIR &=~ BIT4
#define Pin17_Read()         						       (P3IN & BIT4)
#define Pin17_HighDriveStrength_15mA()					   {P3DS |= BIT4;}    /*Sets Logic High and Low of pins for  High Drive strength */
#define PIn17_LowDriveStrength_6mA()					   {P3DS &= ~BIT4;}    /*Sets Logic High and Low of pins for  Low Drive strength */

//Secondary function mapping
#define Pin17_FunctionIO()          					   {P3SEL &= ~BIT4;}  /* */

#define Pin17_FunctionNone()         					   {PMAPPWD = 0x02D52;P3MAP4 = PM_NONE;PMAPPWD = 0;P3SEL |= BIT4;P3DIR |= BIT4;P3SEL &= ~BIT4;}  /* */

#define Pin17_FunctionAclk()         					   {PMAPPWD = 0x02D52;P3MAP4 = PM_ACLK;PMAPPWD = 0;P3SEL |= BIT4;P3DIR |= BIT4;}
#define Pin17_FunctionMclk()         					   {PMAPPWD = 0x02D52;P3MAP4 = PM_MCLK;PMAPPWD = 0;P3SEL |= BIT4;P3DIR |= BIT4;}
#define Pin17_FunctionSmclk()        					   {PMAPPWD = 0x02D52;P3MAP4 = PM_SMCLK;PMAPPWD = 0;P3SEL |= BIT4;P3DIR |= BIT4;}

#define Pin17_FunctionTA0clkIN()     					   {PMAPPWD = 0x02D52;P3MAP4 = PM_TA0CLK;PMAPPWD = 0;P3SEL |= BIT4;P3DIR &= ~BIT4;}

#define Pin17_FunctionUartATxOUT()   					   {PMAPPWD = 0x02D52;P3MAP4 = PM_UCA0TXD;PMAPPWD = 0;P3SEL |= BIT4;P3DIR |= BIT4;}
#define Pin17_FunctionUartARxD()     					   {PMAPPWD = 0x02D52;P3MAP4 = PM_UCA0RXD;PMAPPWD = 0;P3SEL |= BIT4;}

#define Pin17_FunctionUartABusy()    					   {eRIC_Port2Busy = 0x00; eRIC_Port3Busy = 0x10;Pin17_SetAsOutput();Pin17_SetLow();} /*Set Port Direction*//*Clear the pin*/

#define Pin17_FunctionSpiA_MI()      					   {PMAPPWD = 0x02D52;P3MAP4 = PM_UCA0SOMI;PMAPPWD = 0;P3DIR &= ~BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionSpiA_MO()      					   {PMAPPWD = 0x02D52;P3MAP4 = PM_UCA0SIMO;PMAPPWD = 0;P3DIR |= BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionSpiA_SO()      					   {PMAPPWD = 0x02D52;P3MAP4 = PM_UCA0SOMI;PMAPPWD = 0;P3DIR |= BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionSpiA_SI()      					   {PMAPPWD = 0x02D52;P3MAP4 = PM_UCA0SIMO;PMAPPWD = 0;P3DIR &= ~BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionSpiA_SCLKOUT() 					   {PMAPPWD = 0x02D52;P3MAP4 = PM_UCA0CLK;PMAPPWD = 0;P3DIR |=BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionSpiA_STE()     					   {PMAPPWD = 0x02D52;P3MAP4 = PM_UCA0STE;PMAPPWD = 0;P3SEL |= BIT4;}

#define Pin17_FunctionSpiB_MI()      					   {PMAPPWD = 0x02D52;P3MAP4 = PM_UCB0SOMI;PMAPPWD = 0;P3DIR &= ~BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionSpiB_MO()      					   {PMAPPWD = 0x02D52;P3MAP4 = PM_UCB0SIMO;PMAPPWD = 0;P3DIR |= BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionSpiB_SO()     	 				   {PMAPPWD = 0x02D52;P3MAP4 = PM_UCB0SOMI;PMAPPWD = 0;P3DIR |= BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionSpiB_SI()      					   {PMAPPWD = 0x02D52;P3MAP4 = PM_UCB0SIMO;PMAPPWD = 0;P3DIR &= ~BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionSpiB_SCLKOUT() 					   {PMAPPWD = 0x02D52;P3MAP4 = PM_UCB0CLK;PMAPPWD = 0;P3DIR |=BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionSpiB_STE()     					   {PMAPPWD = 0x02D52;P3MAP4 = PM_UCB0STE;PMAPPWD = 0;P3SEL |= BIT4;}

#define Pin17_FunctionI2CB_SCl()     					   {PMAPPWD = 0x02D52;P3MAP4 = PM_UCB0SCL;PMAPPWD = 0;P3SEL |= BIT4;}
#define Pin17_FunctionI2CB_SDA()     					   {PMAPPWD = 0x02D52;P3MAP4 = PM_UCB0SDA;PMAPPWD = 0;P3SEL |= BIT4;}

#define Pin17_SetAsAsyncRxData()       					   {PMAPPWD = 0x02D52;P3MAP4 = PM_RFGDO1;PMAPPWD = 0;P3SEL |= BIT4;}
#define Pin17_SetAsAsyncTxData()       					   {PMAPPWD = 0x02D52;P3MAP4 = PM_RFGDO0;PMAPPWD = 0;P3SEL |= BIT4;P3REN |= BIT4;}

#define Pin17_FunctionTA0CompareOut0()					   {PMAPPWD = 0x02D52;P3MAP4 = PM_TA0CCR0A;PMAPPWD = 0;P3DIR |= BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionTA0CompareOut1()					   {PMAPPWD = 0x02D52;P3MAP4 = PM_TA0CCR1A;PMAPPWD = 0;P3DIR |= BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionPWM1()         					   {Pin17_FunctionTA0CompareOut1();}
#define Pin17_FunctionTA0CompareOut2()					   {PMAPPWD = 0x02D52;P3MAP4 = PM_TA0CCR2A;PMAPPWD = 0;P3DIR |= BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionPWM2()         					   {Pin17_FunctionTA0CompareOut2();}
#define Pin17_FunctionTA0CompareOut3()					   {PMAPPWD = 0x02D52;P3MAP4 = PM_TA0CCR3A;PMAPPWD = 0;P3DIR |= BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionPWM3()         					   {Pin17_FunctionTA0CompareOut3();}
#define Pin17_FunctionTA0CompareOut4()					   {PMAPPWD = 0x02D52;P3MAP4 = PM_TA0CCR4A;PMAPPWD = 0;P3DIR |= BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionPWM4()        				       {Pin17_FunctionTA0CompareOut4();}

#define Pin17_FunctionTA0CaptureIn0()					   {PMAPPWD = 0x02D52;P3MAP4 = PM_TA0CCR0A;PMAPPWD = 0;P3DIR &= ~BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionTA0CaptureIn1()					   {PMAPPWD = 0x02D52;P3MAP4 = PM_TA0CCR1A;PMAPPWD = 0;P3DIR &= ~BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionTA0CaptureIn2()					   {PMAPPWD = 0x02D52;P3MAP4 = PM_TA0CCR2A;PMAPPWD = 0;P3DIR &= ~BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionTA0CaptureIn3()					   {PMAPPWD = 0x02D52;P3MAP4 = PM_TA0CCR3A;PMAPPWD = 0;P3DIR &= ~BIT4;P3SEL |= BIT4;}
#define Pin17_FunctionTA0CaptureIn4()					   {PMAPPWD = 0x02D52;P3MAP4 = PM_TA0CCR4A;PMAPPWD = 0;P3DIR &= ~BIT4;P3SEL |= BIT4;}

#define Pin17_FunctionGDOSignal()                          {PMAPPWD = 0x02D52;P3MAP4 = PM_RFGDO2;PMAPPWD = 0;P3SEL |= BIT4;} //V1.5 and eROS V4.1

//eRIC_Pin18 Definitions
//PullUp/Down Resistor
#define Pin18_PullUpEnable() 							   {P3REN |= BIT3;P3OUT|=BIT3;}
#define Pin18_PullDownEnable()							   {P3REN |= BIT3;P3OUT&=~BIT3;}
#define Pin18_PullUpDisable() 							    P3REN &= ~BIT3

//O/P
#define Pin18_SetAsOutput()   							    P3DIR |= BIT3
#define Pin18_SetHigh()        							    P3OUT |= BIT3
#define Pin18_SetLow()         							    P3OUT &=~ BIT3
#define Pin18_Toggle()        							    P3OUT ^= BIT3;    //V1.4
//I/P
#define Pin18_SetAsInput()   							    P3DIR &=~ BIT3
#define Pin18_Read()         						       (P3IN & BIT3)
#define Pin18_HighDriveStrength_15mA()					   {P3DS |= BIT3;}    /*Sets Logic High and Low of pins for  High Drive strength */
#define PIn18_LowDriveStrength_6mA()					   {P3DS &= ~BIT3;}    /*Sets Logic High and Low of pins for  Low Drive strength */

//Secondary function mapping
#define Pin18_FunctionIO()          				       {P3SEL &= ~BIT3;}  /* */

#define Pin18_FunctionNone()        				       {PMAPPWD = 0x02D52;P3MAP3 = PM_NONE;PMAPPWD = 0;P3SEL |= BIT3;P3DIR |= BIT3;P3SEL &= ~BIT3;}  /* */

#define Pin18_FunctionAclk()        				       {PMAPPWD = 0x02D52;P3MAP3 = PM_ACLK;PMAPPWD = 0;P3SEL |= BIT3;P3DIR |= BIT3;}
#define Pin18_FunctionMclk()        				       {PMAPPWD = 0x02D52;P3MAP3 = PM_MCLK;PMAPPWD = 0;P3SEL |= BIT3;P3DIR |= BIT3;}
#define Pin18_FunctionSmclk()        					   {PMAPPWD = 0x02D52;P3MAP3 = PM_SMCLK;PMAPPWD = 0;P3SEL |= BIT3;P3DIR |= BIT3;}

#define Pin18_FunctionTA0clkIN()     					   {PMAPPWD = 0x02D52;P3MAP3 = PM_TA0CLK;PMAPPWD = 0;P3SEL |= BIT3;P3DIR &= ~BIT3;}

#define Pin18_FunctionUartATxOUT()   					   {PMAPPWD = 0x02D52;P3MAP3 = PM_UCA0TXD;PMAPPWD = 0;P3SEL |= BIT3;P3DIR |= BIT3;}
#define Pin18_FunctionUartARxD()     					   {PMAPPWD = 0x02D52;P3MAP3 = PM_UCA0RXD;PMAPPWD = 0;P3SEL |= BIT3;}

#define Pin18_FunctionUartABusy()    					   {eRIC_Port2Busy = 0x00; eRIC_Port3Busy = 0x08;Pin18_SetAsOutput();Pin18_SetLow();} /*Set Port Direction*//*Clear the pin*/

#define Pin18_FunctionSpiA_MI()      					   {PMAPPWD = 0x02D52;P3MAP3 = PM_UCA0SOMI;PMAPPWD = 0;P3DIR &= ~BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionSpiA_MO()      					   {PMAPPWD = 0x02D52;P3MAP3 = PM_UCA0SIMO;PMAPPWD = 0;P3DIR |= BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionSpiA_SO()      					   {PMAPPWD = 0x02D52;P3MAP3 = PM_UCA0SOMI;PMAPPWD = 0;P3DIR |= BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionSpiA_SI()      					   {PMAPPWD = 0x02D52;P3MAP3 = PM_UCA0SIMO;PMAPPWD = 0;P3DIR &= ~BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionSpiA_SCLKOUT() 					   {PMAPPWD = 0x02D52;P3MAP3 = PM_UCA0CLK;PMAPPWD = 0;P3DIR |=BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionSpiA_STE()     					   {PMAPPWD = 0x02D52;P3MAP3 = PM_UCA0STE;PMAPPWD = 0;P3SEL |= BIT3;}

#define Pin18_FunctionSpiB_MI()      					   {PMAPPWD = 0x02D52;P3MAP3 = PM_UCB0SOMI;PMAPPWD = 0;P3DIR &= ~BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionSpiB_MO()      					   {PMAPPWD = 0x02D52;P3MAP3 = PM_UCB0SIMO;PMAPPWD = 0;P3DIR |= BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionSpiB_SO()      					   {PMAPPWD = 0x02D52;P3MAP3 = PM_UCB0SOMI;PMAPPWD = 0;P3DIR |= BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionSpiB_SI()      					   {PMAPPWD = 0x02D52;P3MAP3 = PM_UCB0SIMO;PMAPPWD = 0;P3DIR &= ~BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionSpiB_SCLKOUT() 					   {PMAPPWD = 0x02D52;P3MAP3 = PM_UCB0CLK;PMAPPWD = 0;P3DIR |=BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionSpiB_STE()     					   {PMAPPWD = 0x02D52;P3MAP3 = PM_UCB0STE;PMAPPWD = 0;P3SEL |= BIT3;}

#define Pin18_FunctionI2CB_SCl()     					   {PMAPPWD = 0x02D52;P3MAP3 = PM_UCB0SCL;PMAPPWD = 0;P3SEL |= BIT3;}
#define Pin18_FunctionI2CB_SDA()     					   {PMAPPWD = 0x02D52;P3MAP3 = PM_UCB0SDA;PMAPPWD = 0;P3SEL |= BIT3;}

#define Pin18_SetAsAsyncRxData()      				       {PMAPPWD = 0x02D52;P3MAP3 = PM_RFGDO1;PMAPPWD = 0;P3SEL |= BIT3;}
#define Pin18_SetAsAsyncTxData()       					   {PMAPPWD = 0x02D52;P3MAP3 = PM_RFGDO0;PMAPPWD = 0;P3SEL |= BIT3;P3REN |= BIT3;}

#define Pin18_FunctionTA0CompareOut0()					   {PMAPPWD = 0x02D52;P3MAP3 = PM_TA0CCR0A;PMAPPWD = 0;P3DIR |= BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionTA0CompareOut1()					   {PMAPPWD = 0x02D52;P3MAP3 = PM_TA0CCR1A;PMAPPWD = 0;P3DIR |= BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionPWM1()        				       {Pin18_FunctionTA0CompareOut1();}
#define Pin18_FunctionTA0CompareOut2()					   {PMAPPWD = 0x02D52;P3MAP3 = PM_TA0CCR2A;PMAPPWD = 0;P3DIR |= BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionPWM2()        	 				   {Pin18_FunctionTA0CompareOut2();}
#define Pin18_FunctionTA0CompareOut3()					   {PMAPPWD = 0x02D52;P3MAP3 = PM_TA0CCR3A;PMAPPWD = 0;P3DIR |= BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionPWM3()        				       {Pin18_FunctionTA0CompareOut3();}
#define Pin18_FunctionTA0CompareOut4()					   {PMAPPWD = 0x02D52;P3MAP3 = PM_TA0CCR4A;PMAPPWD = 0;P3DIR |= BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionPWM4()         					   {Pin18_FunctionTA0CompareOut4();}

#define Pin18_FunctionTA0CaptureIn0()					   {PMAPPWD = 0x02D52;P3MAP3 = PM_TA0CCR0A;PMAPPWD = 0;P3DIR &= ~BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionTA0CaptureIn1()					   {PMAPPWD = 0x02D52;P3MAP3 = PM_TA0CCR1A;PMAPPWD = 0;P3DIR &= ~BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionTA0CaptureIn2()					   {PMAPPWD = 0x02D52;P3MAP3 = PM_TA0CCR2A;PMAPPWD = 0;P3DIR &= ~BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionTA0CaptureIn3()					   {PMAPPWD = 0x02D52;P3MAP3 = PM_TA0CCR3A;PMAPPWD = 0;P3DIR &= ~BIT3;P3SEL |= BIT3;}
#define Pin18_FunctionTA0CaptureIn4()					   {PMAPPWD = 0x02D52;P3MAP3 = PM_TA0CCR4A;PMAPPWD = 0;P3DIR &= ~BIT3;P3SEL |= BIT3;}

#define Pin18_FunctionGDOSignal()                          {PMAPPWD = 0x02D52;P3MAP3 = PM_RFGDO2;PMAPPWD = 0;P3SEL |= BIT3;} //V1.5 and eROS V4.1

//eRIC_Pin19 Definitions
//PullUp/Down Resistor
#define Pin19_PullUpEnable() 							   {P3REN |= BIT2;P3OUT|=BIT2;}
#define Pin19_PullDownEnable()							   {P3REN |= BIT2;P3OUT&=~BIT2;}
#define Pin19_PullUpDisable() 							    P3REN &= ~BIT2

//O/P
#define Pin19_SetAsOutput()   							    P3DIR |= BIT2
#define Pin19_SetHigh()        							    P3OUT |= BIT2
#define Pin19_SetLow()         							    P3OUT &=~ BIT2
#define Pin19_Toggle()        							    P3OUT ^= BIT2;    //V1.4

//I/P
#define Pin19_SetAsInput()   							    P3DIR &=~ BIT2
#define Pin19_Read()         						       (P3IN & BIT2)
#define Pin19_HighDriveStrength_15mA()					   {P3DS |= BIT2;}    /*Sets Logic High and Low of pins for  High Drive strength */
#define PIn19_LowDriveStrength_6mA()					   {P3DS &= ~BIT2;}    /*Sets Logic High and Low of pins for  Low Drive strength */

//Secondary function mapping
#define Pin19_FunctionIO()          				       {P3SEL &= ~BIT2;}  /* */

#define Pin19_FunctionNone()         					   {PMAPPWD = 0x02D52;P3MAP2 = PM_NONE;PMAPPWD = 0;P3SEL |= BIT2;P3DIR |= BIT2;P3SEL &= ~BIT2;}  /* */

#define Pin19_FunctionAclk()         					   {PMAPPWD = 0x02D52;P3MAP2 = PM_ACLK;PMAPPWD = 0;P3SEL |= BIT2;P3DIR |= BIT2;}
#define Pin19_FunctionMclk()         					   {PMAPPWD = 0x02D52;P3MAP2 = PM_MCLK;PMAPPWD = 0;P3SEL |= BIT2;P3DIR |= BIT2;}
#define Pin19_FunctionSmclk()        					   {PMAPPWD = 0x02D52;P3MAP2 = PM_SMCLK;PMAPPWD = 0;P3SEL |= BIT2;P3DIR |= BIT2;}

#define Pin19_FunctionTA0clkIN()     					   {PMAPPWD = 0x02D52;P3MAP2 = PM_TA0CLK;PMAPPWD = 0;P3SEL |= BIT2;P3DIR &= ~BIT2;}

#define Pin19_FunctionUartATxOUT()   					   {PMAPPWD = 0x02D52;P3MAP2 = PM_UCA0TXD;PMAPPWD = 0;P3SEL |= BIT2;P3DIR |= BIT2;}
#define Pin19_FunctionUartARxD()     					   {PMAPPWD = 0x02D52;P3MAP2 = PM_UCA0RXD;PMAPPWD = 0;P3SEL |= BIT2;}

#define Pin19_FunctionUartABusy()    					   {eRIC_Port2Busy = 0x00; eRIC_Port3Busy = 0x04;Pin19_SetAsOutput();Pin19_SetLow();} /*Set Port Direction*//*Clear the pin*/

#define Pin19_FunctionSpiA_MI()      					   {PMAPPWD = 0x02D52;P3MAP2 = PM_UCA0SOMI;PMAPPWD = 0;P3DIR &= ~BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionSpiA_MO()      					   {PMAPPWD = 0x02D52;P3MAP2 = PM_UCA0SIMO;PMAPPWD = 0;P3DIR |= BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionSpiA_SO()      					   {PMAPPWD = 0x02D52;P3MAP2 = PM_UCA0SOMI;PMAPPWD = 0;P3DIR |= BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionSpiA_SI()      					   {PMAPPWD = 0x02D52;P3MAP2 = PM_UCA0SIMO;PMAPPWD = 0;P3DIR &= ~BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionSpiA_SCLKOUT() 					   {PMAPPWD = 0x02D52;P3MAP2 = PM_UCA0CLK;PMAPPWD = 0;P3DIR |=BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionSpiA_STE()     					   {PMAPPWD = 0x02D52;P3MAP2 = PM_UCA0STE;PMAPPWD = 0;P3SEL |= BIT2;}

#define Pin19_FunctionSpiB_MI()      					   {PMAPPWD = 0x02D52;P3MAP2 = PM_UCB0SOMI;PMAPPWD = 0;P3DIR &= ~BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionSpiB_MO()      					   {PMAPPWD = 0x02D52;P3MAP2 = PM_UCB0SIMO;PMAPPWD = 0;P3DIR |= BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionSpiB_SO()      					   {PMAPPWD = 0x02D52;P3MAP2 = PM_UCB0SOMI;PMAPPWD = 0;P3DIR |= BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionSpiB_SI()      					   {PMAPPWD = 0x02D52;P3MAP2 = PM_UCB0SIMO;PMAPPWD = 0;P3DIR &= ~BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionSpiB_SCLKOUT() 					   {PMAPPWD = 0x02D52;P3MAP2 = PM_UCB0CLK;PMAPPWD = 0;P3DIR |=BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionSpiB_STE()     					   {PMAPPWD = 0x02D52;P3MAP2 = PM_UCB0STE;PMAPPWD = 0;P3SEL |= BIT2;}

#define Pin19_FunctionI2CB_SCl()     					   {PMAPPWD = 0x02D52;P3MAP2 = PM_UCB0SCL;PMAPPWD = 0;P3SEL |= BIT2;}
#define Pin19_FunctionI2CB_SDA()    	 				   {PMAPPWD = 0x02D52;P3MAP2 = PM_UCB0SDA;PMAPPWD = 0;P3SEL |= BIT2;}

#define Pin19_SetAsAsyncRxData()      				       {PMAPPWD = 0x02D52;P3MAP2 = PM_RFGDO1;PMAPPWD = 0;P3SEL |= BIT2;}
#define Pin19_SetAsAsyncTxData()       					   {PMAPPWD = 0x02D52;P3MAP2 = PM_RFGDO0;PMAPPWD = 0;P3SEL |= BIT2;P3REN |= BIT2;}

#define Pin19_FunctionTA0CompareOut0()					   {PMAPPWD = 0x02D52;P3MAP2 = PM_TA0CCR0A;PMAPPWD = 0;P3DIR |= BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionTA0CompareOut1()					   {PMAPPWD = 0x02D52;P3MAP2 = PM_TA0CCR1A;PMAPPWD = 0;P3DIR |= BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionPWM1()         					   {Pin19_FunctionTA0CompareOut1();}
#define Pin19_FunctionTA0CompareOut2()					   {PMAPPWD = 0x02D52;P3MAP2 = PM_TA0CCR2A;PMAPPWD = 0;P3DIR |= BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionPWM2()         					   {Pin19_FunctionTA0CompareOut2();}
#define Pin19_FunctionTA0CompareOut3()					   {PMAPPWD = 0x02D52;P3MAP2 = PM_TA0CCR3A;PMAPPWD = 0;P3DIR |= BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionPWM3()         					   {Pin19_FunctionTA0CompareOut3();}
#define Pin19_FunctionTA0CompareOut4()					   {PMAPPWD = 0x02D52;P3MAP2 = PM_TA0CCR4A;PMAPPWD = 0;P3DIR |= BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionPWM4()         					   {Pin19_FunctionTA0CompareOut4();}

#define Pin19_FunctionTA0CaptureIn0()					   {PMAPPWD = 0x02D52;P3MAP2 = PM_TA0CCR0A;PMAPPWD = 0;P3DIR &= ~BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionTA0CaptureIn1()					   {PMAPPWD = 0x02D52;P3MAP2 = PM_TA0CCR1A;PMAPPWD = 0;P3DIR &= ~BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionTA0CaptureIn2()					   {PMAPPWD = 0x02D52;P3MAP2 = PM_TA0CCR2A;PMAPPWD = 0;P3DIR &= ~BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionTA0CaptureIn3()					   {PMAPPWD = 0x02D52;P3MAP2 = PM_TA0CCR3A;PMAPPWD = 0;P3DIR &= ~BIT2;P3SEL |= BIT2;}
#define Pin19_FunctionTA0CaptureIn4()					   {PMAPPWD = 0x02D52;P3MAP2 = PM_TA0CCR4A;PMAPPWD = 0;P3DIR &= ~BIT2;P3SEL |= BIT2;}

#define Pin19_FunctionGDOSignal()                          {PMAPPWD = 0x02D52;P3MAP2 = PM_RFGDO2;PMAPPWD = 0;P3SEL |= BIT2;} //V1.5 and eROS V4.1

//eRIC_Pin20 Definitions
//PullUp/Down Resistor
#define Pin20_PullUpEnable() 							   {P3REN |= BIT1;P3OUT|=BIT1;}
#define Pin20_PullDownEnable()							   {P3REN |= BIT1;P3OUT&=~BIT1;}
#define Pin20_PullUpDisable() 							    P3REN &= ~BIT1

//O/P
#define Pin20_SetAsOutput()   							    P3DIR |= BIT1
#define Pin20_SetHigh()         						    P3OUT |= BIT1
#define Pin20_SetLow()          						    P3OUT &=~ BIT1
#define Pin20_Toggle()         							    P3OUT ^= BIT1;    //V1.4

//I/P
#define Pin20_SetAsInput()    							    P3DIR &=~ BIT1
#define Pin20_Read()         						       (P3IN & BIT1)

//Secondary function mapping
#define Pin20_FunctionIO()          				       {P3SEL &= ~BIT1;}  /* */

#define Pin20_FunctionNone()        				       {PMAPPWD = 0x02D52;P3MAP1 = PM_NONE;PMAPPWD = 0;P3SEL |= BIT1;P3DIR |= BIT1;P3SEL &= ~BIT1;}  /* */

#define Pin20_FunctionAclk()         					   {PMAPPWD = 0x02D52;P3MAP1 = PM_ACLK;PMAPPWD = 0;P3SEL |= BIT1;P3DIR |= BIT1;}
#define Pin20_FunctionMclk()         					   {PMAPPWD = 0x02D52;P3MAP1 = PM_MCLK;PMAPPWD = 0;P3SEL |= BIT1;P3DIR |= BIT1;}
#define Pin20_FunctionSmclk()        					   {PMAPPWD = 0x02D52;P3MAP1 = PM_SMCLK;PMAPPWD = 0;P3SEL |= BIT1;P3DIR |= BIT1;}

#define Pin20_FunctionTA0clkIN()     					   {PMAPPWD = 0x02D52;P3MAP1 = PM_TA0CLK;PMAPPWD = 0;P3SEL |= BIT1;P3DIR &= ~BIT1;}

#define Pin20_FunctionUartATxOUT()    					   {PMAPPWD = 0x02D52;P3MAP1 = PM_UCA0TXD;PMAPPWD = 0;P3SEL |= BIT1;P3DIR |= BIT1;}
#define Pin20_FunctionUartARxD()    				       {PMAPPWD = 0x02D52;P3MAP1 = PM_UCA0RXD;PMAPPWD = 0;P3SEL |= BIT1;}

#define Pin20_FunctionUartABusy()    					   {eRIC_Port2Busy = 0x00; eRIC_Port3Busy = 0x02;Pin20_SetAsOutput();Pin20_SetLow();} /*Set Port Direction*//*Clear the pin*/

#define Pin20_FunctionSpiA_MI()     				       {PMAPPWD = 0x02D52;P3MAP1 = PM_UCA0SOMI;PMAPPWD = 0;P3DIR &= ~BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionSpiA_MO()     				       {PMAPPWD = 0x02D52;P3MAP1 = PM_UCA0SIMO;PMAPPWD = 0;P3DIR |= BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionSpiA_SO()      					   {PMAPPWD = 0x02D52;P3MAP1 = PM_UCA0SOMI;PMAPPWD = 0;P3DIR |= BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionSpiA_SI()      					   {PMAPPWD = 0x02D52;P3MAP1 = PM_UCA0SIMO;PMAPPWD = 0;P3DIR &= ~BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionSpiA_SCLKOUT() 					   {PMAPPWD = 0x02D52;P3MAP1 = PM_UCA0CLK;PMAPPWD = 0;P3DIR |=BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionSpiA_STE()     					   {PMAPPWD = 0x02D52;P3MAP1 = PM_UCA0STE;PMAPPWD = 0;P3SEL |= BIT1;}

#define Pin20_FunctionSpiB_MI()      					   {PMAPPWD = 0x02D52;P3MAP1 = PM_UCB0SOMI;PMAPPWD = 0;P3DIR &= ~BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionSpiB_MO()      					   {PMAPPWD = 0x02D52;P3MAP1 = PM_UCB0SIMO;PMAPPWD = 0;P3DIR |= BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionSpiB_SO()      					   {PMAPPWD = 0x02D52;P3MAP1 = PM_UCB0SOMI;PMAPPWD = 0;P3DIR |= BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionSpiB_SI()     	 				   {PMAPPWD = 0x02D52;P3MAP1 = PM_UCB0SIMO;PMAPPWD = 0;P3DIR &= ~BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionSpiB_SCLKOUT() 					   {PMAPPWD = 0x02D52;P3MAP1 = PM_UCB0CLK;PMAPPWD = 0;P3DIR |=BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionSpiB_STE()     					   {PMAPPWD = 0x02D52;P3MAP1 = PM_UCB0STE;PMAPPWD = 0;P3SEL |= BIT1;}

#define Pin20_FunctionI2CB_SCl()     					   {PMAPPWD = 0x02D52;P3MAP1 = PM_UCB0SCL;PMAPPWD = 0;P3SEL |= BIT1;}
#define Pin20_FunctionI2CB_SDA()     					   {PMAPPWD = 0x02D52;P3MAP1 = PM_UCB0SDA;PMAPPWD = 0;P3SEL |= BIT1;}

#define Pin20_SetAsAsyncRxData()       					   {PMAPPWD = 0x02D52;P3MAP1 = PM_RFGDO1;PMAPPWD = 0;P3SEL |= BIT1;}
#define Pin20_SetAsAsyncTxData()       					   {PMAPPWD = 0x02D52;P3MAP1 = PM_RFGDO0;PMAPPWD = 0;P3SEL |= BIT1;P3REN |= BIT1;}

#define Pin20_FunctionTA0CompareOut0()					   {PMAPPWD = 0x02D52;P3MAP1 = PM_TA0CCR0A;PMAPPWD = 0;P3DIR |= BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionTA0CompareOut1()					   {PMAPPWD = 0x02D52;P3MAP1 = PM_TA0CCR1A;PMAPPWD = 0;P3DIR |= BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionPWM1()      					       {Pin20_FunctionTA0CompareOut1();}
#define Pin20_FunctionTA0CompareOut2()					   {PMAPPWD = 0x02D52;P3MAP1 = PM_TA0CCR2A;PMAPPWD = 0;P3DIR |= BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionPWM2()        				       {Pin20_FunctionTA0CompareOut2();}
#define Pin20_FunctionTA0CompareOut3()					   {PMAPPWD = 0x02D52;P3MAP1 = PM_TA0CCR3A;PMAPPWD = 0;P3DIR |= BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionPWM3()         					   {Pin20_FunctionTA0CompareOut3();}
#define Pin20_FunctionTA0CompareOut4()					   {PMAPPWD = 0x02D52;P3MAP1 = PM_TA0CCR4A;PMAPPWD = 0;P3DIR |= BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionPWM4()         					   {Pin20_FunctionTA0CompareOut4();}

#define Pin20_FunctionTA0CaptureIn0()					   {PMAPPWD = 0x02D52;P3MAP1 = PM_TA0CCR0A;PMAPPWD = 0;P3DIR &= ~BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionTA0CaptureIn1()					   {PMAPPWD = 0x02D52;P3MAP1 = PM_TA0CCR1A;PMAPPWD = 0;P3DIR &= ~BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionTA0CaptureIn2()					   {PMAPPWD = 0x02D52;P3MAP1 = PM_TA0CCR2A;PMAPPWD = 0;P3DIR &= ~BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionTA0CaptureIn3()					   {PMAPPWD = 0x02D52;P3MAP1 = PM_TA0CCR3A;PMAPPWD = 0;P3DIR &= ~BIT1;P3SEL |= BIT1;}
#define Pin20_FunctionTA0CaptureIn4()					   {PMAPPWD = 0x02D52;P3MAP1 = PM_TA0CCR4A;PMAPPWD = 0;P3DIR &= ~BIT1;P3SEL |= BIT1;}

#define Pin20_FunctionGDOSignal()                          {PMAPPWD = 0x02D52;P3MAP1 = PM_RFGDO2;PMAPPWD = 0;P3SEL |= BIT1;} //V1.5 and eROS V4.1

//eRIC_Pin21 Definitions
//PullUp/Down Resistor
#define Pin21_PullUpEnable() 							   {P3REN |= BIT0;P3OUT|=BIT0;}
#define Pin21_PullDownEnable()							   {P3REN |= BIT0;P3OUT&=~BIT0;}
#define Pin21_PullUpDisable() 							    P3REN &= ~BIT0

//O/P
#define Pin21_SetAsOutput()   							    P3DIR |= BIT0
#define Pin21_SetHigh()       						        P3OUT |= BIT0
#define Pin21_SetLow()          						    P3OUT &=~ BIT0
#define Pin21_Toggle()         							    P3OUT ^= BIT0;    //V1.4

//I/P
#define Pin21_SetAsInput()    							    P3DIR &=~ BIT0
#define Pin21_Read()          							   (P3IN & BIT0)

//Secondary function mapping
#define Pin21_FunctionIO()           					   {P3SEL &= ~BIT0;}  /* */

#define Pin21_FunctionNone()        				       {PMAPPWD = 0x02D52;P3MAP0 = PM_NONE;PMAPPWD = 0;P3SEL |= BIT0;P3DIR |= BIT0;P3SEL &= ~BIT0;}  /* */

#define Pin21_FunctionAclk()         					   {PMAPPWD = 0x02D52;P3MAP0 = PM_ACLK;PMAPPWD = 0;P3SEL |= BIT0;P3DIR |= BIT0;}
#define Pin21_FunctionMclk()         					   {PMAPPWD = 0x02D52;P3MAP0 = PM_MCLK;PMAPPWD = 0;P3SEL |= BIT0;P3DIR |= BIT0;}
#define Pin21_FunctionSmclk()        					   {PMAPPWD = 0x02D52;P3MAP0 = PM_SMCLK;PMAPPWD = 0;P3SEL |= BIT0;P3DIR |= BIT0;}

#define Pin21_FunctionTA0clkIN()     				       {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CLK;PMAPPWD = 0;P3SEL |= BIT0;P3DIR &= ~BIT0;}

#define Pin21_FunctionUartATxOUT()   					   {PMAPPWD = 0x02D52;P3MAP0 = PM_UCA0TXD;PMAPPWD = 0;P3SEL |= BIT0;P3DIR |= BIT0;}
#define Pin21_FunctionUartARxD()    				       {PMAPPWD = 0x02D52;P3MAP0 = PM_UCA0RXD;PMAPPWD = 0;P3SEL |= BIT0;}

#define Pin21_FunctionUartABusy()    					   {eRIC_Port2Busy = 0x00; eRIC_Port3Busy = 0x01;Pin21_SetAsOutput();Pin21_SetLow();} /*Set Port Direction*//*Clear the pin*/

#define Pin21_FunctionSpiA_MI()      					   {PMAPPWD = 0x02D52;P3MAP0 = PM_UCA0SOMI;PMAPPWD = 0;P3DIR &= ~BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionSpiA_MO()     				       {PMAPPWD = 0x02D52;P3MAP0 = PM_UCA0SIMO;PMAPPWD = 0;P3DIR |= BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionSpiA_SO()      					   {PMAPPWD = 0x02D52;P3MAP0 = PM_UCA0SOMI;PMAPPWD = 0;P3DIR |= BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionSpiA_SI()      					   {PMAPPWD = 0x02D52;P3MAP0 = PM_UCA0SIMO;PMAPPWD = 0;P3DIR &= ~BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionSpiA_SCLKOUT() 					   {PMAPPWD = 0x02D52;P3MAP0 = PM_UCA0CLK;PMAPPWD = 0;P3DIR |=BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionSpiA_STE()     					   {PMAPPWD = 0x02D52;P3MAP0 = PM_UCA0STE;PMAPPWD = 0;P3SEL |= BIT0;}

#define Pin21_FunctionSpiB_MI()      					   {PMAPPWD = 0x02D52;P3MAP0 = PM_UCB0SOMI;PMAPPWD = 0;P3DIR &= ~BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionSpiB_MO()      					   {PMAPPWD = 0x02D52;P3MAP0 = PM_UCB0SIMO;PMAPPWD = 0;P3DIR |= BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionSpiB_SO()      					   {PMAPPWD = 0x02D52;P3MAP0 = PM_UCB0SOMI;PMAPPWD = 0;P3DIR |= BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionSpiB_SI()      					   {PMAPPWD = 0x02D52;P3MAP0 = PM_UCB0SIMO;PMAPPWD = 0;P3DIR &= ~BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionSpiB_SCLKOUT() 					   {PMAPPWD = 0x02D52;P3MAP0 = PM_UCB0CLK;PMAPPWD = 0;P3DIR |=BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionSpiB_STE()     					   {PMAPPWD = 0x02D52;P3MAP0 = PM_UCB0STE;PMAPPWD = 0;P3SEL |= BIT0;}

#define Pin21_FunctionI2CB_SCl()     					   {PMAPPWD = 0x02D52;P3MAP0 = PM_UCB0SCL;PMAPPWD = 0;P3SEL |= BIT0;}
#define Pin21_FunctionI2CB_SDA()     					   {PMAPPWD = 0x02D52;P3MAP0 = PM_UCB0SDA;PMAPPWD = 0;P3SEL |= BIT0;}

#define Pin21_SetAsAsyncRxData()       					   {PMAPPWD = 0x02D52;P3MAP0 = PM_RFGDO1;PMAPPWD = 0;P3SEL |= BIT0;}
#define Pin21_SetAsAsyncTxData()       					   {PMAPPWD = 0x02D52;P3MAP0 = PM_RFGDO0;PMAPPWD = 0;P3SEL |= BIT0;P3REN |= BIT0;}

#define Pin21_FunctionTA0CompareOut0()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR0A;PMAPPWD = 0;P3DIR |= BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionTA0CompareOut1()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR1A;PMAPPWD = 0;P3DIR |= BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionPWM1()    				           {Pin21_FunctionTA0CompareOut1();}
#define Pin21_FunctionTA0CompareOut2()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR2A;PMAPPWD = 0;P3DIR |= BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionPWM2()         					   {Pin21_FunctionTA0CompareOut2();}
#define Pin21_FunctionTA0CompareOut3()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR3A;PMAPPWD = 0;P3DIR |= BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionPWM3()         					   {Pin21_FunctionTA0CompareOut3();}
#define Pin21_FunctionTA0CompareOut4()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR4A;PMAPPWD = 0;P3DIR |= BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionPWM4()         					   {Pin21_FunctionTA0CompareOut4();}

#define Pin21_FunctionTA0CaptureIn0()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR0A;PMAPPWD = 0;P3DIR &= ~BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionTA0CaptureIn1()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR1A;PMAPPWD = 0;P3DIR &= ~BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionTA0CaptureIn2()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR2A;PMAPPWD = 0;P3DIR &= ~BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionTA0CaptureIn3()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR3A;PMAPPWD = 0;P3DIR &= ~BIT0;P3SEL |= BIT0;}
#define Pin21_FunctionTA0CaptureIn4()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR4A;PMAPPWD = 0;P3DIR &= ~BIT0;P3SEL |= BIT0;}

#define Pin21_FunctionGDOSignal()                          {PMAPPWD = 0x02D52;P3MAP0 = PM_RFGDO2;PMAPPWD = 0;P3SEL |= BIT0;} //V1.5 and eROS V4.1

//eRIC_Pin22 Definitions
//PullUp/Down Resistor
#define Pin22_PullUpEnable() 							   {P2REN |= BIT5;P2OUT|=BIT5;}
#define Pin22_PullDownEnable()							   {P2REN |= BIT5;P2OUT&=~BIT5;}
#define Pin22_PullUpDisable() 							    P2REN &= ~BIT5

//O/P
#define Pin22_SetAsOutput()   							    P2DIR |= BIT5
#define Pin22_SetHigh()        							    P2OUT |= BIT5
#define Pin22_SetLow()          						    P2OUT &=~ BIT5
#define Pin22_Toggle()        							    P2OUT ^= BIT5;    //V1.4

//I/P
#define Pin22_SetAsInput()    							    P2DIR &=~ BIT5
#define Pin22_Read()         							   (P2IN & BIT5)

//Pin Drive Strength (sets maximum drive capabilities of each pin individually - default = low 6mA)
#define Pin22_HighDriveStrength_15mA()					   {P2DS |= BIT5;}    /*Sets Logic High and Low of pins for  High Drive strength */
#define PIn22_LowDriveStrength_6mA()					   {P2DS &= ~BIT5;}    /*Sets Logic High and Low of pins for  Low Drive strength */

//Pin Interrupt Edge Direction
#define Pin22_InterruptLow2High()						   {P2IES &= ~BIT5;}       /*Set Interrupt Flag on PIN Low to High*/
#define Pin22_InterruptHigh2Low()						   {P2IES |= BIT5;}        /*Set Interrupt Flag on PIN High to Low*/
#define Pin22_InterruptDirection()						   (P2IES & BIT5)      /*Read Interrupt Edge selection*/

//Pin Change Interrupt Enable/Disable
#define Pin22_InterruptEnable()							   {P2IE |= BIT5;}        /*Enable Pin Interrupt, only use when using Interrupt Service Routine*/
#define Pin22_InterruptDisable()						   {P2IE &= ~BIT5;}       /*Disable Pin Interrupt*/
#define Pin22_InterruptEnabled()						   (P2IE & BIT5)        /*Read Interrupt Enabled status*/

//Pin Interrupt Flag
#define Pin22_SetInterruptFlag()                           {P2IFG |= BIT5;}
#define Pin22_ClearInterruptFlag()						   {P2IFG &= ~BIT5;}     /*Reset Interrupt flag*/
#define Pin22_HasIntterupted()  						   (P2IFG & BIT5)      /*Test if Pin has changed*/

//Secondary function mapping

#define Pin22_FunctionIO()      					       {P2SEL &= ~BIT5;}  /* */

#define Pin22_FunctionNone()    					       {PMAPPWD = 0x02D52;P2MAP5 = PM_NONE;PMAPPWD = 0;P2SEL |= BIT5;P2DIR |= BIT5;P2SEL &= ~BIT5;}  /* */

#define Pin22_FunctionAclk()    					       {PMAPPWD = 0x02D52;P2MAP5 = PM_ACLK;PMAPPWD = 0;P2SEL |= BIT5;P2DIR |= BIT5;}
#define Pin22_FunctionMclk()     						   {PMAPPWD = 0x02D52;P2MAP5 = PM_MCLK;PMAPPWD = 0;P2SEL |= BIT5;P2DIR |= BIT5;}
#define Pin22_FunctionSmclk()    						   {PMAPPWD = 0x02D52;P2MAP5 = PM_SMCLK;PMAPPWD = 0;P2SEL |= BIT5;P2DIR |= BIT5;}

#define Pin22_FunctionTA0clkIN() 						   {PMAPPWD = 0x02D52;P2MAP5 = PM_TA0CLK;PMAPPWD = 0;P2SEL |= BIT5;P2DIR &= ~BIT5;}

#define Pin22_FunctionA2D()      						   {PMAPPWD = 0x02D52;P2MAP5 = PM_ANALOG;PMAPPWD = 0;P2SEL |= BIT5;}

#define Pin22_FunctionUartATxOUT()						   {PMAPPWD = 0x02D52;P2MAP5 = PM_UCA0TXD;PMAPPWD = 0;P2SEL |= BIT5;P2DIR |= BIT5;}
#define Pin22_FunctionUartARxD()  						   {PMAPPWD = 0x02D52;P2MAP5 = PM_UCA0RXD;PMAPPWD = 0;P2SEL |= BIT5;}

#define Pin22_FunctionSpiA_MI()   						   {PMAPPWD = 0x02D52;P2MAP5 = PM_UCA0SOMI;PMAPPWD = 0;P2DIR &= ~BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionSpiA_MO()   						   {PMAPPWD = 0x02D52;P2MAP5 = PM_UCA0SIMO;PMAPPWD = 0;P2DIR |= BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionSpiA_SO()   						   {PMAPPWD = 0x02D52;P2MAP5 = PM_UCA0SOMI;PMAPPWD = 0;P2DIR |= BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionSpiA_SI()   						   {PMAPPWD = 0x02D52;P2MAP5 = PM_UCA0SIMO;PMAPPWD = 0;P2DIR &= ~BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionSpiA_SCLKOUT()				 	   {PMAPPWD = 0x02D52;P2MAP5 = PM_UCA0CLK;PMAPPWD = 0;P2DIR |=BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionSpiA_STE()  						   {PMAPPWD = 0x02D52;P2MAP5 = PM_UCA0STE;PMAPPWD = 0;P2SEL |= BIT5;}

#define Pin22_FunctionSpiB_MI()   						   {PMAPPWD = 0x02D52;P2MAP5 = PM_UCB0SOMI;PMAPPWD = 0;P2DIR &= ~BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionSpiB_MO()   						   {PMAPPWD = 0x02D52;P2MAP5 = PM_UCB0SIMO;PMAPPWD = 0;P2DIR |= BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionSpiB_SO()   						   {PMAPPWD = 0x02D52;P2MAP5 = PM_UCB0SOMI;PMAPPWD = 0;P2DIR |= BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionSpiB_SI()   						   {PMAPPWD = 0x02D52;P2MAP5 = PM_UCB0SIMO;PMAPPWD = 0;P2DIR &= ~BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionSpiB_SCLKOUT() 					   {PMAPPWD = 0x02D52;P2MAP5 = PM_UCB0CLK;PMAPPWD = 0;P2DIR |=BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionSpiB_STE()  						   {PMAPPWD = 0x02D52;P2MAP5 = PM_UCB0STE;PMAPPWD = 0;P2SEL |= BIT5;}

#define Pin22_FunctionI2CB_SCl()  						   {PMAPPWD = 0x02D52;P2MAP5 = PM_UCB0SCL;PMAPPWD = 0;P2SEL |= BIT5;}
#define Pin22_FunctionI2CB_SDA()  						   {PMAPPWD = 0x02D52;P2MAP5 = PM_UCB0SDA;PMAPPWD = 0;P2SEL |= BIT5;}

#define Pin22_SetAsAsyncRxData()      				       {PMAPPWD = 0x02D52;P2MAP5 = PM_RFGDO1;PMAPPWD = 0;P2SEL |= BIT5;}
#define Pin22_SetAsAsyncTxData()       					   {PMAPPWD = 0x02D52;P2MAP5 = PM_RFGDO0;PMAPPWD = 0;P2SEL |= BIT5;P2REN |= BIT5;}

#define Pin22_FunctionTA0CompareOut0()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR0A;PMAPPWD = 0;P2DIR |= BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionTA0CompareOut1()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR1A;PMAPPWD = 0;P2DIR |= BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionPWM1()         					   {Pin22_FunctionTA0CompareOut1();}
#define Pin22_FunctionTA0CompareOut2()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR2A;PMAPPWD = 0;P2DIR |= BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionPWM2()        				       {Pin22_FunctionTA0CompareOut2();}
#define Pin22_FunctionTA0CompareOut3()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR3A;PMAPPWD = 0;P2DIR |= BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionPWM3()        				       {Pin22_FunctionTA0CompareOut3();}
#define Pin22_FunctionTA0CompareOut4()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR4A;PMAPPWD = 0;P2DIR |= BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionPWM4()         					   {Pin22_FunctionTA0CompareOut4();}

#define Pin22_FunctionTA0CaptureIn0()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR0A;PMAPPWD = 0;P2DIR &= ~BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionTA0CaptureIn1()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR1A;PMAPPWD = 0;P2DIR &= ~BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionTA0CaptureIn2()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR2A;PMAPPWD = 0;P2DIR &= ~BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionTA0CaptureIn3()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR3A;PMAPPWD = 0;P2DIR &= ~BIT5;P2SEL |= BIT5;}
#define Pin22_FunctionTA0CaptureIn4()					   {PMAPPWD = 0x02D52;P3MAP0 = PM_TA0CCR4A;PMAPPWD = 0;P2DIR &= ~BIT5;P2SEL |= BIT5;}

#define Pin22_FunctionGDOSignal()                          {PMAPPWD = 0x02D52;P3MAP0 = PM_RFGDO2;PMAPPWD = 0;P3SEL |= BIT0;} //V1.5 and eROS V4.1

/************************************************************
 * STANDARD BITS
 ************************************************************/

unsigned char Rx_data();
signed char GetPacketRSSI();
//unsigned long ReadAdc(unsigned char eRIC_AdcPin,unsigned char eRIC_AdcRefVoltage);  //removed from V1.4
unsigned long ReadAdc();


void SetAdcPin(unsigned char eRICPinNumber);
void SetAdcRefVolt(unsigned char eRIC_ReferenceVoltage,unsigned char RefOut_OnorOff_Pin22);

float GetTemperature();
unsigned char eRIC_Eeprom_Read(volatile unsigned char Address);

void eRIC_Eeprom_Write(volatile unsigned char Address,volatile unsigned char Data);
unsigned long GetSerialNumber();

void eRIC_Stringcopy(volatile unsigned char *destination, const char *source,volatile unsigned char count);
unsigned char eRIC_Stringcompare(char *a, char *b, unsigned char count);
unsigned char eRIC_Stringlength(char *string);
unsigned char eRIC_Sprintf(char *buff, char *string, float val);
void eRIC_Print(char* txt);
char eRIC_Ascii2Hex(char val);
char eRIC_Int2Ascii(int val);


void SetUncalibratedFrequency();

signed char GetRSSI();

void eRIC_SetPMMVCoreLevel(volatile unsigned char Level); //V1.5

void eRIC_RadioAsyncMode();
void eRIC_RadioPacketMode();
void eROS_Initialise(volatile unsigned long RadioFrequency);
void eRIC_SetCpuFrequency(volatile unsigned long ClockFrequency);
void eRIC_FlashProgram_Mode(volatile unsigned char Mode /*0 = UART FLash*/);
void eRIC_Delay(volatile unsigned int MilliSeconds);
void eRIC_Tx_CarrierOn();
void eRIC_Tx_CarrierOff();
void eRIC_GroupIDEnable(volatile unsigned int IDNumber);
void eRIC_GroupIDDisable();
unsigned int IsGroupID_Enabled();
unsigned int IsRadio_Rx_Busy();
unsigned int Is60ByteLimitEnabled();
unsigned int IsAsyncModeEnabled();
void eRIC_FunctionClearUartABusy();

unsigned char RadioRegRead(unsigned char Address); //V1.5


//void eRIC_AES_SetKey(volatile unsigned char mode,volatile unsigned char *Key /* passed buffer MUST be 16 bytes long!!!*/);
//void eRIC_AES_SetKey();

//void eRIC_AES_ChangeKey();

//void eRIC_AES_Run();

#define eRIC_AES_ChangeKey();                               asm(" CALLA #0X8070"); //V4.1
#define eRIC_AES_SetKey();                                  asm(" CALLA #0X8074"); //V4.1
#define eRIC_AES_Run();                                     asm(" CALLA #0X8078"); //V4.1


#define eRIC_RadioUpdate()   							    asm(" CALLA #0X8028")

#define eRIC_RfSenddata()       						    asm(" CALLA #0X802C")    //  RF1AIFG |= BIT5
#define eRIC_ReadRfByte()      							    Rx_data()

#define eRIC_Rx_Enable()        					        asm(" CALLA #0x8038")
#define eRIC_Rx_Disable()      							    asm(" CALLA #0x803C")





/* General Definition (non Radio)
 * */


//#define eRIC_ReadAdc(Adc_Pinnumber,ReferenceVoltage)    ReadAdc(Adc_Pinnumber,ReferenceVoltage)         //{eRIC_AdcPin = Adc_Pinnumber;eRIC_AdcRefVoltage = ReferenceVoltage;asm(" CALLA #0x9276");return eRIC_AdcResult;}
//Above is modified or removed from V1.4

#define eRIC_SetAdcPin(eRICPinNumber)                                          {SetAdcPin(eRICPinNumber);}
#define eRIC_SetAdcRefVoltage(eRIC_ReferenceVoltage,RefOut_OnorOff_Pin22)     {SetAdcRefVolt(eRIC_ReferenceVoltage,RefOut_OnorOff_Pin22);}
#define eRIC_ReadAdc()                                                          ReadAdc()

#define Ref_1_5v 0
#define Ref_2_0v 1
#define Ref_2_5v 2

#define eRICADCRef_1_5v 0
#define eRICADCRef_2_0v 1
#define eRICADCRef_2_5v 2

#define eRIC_GetTemperature()      						    GetTemperature()
#define eRIC_GetLiveRSSI()         			 			    GetRSSI()


#define eRIC_GetLastPacketRSSI()    					    GetPacketRSSI()




//#define eRIC_Breakpoint(BreakPointNumber)       		   {CommonPassedVariable = BreakPointNumber;asm(" CALLA #0X8048");}
//#define eRIC_SetWatch(WatchNumber,Variable,Type)     	   {CommonPassedVariable = WatchNumber;CommonPassedVariable2 = (unsigned long)&Variable;CommonPassedVariable3 = (unsigned long)Type;asm(" CALLA #0x804C");}

#define													    _unsigned_char 0x00       /* Names day and declares a       */
#define 												    _unsigned_int  0x01   /* variable named workday with    */
#define													    _unsigned_long  0x02       /* that type                      */
#define													    _unsigned_double 0x03
#define													    _signed_char  0x80      /* wednesday is associated with 3 */
#define													    _signed_int 0x81
#define													    _signed_long 0x82
#define													    _signed_double 0x83

//#define eRIC_SetModulationCarrierOn()       			   {CommonPassedVariable2 = 1;asm(" CALLA #0x8020");}
//#define eRIC_SetCarrierOff()                			   {CommonPassedVariable2 = 0;asm(" CALLA #0x8020");}//asm(" CALLA #0x9030")

//#define eRIC_SetHighSideCarrierOn()         			   {CommonPassedVariable2 = 3;asm(" CALLA #0x8020");}//{asm(" CALLA #0X9072");}
//#define eRIC_SetLowSideCarrierOn()           			   {CommonPassedVariable2 = 2;asm(" CALLA #0x8020");}//{asm(" CALLA #0X9078");}


//#define eRIC_SetModulationCarrierOn()      		       {eRIC_RadioPacketMode();eRIC_Tx_CarrierOn();}

#define eRIC_SetModulationCarrierOn()                      {eRIC_RadioUpdate();eRIC_RadioPacketMode();eRIC_Tx_CarrierOn();} //Modified from above in V1.4 //eRIC_RadioUpdate(); is used in front so that if changed from uncalibrated to these modes,frequency is chanhed to calibrated before using radio update
#define eRIC_SetCarrierOff()                 			   {eRIC_RadioUpdate();eRIC_RadioPacketMode();}                      //eRIC_RadioUpdate(); is used in front so that if changed from uncalibrated to these modes,frequency is chanhed to calibrated before using radio update
#define eRIC_SetHighSideCarrierOn()         			   {eRIC_RadioUpdate();eRIC_RadioAsyncMode();P1OUT |=BIT0;eRIC_Tx_CarrierOn();}   //eRIC_RadioUpdate(); is used in front so that if changed from uncalibrated to these modes,frequency is chanhed to calibrated before using radio update
#define eRIC_SetLowSideCarrierOn()    					   {eRIC_RadioUpdate();eRIC_RadioAsyncMode();P1OUT &=~BIT0;eRIC_Tx_CarrierOn();}  //eRIC_RadioUpdate(); is used in front so that if changed from uncalibrated to these modes,frequency is chanhed to calibrated before using radio update

#define eRIC_SetUncalibratedModulationCarrierOn()		   {SetUncalibratedFrequency();eRIC_RadioPacketMode();eRIC_Tx_CarrierOn();}



#define eRIC_GetSerialNumber() 							    GetSerialNumber()

#define eRIC_PowerOnReset()        						   {PMMCTL0_H = 0xA5;PMMCTL0_L|=PMMSWPOR;PMMCTL0_H = 0x00;}

#define eRIC_BrownOutReset()                               {PMMCTL0_H = 0xA5;PMMCTL0_L|=PMMSWBOR;PMMCTL0_H = 0x00;}

#define eRIC_WDT_Stop()           						   {unsigned int temp = WDTCTL;temp&=0xFF;WDTCTL = WDTPW|WDTHOLD|temp|WDTTMSEL;}
#define eRIC_WDT_Start()          						   {unsigned int temp = WDTCTL;temp&=0x7F;WDTCTL = WDTPW+temp;}

#define eRIC_WDT_Reset()          						   {unsigned int temp = WDTCTL;temp&=0xFF;WDTCTL = WDTPW|temp|WDTCNTCL;}

#define eRICWDT_Cs_CPU             						    WDTSSEL__SMCLK
#define eRICWDT_Cs_32k             						    WDTSSEL__ACLK
#define eRICWDT_Cs_10k             						    WDTSSEL__VLO
#define eRICWDT_Interval_64        						    WDTIS__64
#define eRICWDT_Interval_512      	 					    WDTIS__512
#define eRICWDT_Interval_8192      						    WDTIS__8192
#define eRICWDT_Interval_32768     						    WDTIS__32K
#define eRICWDT_Interval_524288    						    WDTIS__512K
#define eRICWDT_Interval_8388608   						    WDTIS__8192K
#define eRICWDT_Interval_134217728 						    WDTIS__128M
#define eRICWDT_Interval_2147483648						    WDTIS__2G

#define eRIC_WDT_InterruptEnable() 						   {SFRIE1 |= WDTIE;}
#define eRIC_WDT_InterruptDisable()						   {SFRIE1 &= ~(WDTIE);}
#define eRIC_WDT_ClearInterruptFlag()			  		   {SFRIFG1 &= ~(WDTIFG);}
#define eRIC_WDT_HasInterrupted()  						   (SFRIFG1&WDTIFG)

#define eRIC_WDT_Setup(Modebits)   						   {WDTCTL = WDTPW+Modebits+WDTTMSEL+WDTCNTCL;}

#define eRIC_LPM_Level0()           					   {eRIC_LPMLevel = 1;LPM0;}
#define eRIC_LPM_ExitLevel0()       					   {LPM0_EXIT;eRIC_LPMLevel = 0;}

#define eRIC_LPM_Level1()                                  {eRIC_LPMLevel = 2;LPM2;} //V1.5.4
#define eRIC_LPM_ExitLevel1()                              {LPM2_EXIT;eRIC_LPMLevel = 0;}   //V1.4 //This is replaced line from above, as there is a typo mistake

#define eRIC_LPM_Level2()                                  {eRIC_LPMLevel = 3;UCSCTL8 &= ~(SMCLKREQEN+ACLKREQEN+MODOSCREQEN);LPM4;}
#define eRIC_LPM_ExitLevel2()                              {UCSCTL8 |= (SMCLKREQEN+ACLKREQEN+MODOSCREQEN);LPM4_EXIT;eRIC_LPMLevel = 0;}

#define eRIC_GlobalInterruptEnable() 					   {__bis_SR_register(GIE);}  //Enables all interrupts which were enabled before
#define eRIC_GlobalInterruptDisable()					   {__bic_SR_register(GIE);} //All enabled interrupts are stopped. Even if we enable any particular interrupt, it doesnt work unless we enable global interrupt enable
#define eRIC_GlobalInterruptIsEnabled()                    (_get_SR_register()&0x8)

#define eRIC_RadioSleep()             				       {CommonPassedVariable2 = RF_SIDLE;asm(" CALLA #0X8068");CommonPassedVariable2 = RF_SXOFF;asm(" CALLA #0X8068");} //V4.1


/*Timer0 related definitions*/

#define eRIC_TimerA0_Setup(CompleteSetup)                  {TA0CTL = CompleteSetup;} //V1.5

#define eRIC_TimerA0_Cs(Clocksource)					   {TA0CTL &= ~TASSEL__INCLK;TA0CTL |= Clocksource;}
//#define eRICTimer_Cs_TA0CLK          					    TASSEL__TACLK
#define eRICTimer_Cs_32k           						    TASSEL__ACLK
#define eRICTimer_Cs_CPU           						    TASSEL__SMCLK
//#define eRICTimer_Cs_INCLK           					    TASSEL__INCLK

#define eRIC_TimerA0_ClockDivider(Clockdivider) 		   {TA0CTL &= ~ID__8;TA0CTL |= Clockdivider;}
#define eRICTimer_Div_1                         		    ID__1
#define eRICTimer_Div_2                         		    ID__2
#define eRICTimer_Div_4                         		    ID__4
#define eRICTimer_Div_8                         		    ID__8

#define eRIC_TimerA0_Stop()          					   {TA0CTL &= ~MC__UPDOWN;TA0CTL |= MC__STOP;}
#define eRIC_TimerA0_UpMode()       					   {TA0CTL &= ~MC__UPDOWN;TA0CTL |= MC__UP;}
#define eRIC_TimerA0_ContinousMode()					   {TA0CTL &= ~MC__UPDOWN;TA0CTL |= MC__CONTINUOUS;}
#define eRIC_TimerA0_UpdownMode()   					   {TA0CTL &= ~MC__UPDOWN;TA0CTL |= MC__UPDOWN;}

#define eRICTimer_Stop                                      MC__STOP             //V1.5
#define eRICTimer_UpMode                                    MC__UP               //V1.5
#define eRICTimer_ContinousMode                             MC__CONTINUOUS       //V1.5
#define eRICTimer_UpdownMode                                MC__UPDOWN           //V1.5


#define eRIC_TimerA0_Reset()        					   {TA0CTL |= TACLR;}
#define eRICTimer_Reset                                     TACLR                //V1.5

#define eRIC_TimerA0_InterruptEnable()					   {TA0CTL |= TAIE;}
//#define eRIC_TimerA0_InterruptDisable()				   {TAOCTL &= ~TAIE;} //V1.4
//#define eRIC_TimerA0_IsInterruptEnabled()				   (TAOCTL & TAIE)    //V1.4
#define eRIC_TimerA0_InterruptDisable()                    {TA0CTL &= ~TAIE;} //V1.5
#define eRIC_TimerA0_IsInterruptEnabled()                  (TA0CTL & TAIE)    //V1.5 typo in 1.4 number 0 as O

#define eRICTimer_InterruptEnable                           TAIE              //V1.5
#define eRICTimer_InterruptDisable                          0               //V1.5

#define eRIC_TimerA0_InterruptFlag_set()				   {TA0CTL |= TAIFG;}
//#define eRIC_TiemrA0_InterruptFlag_clear()				   {TA0CTL &= ~TAIFG;} //V1.4
#define eRIC_TimerA0_InterruptFlag_clear()                 {TA0CTL &= ~TAIFG;} //V1.5 typo
#define eRIC_TimerA0_HasInterrupted()					   (TA0CTL & TAIFG)

#define eRIC_TimerA0_Count_Read()						   (TA0R)
#define eRIC_TimerA0_Count_Set(intcountnumber)			   {TA0R = intcountnumber;}

/*#define eRIC_TimerA0_Capture0orCompare0Setup(CompleteSetup) {TA0CCTL1 = CompleteSetup;} //V1.4
#define eRIC_TimerA0_Capture1orCompare1Setup(CompleteSetup) {TA0CCTL1 = CompleteSetup;}
#define eRIC_TimerA0_Capture2orCompare2Setup(CompleteSetup) {TA0CCTL1 = CompleteSetup;}
#define eRIC_TimerA0_Capture3orCompare3Setup(CompleteSetup) {TA0CCTL1 = CompleteSetup;}
#define eRIC_TimerA0_Capture4orCompare4Setup(CompleteSetup) {TA0CCTL1 = CompleteSetup;}*/

#define eRIC_TimerA0_Capture0orCompare0Setup(CompleteSetup) {TA0CCTL0 = CompleteSetup;} //V1.5 typo all same TA0CCTL1
#define eRIC_TimerA0_Capture1orCompare1Setup(CompleteSetup) {TA0CCTL1 = CompleteSetup;} //V1.5
#define eRIC_TimerA0_Capture2orCompare2Setup(CompleteSetup) {TA0CCTL2 = CompleteSetup;} //V1.5
#define eRIC_TimerA0_Capture3orCompare3Setup(CompleteSetup) {TA0CCTL3 = CompleteSetup;} //V1.5
#define eRIC_TimerA0_Capture4orCompare4Setup(CompleteSetup) {TA0CCTL4 = CompleteSetup;} //V1.5

#define eRICTimer_CaptureNothing                            CM_0
#define eRICTimer_CaptureOnRising                           CM_1
#define eRICTimer_CaptureOnFalling                          CM_2
#define eRICTimer_CaptureOnBothFallRise                     CM_3

#define eRICTimer_CaptureMode                               CAP
//#define eRICTimer_CompareMode                            ~CAP
#define eRICTimer_CompareMode                               0 // ~CAP V1.5

#define eRICTimer_OutputMode_OutputOnly                     OUTMOD_0   //V1.5
#define eRICTimer_OutputMode_Set                            OUTMOD_1
#define eRICTimer_OutputMode_Toggle_Reset                   OUTMOD_2
#define eRICTimer_OutputMode_Set_Reset                      OUTMOD_3
#define eRICTimer_OutputMode_Toggle                         OUTMOD_4
#define eRICTimer_OutputMode_Reset                          OUTMOD_5
#define eRICTimer_OutputMode_Toggle_Set                     OUTMOD_6
#define eRICTimer_OutputMode_Reset_Set                      OUTMOD_7

#define eRICTimer_CCInterruptEnable                         CCIE
//#define eRICTimer_CCInterruptDisable                     ~CCIE
#define eRICTimer_CCInterruptDisable                        0 //~CCIE //V1.5

#define eRIC_TimerA0_Capture0orCompare0_Data                TA0CCR0
#define eRIC_TimerA0_Capture1orCompare1_Data                TA0CCR1
#define eRIC_TimerA0_Capture2orCompare2_Data                TA0CCR2
#define eRIC_TimerA0_Capture3orCompare3_Data                TA0CCR3
#define eRIC_TimerA0_Capture4orCompare4_Data                TA0CCR4

#define eRIC_TimerA0_Capture0orCompare0InterruptEnable()    {TA0CCTL0 |=CCIE;}  //V1.5
#define eRIC_TimerA0_Capture1orCompare1InterruptEnable()    {TA0CCTL1 |=CCIE;}  //V1.5
#define eRIC_TimerA0_Capture2orCompare2InterruptEnable()    {TA0CCTL2 |=CCIE;}  //V1.5
#define eRIC_TimerA0_Capture3orCompare3InterruptEnable()    {TA0CCTL3 |=CCIE;}  //V1.5
#define eRIC_TimerA0_Capture4orCompare4InterruptEnable()    {TA0CCTL4 |=CCIE;}  //V1.5

#define eRIC_TimerA0_Capture0orCompare0InterruptDisable()   {TA0CCTL0 &=~CCIE;} //V1.5
#define eRIC_TimerA0_Capture1orCompare1InterruptDisable()   {TA0CCTL1 &=~CCIE;} //V1.5
#define eRIC_TimerA0_Capture2orCompare2InterruptDisable()   {TA0CCTL2 &=~CCIE;} //V1.5
#define eRIC_TimerA0_Capture3orCompare3InterruptDisable()   {TA0CCTL3 &=~CCIE;} //V1.5
#define eRIC_TimerA0_Capture4orCompare4InterruptDisable()   {TA0CCTL4 &=~CCIE;} //V1.5

#define eRIC_TimerA0_Capture0orCompare0InterruptFlagSet()   {TA0CCTL0 |=CCIFG;}  //V1.5
#define eRIC_TimerA0_Capture1orCompare1InterruptFlagSet()   {TA0CCTL1 |=CCIFG;}  //V1.5
#define eRIC_TimerA0_Capture2orCompare2InterruptFlagSet()   {TA0CCTL2 |=CCIFG;}  //V1.5
#define eRIC_TimerA0_Capture3orCompare3InterruptFlagSet()   {TA0CCTL3 |=CCIFG;}  //V1.5
#define eRIC_TimerA0_Capture4orCompare4InterruptFlagSet()   {TA0CCTL4 |=CCIFG;}  //V1.5


#define eRIC_TimerA0_Capture0orCompare0InterruptFlagClear() {TA0CCTL0 &=~CCIFG;}  //V1.5
#define eRIC_TimerA0_Capture1orCompare1InterruptFlagClear() {TA0CCTL1 &=~CCIFG;}  //V1.5
#define eRIC_TimerA0_Capture2orCompare2InterruptFlagClear() {TA0CCTL2 &=~CCIFG;}  //V1.5
#define eRIC_TimerA0_Capture3orCompare3InterruptFlagClear() {TA0CCTL3 &=~CCIFG;}  //V1.5
#define eRIC_TimerA0_Capture4orCompare4InterruptFlagClear() {TA0CCTL4 &=~CCIFG;}  //V1.5

#define eRIC_TimerA0_Capture0orCompare0HasInterrupted()     (TA0CCTL0 & CCIFG)  //V1.5
#define eRIC_TimerA0_Capture1orCompare1HasInterrupted()     (TA0CCTL1 & CCIFG)  //V1.5
#define eRIC_TimerA0_Capture2orCompare2HasInterrupted()     (TA0CCTL2 & CCIFG)  //V1.5
#define eRIC_TimerA0_Capture3orCompare3HasInterrupted()     (TA0CCTL3 & CCIFG)  //V1.5
#define eRIC_TimerA0_Capture4orCompare4HasInterrupted()     (TA0CCTL4 & CCIFG)  //V1.5

/*PWM Related definition*/
#define eRIC_PWM_Cs(Clocksource)                           {TA0CTL &= ~TASSEL__INCLK;TA0CTL |= Clocksource;}
//#define eRICPWM_Cs_TA0CLK             					TASSEL__TACLK
#define eRICPWM_Cs_32k               						TASSEL__ACLK
#define eRICPWM_Cs_CPU              						TASSEL__SMCLK
//#define eRICPWM_Cs_INCLK              					TASSEL__INCLK

#define eRIC_PWM_UpDownContinousMode(UpDownContinousMode)  {TA0CTL &= ~MC__UPDOWN;TA0CTL |= UpDownContinousMode;}
#define eRICPWM_Stop            						    MC__STOP
#define eRICPWM_UpMode        							    MC__UP
#define eRICPWM_ContinousMode  							    MC__CONTINUOUS
#define eRICPWM_UpdownMode    							    MC__UPDOWN

#define eRIC_PWM_ClockDivider(Clockdivider)				   {TA0CTL &= ~ID__8;TA0CTL |= Clockdivider;}
#define eRICPWM_DIV_1                         			    ID__1
#define eRICPWM_DIV_2                          			    ID__2
#define eRICPWM_DIV_4                          				ID__4
#define eRICPWM_DIV_8                          				ID__8

#define eRIC_PWM_Reset()          						   {TA0CTL |= TACLR;}


#define eRIC_PWM_Setup(ClockSource,ClockDivider,UpDownContinousMode,Period)   {TA0CTL = (ClockSource)+(ClockDivider)+(UpDownContinousMode)+(TACLR);TA0CCR0 = Period;}

//#define eRIC_PWM_Setup(ClockSource,ClockDivider,UpDownContinousMode,Period) {eRIC_PWM_Cs(ClockSource);eRIC_PWM_ClockDivider(ClockDivider);eRIC_PWM_UpDownContinousMode(UpDownContinousMode);eRIC_PWM_Reset();TA0CCR0 = Period;}

#define eRIC_PWM1_DutyCycle(DutyCycle,LogicOutput)         {TA0CCR1 = DutyCycle;TA0CCTL1 = LogicOutput;}
#define eRIC_PWM2_DutyCycle(DutyCycle,LogicOutput)         {TA0CCR2 = DutyCycle;TA0CCTL2 = LogicOutput;}
#define eRIC_PWM3_DutyCycle(DutyCycle,LogicOutput)         {TA0CCR3 = DutyCycle;TA0CCTL3 = LogicOutput;}
#define eRIC_PWM4_DutyCycle(DutyCycle,LogicOutput)         {TA0CCR4 = DutyCycle;TA0CCTL4 = LogicOutput;}

#define eRICPWM_OutputMode_Set                              OUTMOD_1
#define eRICPWM_OutputMode_Toggle_Reset                     OUTMOD_2
#define eRICPWM_OutputMode_Set_Reset                        OUTMOD_3
#define eRICPWM_OutputMode_Toggle                           OUTMOD_4
#define eRICPWM_OutputMode_Reset                            OUTMOD_5
#define eRICPWM_OutputMode_Toggle_Set                       OUTMOD_6
#define eRICPWM_OutputMode_Reset_Set                        OUTMOD_7


#define eRIC_PWM_Period(Period)                            {TA0CCR0 = Period;}


#define eRIC_CRC_Initialise(Data)					       {CRCINIRES = Data;} //from V1.4
#define eRIC_CRC_FirstByte(Data)     					   {CRCDI = Data;}       //from V1.4
#define eRIC_CRC_NextBytes(Data) 					       {CRCDI_L = Data;}     //from V1.4
#define eRIC_CRC_Result()            	 					CRCINIRES   //from V1.4

#define eRIC_RadioRegWrite(RegAddress,Data)                {CommonPassedVariable = RegAddress;CommonPassedVariable2 = Data;asm(" CALLA #0X807C");}  //V1.5
#define eRIC_RadioRegRead(RegAddress)                       RadioRegRead(RegAddress)   //V1.5

#define eRIC_SetGDOSignal(SelectSignalType)                {eRIC_RadioRegWrite(IOCFG2,SelectSignalType);}
//Few signal selection. Others can be found on Page 712 of slau259e.pdf datasheet
#define eRICGDO_SyncWordSignal                              0x06 //Asserts when sync word is sent or recevied and desserts at the end of packet
#define eRICGDO_PacketReceivedWithCRCOKSignal               0x07 //Asserts when packet has been received  with CRC ok and deserts when byte is read
#define eRICGDO_CarrierSenseSignal                          0x0E
#define eRICGDO_RadioTransmitSignal                         0x1B
#define eRICGDO_RadioReceiverSignal                         0x1C
#define eRICGDO_RadioRSSIValidSignal                        0x1E
#define eRICGDO_RadioRXTimeoutSignal                        0x1F
#define eRICGDO_RadioClock32Signal                          0x27

//#define eRIC_RfDataReceivedInterruptEnable()               {P1REN |= BIT2;P1OUT&=~BIT2; P1IES &=~BIT2;P1IFG &=~BIT2; P1IE|=BIT2; }  //V1.5.5 edge select and pull down is moved in to eROS
#define eRIC_RfDataReceivedInterruptEnable()               {P1IE|=BIT2;}  //V1.5.5
#define eRIC_RfDataReceivedInterruptDisable()              {P1IE&=~BIT2;}  //V1.5.4
void eRIC_RfDataReceivedInterrupt();                       //V1.5.4
#define eRIC_RfDataReceivedInterruptFlag_Set()             {P1IFG|=BIT2;}  //V1.5.5
#define eRIC_RfDataReceivedInterruptFlag_Clear()           {P1IFG&=~BIT2;}  //V1.5.5


#define eRIC_WaitForStableClock();                          asm(" CALLA #0X8084"); //V1.5.5  V4.5

#endif
