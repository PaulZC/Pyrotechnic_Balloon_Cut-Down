// MPL3115A2 I2C routines
// Gratefully plagiarised from https://github.com/sparkfun/MPL3115A2_Breakout
// Then modified for the eRIC eROS
// Acknowledgements: Nathan Seidle, Sparkfun Electronics

#include <cc430f5137.h>
#include "eRIC.h"
#include "MPL3115A2.h"
#include "LPRS_I2C.h"

//Clears then sets the OST bit which causes the sensor to immediately take another reading
//Needed to sample faster than 1Hz
void toggleOneShot(void)
{
  unsigned char tempSetting = I2C_ReadAddress(CTRL_REG1); //Read current settings
  tempSetting &= ~(1<<1); //Clear OST bit
  I2C_WriteAddress(CTRL_REG1, tempSetting);

  tempSetting = I2C_ReadAddress(CTRL_REG1); //Read current settings to be safe
  tempSetting |= (1<<1); //Set OST bit
  I2C_WriteAddress(CTRL_REG1, tempSetting);
}

//Reads the current pressure in Pa
//Unit must be set in barometric pressure mode
//Returns -1 if no new data is available
float readPressure()
{
    //Check PDR bit, if it's not set then toggle OST
    if(I2C_ReadAddress(STATUS) & (1<<2) == 0) toggleOneShot(); //Toggle the OST bit causing the sensor to immediately take another reading

    //Wait for PDR bit, indicates we have new pressure data
    int counter = 0;
    while(I2C_ReadAddress(STATUS) & (1<<2) == 0)
    {
        if(++counter > 600) return(-999); //Error out after max of 512ms for a read
        eRIC_Delay(1);
    }

    // Read pressure registers

    eRIC_I2CB_AsTransmitter(); //I2C set as Master TX
    eRIC_I2CB_Start();//Start I2C. this will send address
    eRIC_I2CB_SendByte(OUT_P_MSB); // Pressure most significant byte register
    while(eRIC_I2CB_TxBufferIsBusy()); // Wait for bytes to be sent
    eRIC_I2CB_AsReceiver(); // I2C set as receiver
    eRIC_I2CB_Start();// Start I2C
    while(eRIC_I2CB_IsStartActive()); // wait while start is active, it needs to be cleared
    unsigned char msb, csb, lsb;
    msb = eRIC_I2CB_ReceiveByte(); // receive most significant byte
    csb = eRIC_I2CB_ReceiveByte(); // receive central byte
    eRIC_I2CB_Stop(); //Stop I2C
    lsb = eRIC_I2CB_ReceiveByte();// receive least significant byte
    while(eRIC_I2CB_IsBusBusy()); //wait while I2C is busy

    toggleOneShot(); //Toggle the OST bit causing the sensor to immediately take another reading

    // Pressure comes back as a left shifted 20 bit number
    long pressure_whole = (long)msb<<16 | (long)csb<<8 | (long)lsb;
    pressure_whole >>= 6; //Pressure is an 18 bit number with 2 bits of decimal. Get rid of decimal portion.

    lsb &= 0x30; // B00110000; //Bits 5/4 represent the fractional component
    lsb >>= 4; //Get it right aligned
    float pressure_decimal = ((float)lsb)/4.0; //Turn it into fraction

    float pressure = (float)pressure_whole + pressure_decimal;

    return(pressure);
}

float readTemp()
{
    if(I2C_ReadAddress(STATUS) & (1<<1) == 0) toggleOneShot(); //Toggle the OST bit causing the sensor to immediately take another reading

    //Wait for TDR bit, indicates we have new temp data
    int counter = 0;
    while( (I2C_ReadAddress(STATUS) & (1<<1)) == 0)
    {
        if(++counter > 600) return(-999); //Error out after max of 512ms for a read
        eRIC_Delay(1);
    }

    // Read temperature registers

    eRIC_I2CB_AsTransmitter(); //I2C set as Master TX
    eRIC_I2CB_Start();//Start I2C. this will send address
    eRIC_I2CB_SendByte(OUT_T_MSB); // Temperature most significant byte register
    while(eRIC_I2CB_TxBufferIsBusy()); // Wait for bytes to be sent
    eRIC_I2CB_AsReceiver(); // I2C set as receiver
    eRIC_I2CB_Start();// Start I2C
    while(eRIC_I2CB_IsStartActive()); // wait while start is active, it needs to be cleared
    unsigned char msb, lsb;
    msb = eRIC_I2CB_ReceiveByte(); // receive most significant byte
    eRIC_I2CB_Stop(); //Stop I2C
    lsb = eRIC_I2CB_ReceiveByte();// receive least significant byte
    while(eRIC_I2CB_IsBusBusy()); //wait while I2C is busy

    toggleOneShot(); //Toggle the OST bit causing the sensor to immediately take another reading

    //Negative temperature fix by D.D.G.
    unsigned int foo = 0;
    int negSign = 0;

    //Check for 2s compliment
    if(msb > 0x7F)
    {
        foo = ~(((unsigned int)msb << 8) + (unsigned int)lsb) + 1;  //2�s complement
        msb = (unsigned char)(foo >> 8);
        lsb = (unsigned char)(foo & 0x00F0);
        negSign = 1;
    }

    // The least significant bytes l_altitude and l_temp are 4-bit,
    // fractional values, so you must cast the calculation in (float),
    // shift the value over 4 spots to the right and divide by 16 (since
    // there are 16 values in 4-bits).
    float templsb = ((float)(lsb>>4))/16.0; //temp, fraction of a degree

    float temperature = ((float)msb) + templsb;

    if (negSign) temperature = 0 - temperature;

    return(temperature);
}

void setModeBarometer() // Put MPL3115A2 into Barometer mode
{
    unsigned char tempSetting = I2C_ReadAddress(CTRL_REG1); //Read current settings
    tempSetting &= ~(1<<7); //Clear ALT bit
    I2C_WriteAddress(CTRL_REG1, tempSetting);
}

//Call with a rate from 0 to 7. See page 33 for table of ratios.
//Sets the over sample rate. Datasheet calls for 128 but you can set it
//from 1 to 128 samples. The higher the oversample rate the greater
//the time between data samples.
void setOversampleRate(unsigned char sampleRate)
{
  if(sampleRate > 7) sampleRate = 7; //OS cannot be larger than 0b.0111
  sampleRate <<= 3; //Align it for the CTRL_REG1 register

  unsigned char tempSetting = I2C_ReadAddress(CTRL_REG1); //Read current settings
  tempSetting &= 0xC7; //B11000111; //Clear out old OS bits
  tempSetting |= sampleRate; //Mask in new OS bits
  I2C_WriteAddress(CTRL_REG1, tempSetting);
}

//Enables the pressure and temp measurement event flags so that we can
//test against them. This is recommended in datasheet during setup.
void enableEventFlags()
{
    I2C_WriteAddress(PT_DATA_CFG, 0x07); // Enable all three pressure and temp event flags
}

